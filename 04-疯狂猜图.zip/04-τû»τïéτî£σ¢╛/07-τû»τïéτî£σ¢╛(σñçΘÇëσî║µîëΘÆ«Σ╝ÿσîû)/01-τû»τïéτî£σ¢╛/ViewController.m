//
//  ViewController.m
//  01-疯狂猜图
//
//  Created by Luffy on 15/7/22.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "HMQuestions.h"

#define kButtonWidth 35
#define kButtonHeight 35
#define kButtonMargin 10
#define kColCount 7

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIButton *iconButton;
@property (weak, nonatomic) IBOutlet UILabel *noLabel;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIButton *nextQuestionsButton;

@property (weak, nonatomic) IBOutlet UIView *answerView;
@property (weak, nonatomic) IBOutlet UIView *optionsView;
@property (nonatomic, strong) UIButton *cover;

@property (nonatomic, strong) NSArray *questions;

// 题目索引
@property (nonatomic, assign) int index;
@end


@implementation ViewController

- (NSArray *)questions
{
    if (_questions == nil) {
        _questions = [HMQuestions questions];
    }
    return _questions;
}

/**
 *  蒙版的懒加载
 *
 *  @return 蒙版
 */
- (UIButton *)cover
{
    if (_cover == nil) {
        _cover = [[UIButton alloc] initWithFrame:self.view.bounds];
        _cover.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.5];
        [self.view addSubview:_cover];
        _cover.alpha = 0.0;
    
        [_cover addTarget:self action:@selector(bigImage) forControlEvents:UIControlEventTouchUpInside];
    }
    return _cover;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
//    NSLog(@"%@", self.questions);
    self.index = -1;
    [self nextQuestions];
    
}

/**
 *  调用此方法设置状态了
 *
 *  @return 高亮内容状态
 */
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

#pragma mark - 大图和小图的显示切换
/**
 *  大图和小图的显示切换
 */
- (IBAction)bigImage
{
    // 通过判断大图还是小图
    if (self.cover.alpha == 0.0) { // 大图
//        [self cover];
        
        // 将视图前置到视图上
        [self.view bringSubviewToFront:self.iconButton];
        
        CGFloat w = self.view.bounds.size.width;
        CGFloat h = w;
        CGFloat y = (self.view.bounds.size.height - h) * 0.5;
        
        [UIView animateWithDuration:1.0 animations:^{
            self.iconButton.frame = CGRectMake(0, y, w, h);
            self.cover.alpha = 1.0;
        }];
    } else { // 小图
        [UIView animateWithDuration:1.0 animations:^{
            self.iconButton.frame = CGRectMake(85, 85, 150, 150);
            self.cover.alpha = 0.0;
        }];
    }
    
}

#pragma mark - 下一题
- (IBAction)nextQuestions
{
    // 1. 当前答题的索引，索引递增
    self.index++;
    
    // 2. 从数组中按照索引从题目中取出模型数据
    HMQuestions *questions = self.questions[self.index];
    
    // 3. 设置基本信息
    [self setupInfoButton:questions];
    
    // 4. 设置答案区按钮
    [self creatAnswerButton:questions];
    
    // 5. 设置备选区按钮
    [self creatOptionsButton:questions];
    
}

/** 设置基本信息 */
- (void)setupInfoButton:(HMQuestions *)questions
{
    self.noLabel.text = [NSString stringWithFormat:@"%d/%d", self.index + 1, self.questions.count];
    self.titleLabel.text = questions.title;
    [self.iconButton setImage:[UIImage imageNamed:questions.icon] forState:UIControlStateNormal];
    
    // 如果到达最后一题，禁用下一题按钮
    self.nextQuestionsButton.enabled = (self.index < self.questions.count - 1);
    
}

/** 设置答案区按钮 */
- (void)creatAnswerButton:(HMQuestions *)questions
{
    for (UIView *view in self.answerView.subviews) {
        [view removeFromSuperview];
    }
    
    CGFloat answerW = self.answerView.bounds.size.width;
    int lenght = questions.answer.length;
    
    CGFloat answerMarginX  = (answerW - kButtonWidth * lenght - kButtonMargin * (lenght - 1)) * 0.5;
    
    for (int i=0; i<lenght; i++) {
        
        
        CGFloat x = answerMarginX +i * (kButtonMargin + kButtonWidth);
        
        UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(x, 0, kButtonWidth, kButtonHeight)];
        
        [btn setBackgroundImage:[UIImage imageNamed:@"btn_answer"] forState:UIControlStateNormal];
        [btn setBackgroundImage:[UIImage imageNamed:@"btn_answer_highlighted"] forState:UIControlStateHighlighted];
        
        [self.answerView addSubview:btn];
        
    }
    
}

/** 设置备选区按钮 */
- (void)creatOptionsButton:(HMQuestions *)questions
{
    if (self.optionsView.subviews.count != questions.options.count) {
        
        for (UIView *view  in self.optionsView.subviews) {
            [view removeFromSuperview];
        }
        
        CGFloat optionsW = self.optionsView.bounds.size.width;
        CGFloat optionsX = (optionsW - kColCount * kButtonWidth - kButtonMargin * (kColCount - 1)) * 0.5;
        
        for (int i=0; i<questions.options.count; i++) {
            
            int row = i / kColCount;
            int col = i % kColCount;
            
            CGFloat x = optionsX + col * (kButtonWidth + kButtonMargin);
            CGFloat y = row * (kButtonHeight + kButtonMargin);
            
            UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(x, y, kButtonWidth, kButtonHeight)];
            [btn setBackgroundImage:[UIImage imageNamed:@"btn_option"] forState:UIControlStateNormal];
            [btn setBackgroundImage:[UIImage imageNamed:@"btn_option_highlighted"] forState:UIControlStateHighlighted];
            
            [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            
            [self.optionsView addSubview:btn];
            
        }
        NSLog(@"%i", self.optionsView.subviews.count);
    }
    int i = 0;
    for (UIButton *btn in self.optionsView.subviews) {
        [btn setTitle:questions.options[i++] forState:UIControlStateNormal];
    }
    
//    [self.optionsView.subviews enumerateObjectsUsingBlock:^(UIButton *btn, NSUInteger i, BOOL *stop) {
//        [btn setTitle:questions.options[i++] forState:UIControlStateNormal];
//    }];
    
}

@end
