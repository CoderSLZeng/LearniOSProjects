//
//  NSArray+Log.m
//  01-疯狂猜图
//
//  Created by Luffy on 15/7/25.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NSArray+Log.h"

@implementation NSArray (Log)

/**
 *  使用NSLog方法，让终端能显示中文
 *
 *  @param locale 本地的数据
 *
 *  @return 重写字符串格式
 */
- (NSString *)descriptionWithLocale:(id)locale
{
    // 创建一个可变的字符串
    NSMutableString *strM = [NSMutableString stringWithString:@"\n"];
    
    for (id obj in self) {
        [strM appendFormat:@"\t%@,\n", obj];
    }
    [strM appendString:@")\n"];
    
    return strM;
}

@end
