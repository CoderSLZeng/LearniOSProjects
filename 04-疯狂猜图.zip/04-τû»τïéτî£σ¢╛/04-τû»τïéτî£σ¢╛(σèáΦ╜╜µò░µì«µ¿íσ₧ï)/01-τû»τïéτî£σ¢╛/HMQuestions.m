//
//  HMquestions.m
//  01-疯狂猜图
//
//  Created by Luffy on 15/7/25.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMQuestions.h"

@implementation HMQuestions

- (instancetype)initWithDict:(NSDictionary *)dict
{
    self = [super init];
    if (self) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+ (instancetype)questionsWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}

+ (NSArray *)questions
{
    NSArray *array = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"questions.plist" ofType:nil]];
    NSMutableArray *arrayM = [NSMutableArray array];
    
//    for (NSDictionary *dict in array) {
//        [arrayM addObject:[self questionsWithDict:dict]];
//    }
    
    [array enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        [arrayM addObject:[HMQuestions questionsWithDict:obj]];
    }];
    return arrayM;
}

- (NSString *)description
{
    return [NSString stringWithFormat:@"<%@: %p> {answeer: %@, icon: %@, title: %@, options: %@}", self.class, self, self.answer, self.icon, self.title, self.options];
}

@end
