//
//  HMquestions.h
//  01-疯狂猜图
//
//  Created by Luffy on 15/7/25.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HMQuestions : NSObject

@property (nonatomic, copy) NSString *answer;
@property (nonatomic, copy) NSString *icon;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, strong) NSArray *options;

- (instancetype)initWithDict:(NSDictionary *)dict;
+ (instancetype)questionsWithDict:(NSDictionary *)dict;

+ (NSArray *)questions;


@end
