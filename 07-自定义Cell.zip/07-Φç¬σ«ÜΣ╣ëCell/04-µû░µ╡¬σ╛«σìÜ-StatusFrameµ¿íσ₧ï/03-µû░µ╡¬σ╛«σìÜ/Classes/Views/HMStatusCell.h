//
//  HMStatusCell.h
//  03-新浪微博
//
//  Created by Luffy on 15/8/11.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HMStatusModel;

@interface HMStatusCell : UITableViewCell
@property (nonatomic, strong) HMStatusModel *status;

@end
