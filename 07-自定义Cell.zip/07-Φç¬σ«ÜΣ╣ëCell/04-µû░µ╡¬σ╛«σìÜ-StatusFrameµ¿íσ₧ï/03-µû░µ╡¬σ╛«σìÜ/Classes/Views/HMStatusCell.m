
//
//  HMStatusCell.m
//  03-新浪微博
//
//  Created by Luffy on 15/8/11.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMStatusCell.h"
#import "HMStatusModel.h"
#import "Constant.h"

@interface HMStatusCell ()
@property (nonatomic, strong) UIImageView *iconView;
@property (nonatomic, strong) UILabel *nameView;
@property (nonatomic, strong) UIImageView *vipView;
@property (nonatomic, strong) UILabel *textView;
@property (nonatomic, strong) UIImageView *pictuerView;
@end

@implementation HMStatusCell

- (UIImageView *)iconView
{
    if (_iconView == nil) {
        _iconView = [[UIImageView alloc] init];
        [self.contentView addSubview:_iconView];
    }
    return _iconView;
}

- (UILabel *)nameView
{
    if (_nameView == nil) {
        _nameView = [[UILabel alloc] init];
        _nameView.font = kNameFont;
        [self.contentView addSubview:_nameView];
    }
    return _nameView;
}

- (UIImageView *)vipView
{
    if (_vipView == nil) {
        _vipView = [[UIImageView alloc] init];
        _vipView.image = [UIImage imageNamed:@"vip"];
        _vipView.hidden = YES;

        [self.contentView addSubview:_vipView];
    }
    return _vipView;
}

- (UILabel *)textView
{
    if (_textView == nil) {
        _textView = [[UILabel alloc] init];
        _textView.font = kTextFont;
        _textView.numberOfLines = 0;
        [self.contentView addSubview:_textView];
    }
    return _textView;
}

- (UIImageView *)pictuerView
{
    if (_pictuerView == nil) {
        _pictuerView = [[UIImageView alloc] init];
        [self.contentView addSubview:_pictuerView];
    }
    return _pictuerView;
}

- (void)setStatus:(HMStatusModel *)status
{
    _status = status;
    
    // 1.设置数据
    [self settingData];
    
    // 2.设置位置
    [self settingFrame];
}

/**
 *  设置数据方法
 */
- (void)settingData
{
    self.iconView.image = [UIImage imageNamed:self.status.icon];
    self.nameView.text = self.status.name;
    if (self.status.vip) {
        self.vipView.hidden = NO;
        self.nameView.textColor = [UIColor redColor];
    } else {
        self.vipView.hidden = YES;
        self.nameView.textColor = [UIColor blackColor];
    }
    
    self.textView.text = self.status.text;
    
    if (self.status.picture.length > 0) {
        self.pictuerView.hidden = NO;
        self.pictuerView.image = [UIImage imageNamed:self.status.picture];
    } else {
        self.pictuerView.hidden = YES;
    }
    
}

/**
 *  设置位置方法
 */
- (void)settingFrame
{
 
    // 0.边距
    CGFloat padding = 10;
    
    // 1.头像
    CGFloat iconX = padding;
    CGFloat iconY = padding;
    CGFloat iconW = 30;
    CGFloat iconH = 30;
    self.iconView.frame = CGRectMake(iconX, iconY, iconW, iconH);
    
    // 2.姓名
    NSDictionary *nameDict = @{NSFontAttributeName: kNameFont};
    CGRect nameFrame = [self.status.name boundingRectWithSize:CGSizeMake(MAXFLOAT, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:nameDict context:nil];
    nameFrame.origin.x = CGRectGetMaxX(self.iconView.frame) + padding;
    nameFrame.origin.y = padding + (self.iconView.bounds.size.height - nameFrame.size.height) * 0.5;
    self.nameView.frame = nameFrame;
    
    // 3.vip
    CGFloat vipX = CGRectGetMaxX(nameFrame) + padding;
    CGFloat vipY = nameFrame.origin.y;
    CGFloat vipW = 14;
    CGFloat vipH = 14;
    self.vipView.frame = CGRectMake(vipX, vipY, vipW, vipH);
    
    // 4.正文
    NSDictionary *textDict = @{NSFontAttributeName: kTextFont};
    CGRect textFrame = [self.status.text boundingRectWithSize:CGSizeMake(300, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:textDict context:nil];
    textFrame.origin.x = padding;
    textFrame.origin.y = padding + CGRectGetMaxY(self.iconView.frame);
    self.textView.frame = textFrame;
    
    CGFloat cellHeight;
    
    // 5.图片
    if (self.status.picture.length > 0) {
        CGFloat pictureX = padding;
        CGFloat pictureY = CGRectGetMaxY(textFrame) + padding;
        CGFloat pictureW = 100;
        CGFloat pictureH = 100;
        self.pictuerView.frame = CGRectMake(pictureX, pictureY, pictureW, pictureH);
        cellHeight = CGRectGetMaxY(self.pictuerView.frame) + padding;
    } else {
        cellHeight = CGRectGetMaxY(self.textView.frame) + padding;
    }

}
@end
