//
//  ViewController.m
//  03-新浪微博
//
//  Created by Luffy on 15/8/11.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "HMStatusModel.h"
#import "HMStatusCell.h"
#import "HMStatusFrameModel.h"

@interface ViewController ()

@property (nonatomic, strong) NSArray *statusFrames;

@end

@implementation ViewController

- (NSArray *)statusFrames
{
    if (_statusFrames == nil) _statusFrames = [HMStatusFrameModel statusFrames];
    return _statusFrames;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.tableView.rowHeight = 200;
}

#pragma mark - 数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  self.statusFrames.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *ID = @"Cell";
    
    HMStatusCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    
    if (cell == nil) {
        cell = [[HMStatusCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
    }
    
    HMStatusFrameModel *statusFrame = self.statusFrames[indexPath.row];
    cell.status = statusFrame.status;
    
    return cell;
}

#pragma mark - 代理方法
#if 0
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    HMStatusFrameModel *statusFrame = self.statuses[indexPath.row];
    
    return statusFrame.cellHeight;
}
#endif


@end
