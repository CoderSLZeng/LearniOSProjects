//
//  Constant.h
//  03-新浪微博
//
//  Created by Luffy on 15/8/11.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#define kNameFont   [UIFont systemFontOfSize:14.0f]
#define kTextFont   [UIFont systemFontOfSize:16.0f]