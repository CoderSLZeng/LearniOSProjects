//
//  HMStatusFrameModel.h
//  03-新浪微博
//
//  Created by Luffy on 15/8/11.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@class HMStatusModel;

/** 专门计算所有控件位置 */
@interface HMStatusFrameModel : NSObject

@property (nonatomic, assign) CGRect iconF;
@property (nonatomic, assign) CGRect nameF;
@property (nonatomic, assign) CGRect vipF;
@property (nonatomic, assign) CGRect textF;
@property (nonatomic, assign) CGRect pictureF;

/** 行高 */
@property (nonatomic, assign) CGFloat cellHeight;

/** 所有控件的尺寸都可以通过Status来计算得出 */
@property (nonatomic, strong) HMStatusModel *status;

/** 所有的statusFrame数据数组 */
+ (NSArray *)statusFrames;

@end
