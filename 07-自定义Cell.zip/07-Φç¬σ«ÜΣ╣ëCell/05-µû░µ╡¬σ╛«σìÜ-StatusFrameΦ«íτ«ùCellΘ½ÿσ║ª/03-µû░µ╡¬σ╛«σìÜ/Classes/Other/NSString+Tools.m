//
//  NSString+Tools.m
//  03-新浪微博
//
//  Created by Luffy on 15/8/11.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NSString+Tools.h"

@implementation NSString (Tools)

// self 就是调用当前成员方法的NSString对象
- (CGRect)textRectWithSize:(CGSize)size attributes:(NSDictionary *)attributes
{
    return [self boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin attributes:attributes context:nil];
}

@end
