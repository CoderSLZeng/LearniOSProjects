//
//  ViewController.m
//  03-新浪微博
//
//  Created by Luffy on 15/8/11.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "HMStatusModel.h"
#import "HMStatusCell.h"
#import "HMStatusFrameModel.h"

@interface ViewController ()

@property (nonatomic, strong) NSArray *statusFrames;

@end

@implementation ViewController
static NSString *ID = @"Cell";

- (NSArray *)statusFrames
{
    if (_statusFrames == nil) _statusFrames = [HMStatusFrameModel statusFrames];
    return _statusFrames;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
//    self.tableView.rowHeight = 200;
    
    // 为tableView注册可重用单元格
    [self.tableView registerClass:[HMStatusCell class] forCellReuseIdentifier:ID];
}

#pragma mark - 数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  self.statusFrames.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    /**
     *  在Storyboard中指定了可重用标示符，同时指定了Cell的类型是HMStatusCell
    
        系统会为tableView注册一个原形Cell，专门用来做可重用单元格的，一旦缓冲区不存在
        可重用单元格，系统会使用原形Cell新实例化一个Cell用程序使用！
     
        因此如果在，Storyboard中，注册了原形Cell，就不再需要 cell == nil 的判断了
     */
    
//    HMStatusCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    // 使用这个方法，要求一定注册可重用单元格，否则就会崩溃！
    // 官方建议使用以下方法，利用程序的崩溃，及时发现问题
    HMStatusCell *cell = [tableView dequeueReusableCellWithIdentifier:ID forIndexPath:indexPath];
    // 一旦在注册了可重用Cell，以上两个方法是等价的
    
//    if (cell == nil) {
//        cell = [[HMStatusCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
//    }
    
    HMStatusFrameModel *statusFrame = self.statusFrames[indexPath.row];
    cell.status = statusFrame.status;
    
    return cell;
}

#pragma mark - 代理方法
#if 1
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    HMStatusFrameModel *statusFrame = self.statusFrames[indexPath.row];
    
    return statusFrame.cellHeight;
}
#endif


@end
