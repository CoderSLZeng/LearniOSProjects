//
//  ViewController.m
//  02-团购
//
//  Created by Luffy on 15/8/6.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "HMTg.h"
#import "HMTgCell.h"

@interface ViewController () <UITableViewDataSource>
@property (nonatomic, strong) NSArray *tgs;
@end

@implementation ViewController

- (NSArray *)tgs
{
    if (_tgs == nil) _tgs = [HMTg tgs];
    return _tgs;
}

- (void)viewDidLoad
{
    self.tableView.rowHeight = 80;
    self.tableView.contentInset = UIEdgeInsetsMake(20, 0, 0, 0);
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, 44)];
    view.backgroundColor = [UIColor redColor];
    self.tableView.tableFooterView = view;
}

//- (BOOL)prefersStatusBarHidden
//{
//    return YES;
//}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.tgs.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    HMTgCell *cell = [HMTgCell cellWithTableView:tableView];
   
    cell.tg = self.tgs[indexPath.row];
    

    
    return cell;
}


@end
