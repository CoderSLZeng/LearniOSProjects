//
//  HMTgCell.h
//  02-团购
//
//  Created by Luffy on 15/8/6.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HMTg;

@interface HMTgCell : UITableViewCell

@property (nonatomic, strong) HMTg *tg;

+ (instancetype)cellWithTableView:(UITableView *)tableViewell;

@end
