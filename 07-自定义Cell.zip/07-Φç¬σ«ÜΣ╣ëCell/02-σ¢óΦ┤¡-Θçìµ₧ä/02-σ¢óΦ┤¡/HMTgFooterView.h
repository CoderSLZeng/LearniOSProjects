//
//  HMTgFooterView.h
//  02-团购
//
//  Created by Luffy on 15/8/8.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HMTgFooterView;

@protocol HMTgFooterViewDelegate <NSObject>

@optional
- (void)tgFooterViewDidDownloadButtonClick:(HMTgFooterView *)footerView;

@end

@interface HMTgFooterView : UIView

@property (weak, nonatomic) id <HMTgFooterViewDelegate> delegate;

+ (instancetype)footerView;

@end
