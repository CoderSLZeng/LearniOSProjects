//
//  HMTgFooterView.m
//  02-团购
//
//  Created by Luffy on 15/8/8.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMTgFooterView.h"

@interface HMTgFooterView ()
@property (weak, nonatomic) IBOutlet UIButton *loadMoreButton;
@property (weak, nonatomic) IBOutlet UIView *tipsView;

@end

@implementation HMTgFooterView

+ (instancetype)footerView
{
    return [[[NSBundle mainBundle] loadNibNamed:@"HMTgFooterView" owner:nil options:nil] lastObject];

}

- (IBAction)loadMore {
    
    // 1.隐藏按钮
    self.loadMoreButton.hidden = YES;
    
    // 2.显示提示视图
    self.tipsView.hidden = NO;
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        if ([self.delegate respondsToSelector:@selector(tgFooterViewDidDownloadButtonClick:)]) {

            // 3.加载数据
            [self.delegate tgFooterViewDidDownloadButtonClick:self];
        }
        
        
        // 4.加载完成数据
        self.loadMoreButton.hidden = NO;
        self.tipsView.hidden = YES;
    });
}

@end
