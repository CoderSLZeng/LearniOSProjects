//
//  ViewController.m
//  02-团购
//
//  Created by Luffy on 15/8/6.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "HMTg.h"
#import "HMTgCell.h"
#import "HMTgFooterView.h"

@interface ViewController () <UITableViewDataSource,HMTgFooterViewDelegate>
@property (nonatomic, strong) NSMutableArray *tgs;
@end

@implementation ViewController

- (NSArray *)tgs
{
    if (_tgs == nil) _tgs = [HMTg tgs];
    return _tgs;
}

- (void)viewDidLoad
{
    self.tableView.rowHeight = 80;
    self.tableView.contentInset = UIEdgeInsetsMake(20, 0, 0, 0);
    
//    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, 44)];
//    view.backgroundColor = [UIColor redColor];
    HMTgFooterView *footerView = [HMTgFooterView footerView];
    footerView.delegate = self;
    self.tableView.tableFooterView = footerView;
}

#pragma mark - footerView的代理方法
#if 1
- (void)tgFooterViewDidDownloadButtonClick:(HMTgFooterView *)footerView
{
    NSLog(@"努力加载数据中");
    
    NSDictionary *dict = @{@"title": @"佛跳墙", @"price": @"100", @"icon": @"ad_00", @"buyCount": @"250"};
    HMTg *tg = [HMTg tgWithDict:dict];
    
    [self.tgs addObject:tg];
    
    NSIndexPath *path = [NSIndexPath indexPathForItem:(self.tgs.count - 1) inSection:0];
    [self.tableView insertRowsAtIndexPaths:@[path] withRowAnimation:UITableViewRowAnimationMiddle];
}

#endif

//- (BOOL)prefersStatusBarHidden
//{
//    return YES;
//}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.tgs.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    HMTgCell *cell = [HMTgCell cellWithTableView:tableView];
   
    cell.tg = self.tgs[indexPath.row];
    

    
    return cell;
}


@end
