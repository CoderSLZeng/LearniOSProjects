//
//  HMTgCell.m
//  02-团购
//
//  Created by Luffy on 15/8/6.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMTgCell.h"
#import "HMTg.h"

@interface HMTgCell()
@property (weak, nonatomic) IBOutlet UIImageView *iconView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;
@property (weak, nonatomic) IBOutlet UILabel *buyCountLabel;

@end

@implementation HMTgCell

+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    static NSString *ID = @"Cell";
    
    HMTgCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    
    if (cell == nil) {
        
        cell = [[[NSBundle mainBundle] loadNibNamed:@"HMTgCell" owner:nil options:nil] lastObject];
    }
    return cell;
   
}

- (void)setTg:(HMTg *)tg
{
    _tg = tg;
    self.iconView.image = [UIImage imageNamed:tg.icon];
    self.titleLabel.text = tg.title;
    self.priceLabel.text = tg.price;
    self.buyCountLabel.text = tg.buyCount;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    if (selected) {
        self.contentView.backgroundColor = [UIColor grayColor];
    }
    
}

@end
