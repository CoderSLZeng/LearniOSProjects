//
//  ViewController.m
//  01-音效播放
//
//  Created by Anthony on 16/4/10.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>
#import "HMAudioTool.h"

@interface ViewController ()
@property (nonatomic, assign) SystemSoundID soundID;
@end

@implementation ViewController

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    NSLog(@"%s", __func__);
    
//    [self test];
//    [self test2];
    
    [HMAudioTool disposeAudioWithFilename:@"buyao.war"];
}

- (void)didReceiveMemoryWarning
{
    // 销毁音效ID
//    AudioServicesDisposeSystemSoundID(self.soundID);
//    [HMAudioTool disposeAudioWithFilename:@"buyao.wav"];
    
    // 随机播放
//    [HMAudioTool disposeAudioWithFilename:[NSString stringWithFormat:@"m_%.2d.wav", arc4random_uniform(14) + 3]];
    
    // 同时播放多个
    [HMAudioTool disposeAudioWithFilename:@"buyao.war"];
    [HMAudioTool disposeAudioWithFilename:@"m_03.wav"];
}

#pragma mark - 懒加载
- (SystemSoundID)soundID
{
    if (!_soundID) {
        NSURL *url = [[NSBundle mainBundle] URLForResource:@"buyao.wav" withExtension:nil];
        AudioServicesCreateSystemSoundID((__bridge CFURLRef _Nonnull)(url), &_soundID);
    }
    
    return _soundID;
}

/**
 *  使用懒加载, 只创建了一次
 */
- (void)test2 {
    
    // 播放音效（本地音效）
    AudioServicesPlaySystemSound(self.soundID);
}


/**
 *  不建议每次都创建SystemSoundID, 形象性能
 */
- (void)test {
    // 1.创建URL
    NSURL *url = [[NSBundle mainBundle] URLForResource:@"buyao.wav" withExtension:nil];
    
    // 2.创建音效ID
    SystemSoundID soundID;
    AudioServicesCreateSystemSoundID((__bridge CFURLRef _Nonnull)(url), &soundID);
    
    // 3.播放音效（本地音效）
    AudioServicesPlaySystemSound(soundID);
}
@end
