//
//  HMAudioTool.h
//  01-音效播放
//
//  Created by Anthony on 16/4/10.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HMAudioTool : NSObject
/**
 *  播放音效
 *
 *  @param filename 音效的文件名
 */
+ (void)playAudioWithFilename:(NSString *)filename;

/**
 *  销毁正在播放的音效
 *
 *  @param filename 音效的文件名
 */
+ (void)disposeAudioWithFilename:(NSString *)filename;

@end
