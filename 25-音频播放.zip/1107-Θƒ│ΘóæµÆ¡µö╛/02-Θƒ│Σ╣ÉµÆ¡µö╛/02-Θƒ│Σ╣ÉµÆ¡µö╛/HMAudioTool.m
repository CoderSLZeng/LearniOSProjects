//
//  HMAudioTuool.m
//  02-音乐播放
//
//  Created by Anthony on 16/4/10.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "HMAudioTool.h"
#import <AVFoundation/AVFoundation.h>

@interface HMAudioTool()
@end

@implementation HMAudioTool

static NSMutableDictionary *_soundIDs;

+ (NSMutableDictionary *)soundIDs
{
    if (!_soundIDs) _soundIDs = [NSMutableDictionary dictionary];
    
    return _soundIDs;
}

static NSMutableDictionary *_players;

+ (NSMutableDictionary *)players
{
    if (!_players) _players = [NSMutableDictionary dictionary];
    return _players;
}

/**
 *  播放音效
 */
+ (void)playAudioWithFilename:(NSString *)filename
{
    // 1.判断filename是否为nil
    if (filename == nil) return;
    
    // 2.从字典中取出音效ID
    SystemSoundID soundID = [[self soundIDs][filename] unsignedIntValue];
    
    // 3.判断音效ID是否为nil
    if (!soundID) {
        // 创建url
        NSURL *url = [[NSBundle mainBundle] URLForResource:filename withExtension:nil];
        
        // 判断url是否为nil
        if (url == nil) return;
        
        // 创建音效ID
        AudioServicesCreateSystemSoundID((__bridge CFURLRef _Nonnull)(url), &soundID);
        
        // 将音效ID添加到进字典中
        [self soundIDs][filename] = @(soundID);
    }
    
    // 5.播放音效
    AudioServicesPlayAlertSound(soundID);
    
}

/**
 *  销毁当前正在播放音效
 */
+ (void)disposeAudioWithFilename:(NSString *)filename
{
    // 1.判断filename是否为nil
    if (filename == nil) {
        return;
    }
    // 2.从字典中取出音效ID
    SystemSoundID soundID = [[self soundIDs][filename] unsignedIntValue];
    
    // 3.判断音效ID是否为nil
    if (!soundID) {
        // 4.销毁音效ID
        AudioServicesDisposeSystemSoundID(soundID);
        
        // 5.从字典中移除已经销毁的音效ID
        [[self soundIDs] removeObjectForKey:filename];
    }
    
}

/**
 *  根据音乐文件名称播放音乐
 */
+ (void)playMusicWithFilename:(NSString *)filename
{
    // 1.判断filename是否为nil
    if (filename == nil) return;
    
    // 2.从字典中取出播放器
    AVAudioPlayer *player = [self players][filename];
    
    // 3.判断播放器是否为nil
    if (!player) {
        // 根据文件名称加载URL
        NSURL *url = [[NSBundle mainBundle] URLForResource:filename withExtension:nil];
        
        // 判断URL是否为nil
        if (url == nil) return;
        
        // 创建播放器
        player = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:nil];
        if (![player prepareToPlay]) {
            return;
        }
        
        // 允许快进
        player.enableRate = YES;
        player.rate = 3;
        
        // 将播放器添加到字典中
        [self players][filename] =  player;
        
    }
    // 4.开始播放
    // 判断播放器是否正在播放音乐
    if (!player.playing) {
        [player play];
    }
}

/**
 *  根据音乐文件名称暂停音乐
 */
+ (void)pauseMusicWithFilename:(NSString *)filename
{
    // 1.判断filename是否为nil
    if (filename == nil) return;
    
    // 2.从字典中取出播放器
    AVAudioPlayer *player = [self players][filename];
    
    // 3.判断播放器是否存在
    if (player) {
        // 判断播放器是否正在播放
        if (player.playing) {
            // 暂停
            [player pause];
        }
    }
}

/**
 *  根据音乐文件名称停止音乐
 */
+ (void)stopMusicWithFilename:(NSString *)filename
{
    // 1.判断filename是否为nil
    if (filename == nil) return;
    
    // 2.从字典中取出播放器
    AVAudioPlayer *player = [self players][filename];
    
    // 3.判断播放器是否存在
    if (player) {
        // 判断是否正在播放
        if (player.playing) {
            // 停止音乐
            [player stop];
            
            // 清空播放器
//            player = nil;
            
            // 从字典中移除停止的音乐
            [[self players] removeObjectForKey:filename];
        }
    }
}


@end
