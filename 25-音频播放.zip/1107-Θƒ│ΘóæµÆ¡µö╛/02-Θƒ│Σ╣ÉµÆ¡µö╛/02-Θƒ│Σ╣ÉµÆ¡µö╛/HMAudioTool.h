//
//  HMAudioTuool.h
//  02-音乐播放
//
//  Created by Anthony on 16/4/10.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HMAudioTool : NSObject

/**
 *  播放音效
 */
+ (void)playAudioWithFilename:(NSString *)filename;

/**
 *  销毁当前正在播放音效
 */
+ (void)disposeAudioWithFilename:(NSString *)filename;

/**
 *  根据音乐文件名称播放音乐
 */
+ (void)playMusicWithFilename:(NSString *)filename;

/**
 *  根据音乐文件名称暂停音乐
 */
+ (void)pauseMusicWithFilename:(NSString *)filename;

/**
 *  根据音乐文件名称停止音乐
 */
+ (void)stopMusicWithFilename:(NSString *)filename;

@end
