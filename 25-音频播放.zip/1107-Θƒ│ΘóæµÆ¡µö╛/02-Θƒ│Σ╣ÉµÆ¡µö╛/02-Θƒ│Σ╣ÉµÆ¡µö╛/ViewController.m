//
//  ViewController.m
//  02-音乐播放
//
//  Created by Anthony on 16/4/10.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>
#import "HMAudioTool.h"

@interface ViewController ()
// 播放
- (IBAction)playMusic:(id)sender;
// 暂停
- (IBAction)pauseMusic:(id)sender;
// 停止
- (IBAction)stopMusic:(id)sender;
// 下一首
- (IBAction)nextMusic:(id)sender;
// 保存所有的音乐
@property (nonatomic, strong) NSArray *musics;

// 记录当前播放音乐的索引
@property (nonatomic, assign) int currentIndex;
@end

@implementation ViewController

#pragma mark - 懒加载
- (NSArray *)musics
{
    if (!_musics) _musics = @[@"最佳损友.mp3", @"心碎了无痕.mp3", @"瓦解.mp3", @"简单爱.mp3"];
    
    return _musics;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    NSLog(@"%s", __func__);
    
//    [self test];
}

- (void)test
{
    // 1.加载音乐文件
    NSURL *url = [[NSBundle mainBundle] URLForResource:@"一千年以后.mp3" withExtension:nil];
    // 2.创建音乐播放器
    AVAudioPlayer *player = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:nil];
    
    // 3.缓冲音乐文件
    [player prepareToPlay];
    
    // 4.播放文件
    [player play];
}

// 播放
- (IBAction)playMusic:(id)sender
{
    [HMAudioTool  playAudioWithFilename:self.musics[self.currentIndex]];
}
// 暂停
- (IBAction)pauseMusic:(id)sender
{
    [HMAudioTool pauseMusicWithFilename:self.musics[self.currentIndex]];
}
// 停止
- (IBAction)stopMusic:(id)sender
{
    [HMAudioTool stopMusicWithFilename:self.musics[self.currentIndex]];
}
// 下一首
- (IBAction)nextMusic:(id)sender
{
    // 1.递增索引
    int nextIndex = self.currentIndex + 1;
    // 2.判断是否越界
    if (nextIndex >= self.musics.count) {
        nextIndex = 0;
    }
    // 3.播放
    // 停止上一首
    [self stopMusic:nil];
    self.currentIndex = nextIndex;
    
    // 开始下一首
    [self playMusic:nil];
    
    
}


@end
