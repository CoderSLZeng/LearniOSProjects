//
//  NJLockView.m
//  04-手势解锁
//
//  Created by Luffy on 15/9/8.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJLockView.h"

@interface NJLockView ()

@property (nonatomic, strong) NSMutableArray *buttons;

@property (nonatomic, assign) CGPoint currentPoint;

@end

@implementation NJLockView

- (NSMutableArray *)buttons
{
    if (_buttons == nil) _buttons = [NSMutableArray array];
    return _buttons;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self == [super initWithFrame:frame]) {
        [self setup];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    if (self == [super initWithCoder:aDecoder]) {
        [self setup];
    }
    return self;
}

- (void)setup
{
    for (int i = 0; i < 9; i++) {
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        
        [btn setBackgroundImage:[UIImage imageNamed:@"gesture_node_normal"] forState:UIControlStateNormal];
        [btn setBackgroundImage:[UIImage imageNamed:@"gesture_node_highlighted"] forState:UIControlStateSelected];
//        [btn setBackgroundColor:[UIColor redColor]];
        [self addSubview:btn];
        
        btn.userInteractionEnabled = NO;
        
        btn.tag = i;
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    for (int i = 0; i < self.subviews.count; i++) {
        
        UIButton *btn = self.subviews[i];

        CGFloat btnW = 74;
        CGFloat btnH = 74;
        CGFloat margin = (self.frame.size.width - (3 * btnW)) / 4;
        int col = i % 3;
        int row = i / 3;
        CGFloat btnX = margin + col * (margin + btnW);
        CGFloat btnY = margin + row * (margin + btnH);
        
        btn.frame = CGRectMake(btnX, btnY, btnW, btnH);
    }
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    CGPoint startPoint = [self getCurrentTouchPoint:touches];
    
    UIButton *btn = [self getCurrentBtnWithPoint:startPoint];
    
    if (btn) {
        btn.selected = YES;
        [self.buttons addObject:btn];
    }
    
    btn.selected = YES;
    
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    CGPoint movePoint = [self getCurrentTouchPoint:touches];
    
    UIButton *btn = [self getCurrentBtnWithPoint:movePoint];
    
    if (btn && btn.selected != YES) {
        btn.selected = YES;
        [self.buttons addObject:btn];
    }
    
    self.currentPoint = movePoint;
    
    [self setNeedsDisplay];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSMutableString *result = [NSMutableString string];
    for (UIButton *btn in self.buttons) {
        [result appendFormat:@"%d", btn.tag];
    }
    NSLog(@"result = %@", result);
    
    [self.buttons makeObjectsPerformSelector:@selector(setSelected:) withObject:@(NO)];
    
    [self.buttons removeAllObjects];
    [self setNeedsDisplay];
    
    self.currentPoint = CGPointZero;
    
}

- (CGPoint)getCurrentTouchPoint:(NSSet *)touches
{
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:touch.view];
    return point;
}

- (UIButton *)getCurrentBtnWithPoint:(CGPoint)Point
{
    for (UIButton *btn in self.subviews) {
        if (CGRectContainsPoint(btn.frame, Point)) {
            return btn;
        }
    }
    return nil;
}

- (void)drawRect:(CGRect)rect
{
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    CGContextClearRect(ctx, rect);
    
    for (int i = 0; i < self.buttons.count; i++) {
        UIButton *btn = self.buttons[i];
        
        if (0 == i) {
            CGContextMoveToPoint(ctx, btn.center.x, btn.center.y);
        } else {
            CGContextAddLineToPoint(ctx, btn.center.x, btn.center.y);
        }
    }

        if (self.buttons.count != 0) {
            CGContextAddLineToPoint(ctx, self.currentPoint.x, self.currentPoint.y);
        }
        
        
//    [[UIColor greenColor] set];
    
    [[UIColor colorWithRed:18/255.0 green:102/255.0 blue:72/255.0 alpha:0.5] set];
    CGContextSetLineWidth(ctx, 10);
    CGContextStrokePath(ctx);
}

@end
