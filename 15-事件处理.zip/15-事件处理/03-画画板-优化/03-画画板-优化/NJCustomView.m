//
//  NJCustomView.m
//  03-画画板-优化
//
//  Created by Luffy on 15/9/8.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJCustomView.h"

@interface NJCustomView ()

@property (nonatomic, strong) NSMutableArray *paths;

@end

@implementation NJCustomView

#pragma mark - 懒加载
- (NSMutableArray *)paths
{
    if (_paths == nil) _paths = [NSMutableArray array];
    return _paths;
}

// 开始触摸
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    CGPoint startPoint = [touch locationInView:touch.view];
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    
    [path setLineCapStyle:kCGLineCapRound];
    [path setLineJoinStyle:kCGLineJoinRound];
    [path setLineWidth:8];
    
    [path moveToPoint:startPoint];
    
    [self.paths addObject:path];
}

// 移动
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    CGPoint currentPoint = [touch locationInView:touch.view];
    
    UIBezierPath *currentPath = [self.paths lastObject];
    
    [currentPath addLineToPoint:currentPoint];
    
    [self setNeedsDisplay];
}

// 停止
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self touchesMoved:touches withEvent:event];
}

// 画线
- (void)drawRect:(CGRect)rect
{
    [[UIColor redColor] set];
    for (UIBezierPath *path in self.paths) {
        [path stroke];
    }
}

- (void)clearView
{
    [self.paths removeAllObjects];
    [self setNeedsDisplay];
}

- (void)backView
{
    [self.paths removeLastObject];
    [self setNeedsDisplay];
}

@end
