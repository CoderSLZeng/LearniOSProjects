//
//  ViewController.m
//  03-画画板-优化
//
//  Created by Luffy on 15/9/8.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "NJCustomView.h"
#import "UIImage+CaptureView.h"
#import "MBProgressHUD+NJ.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet NJCustomView *customViiew;

@end

@implementation ViewController

- (IBAction)clearView:(UIButton *)sender {
    
    [self.customViiew clearView];
}

- (IBAction)backView:(UIButton *)sender {
    [self.customViiew backView];
}
- (IBAction)saveView:(UIButton *)sender {
    UIImage *newImage = [UIImage captureImageWithView:self.customViiew];
    
    UIImageWriteToSavedPhotosAlbum(newImage, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    if (error) {
        [MBProgressHUD showError:@"保存失败"];
    } else {
        [MBProgressHUD showSuccess:@"保存成功"];
    }
}

@end
