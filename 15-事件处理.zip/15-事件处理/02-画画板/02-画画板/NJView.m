//
//  NJView.m
//  02-画画板
//
//  Created by Luffy on 15/9/7.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJView.h"

@interface NJView()

@property (nonatomic, strong) NSMutableArray *totalPoints;

@end

@implementation NJView

#pragma mark - 懒加载
- (NSMutableArray *)totalPoints
{
    if (_totalPoints == nil) {
        _totalPoints = [NSMutableArray array];
    }
    return _totalPoints;
}

// 开始触摸
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    // 1.获取手指对应的UITouch对象
    UITouch *touch = [touches anyObject];
    // 2.通过UITouch对象获取手指触摸的位置
    CGPoint startPoint = [touch locationInView:touch.view];
    // 3.将手指触摸的点存储到数组中
    
    
    // 3.创建一个小数组，用于保存当前路径所有的店
    NSMutableArray *subPoints = [NSMutableArray array];
    // 4.将手指触摸的起点存储到小数组中
    [subPoints addObject:[NSValue valueWithCGPoint:startPoint]];
    // 5.将小数组存储到到大数组中
    [self.totalPoints addObject:subPoints];
}

// 移动
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    // 1.获取手指对应的UITouch对象
    UITouch *touch = [touches anyObject];
    // 2.通过UITouch对象获取手指触摸的位置
    CGPoint movePoint = [touch locationInView:touch.view];
    // 3.将手指移动时触摸的点存储到数组中
    
    
    // 3.从大数组中取出当前路径对应的小数据
    NSMutableArray *subPoints = [self.totalPoints lastObject];
    // 4.将手指移动时触摸的点存储到小数组中
    [subPoints addObject:[NSValue valueWithCGPoint:movePoint]];
    // 5.调用darwRect方法重绘制视图
    [self setNeedsDisplay];
    
}

// 离开View(停止触摸)
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    // 1.获取手指对应的UITouch对象
    UITouch *touch = [touches anyObject];
    // 2.通过UITouch对象获取手指触摸的位置
    CGPoint endPoint = [touch locationInView:touch.view];
    // 3.将手指离开时触摸的点存储到数组中
    
    // 3.从大数组中取出当前路径对应的小数据
    NSMutableArray *subPoints = [self.totalPoints lastObject];
    // 4.将手指移动时触摸的店存储到小数组中
    [subPoints addObject:[NSValue valueWithCGPoint:endPoint]];
    // 5.调用darwRect方法重绘视图
    [self setNeedsDisplay];
}

// 画线
- (void)drawRect:(CGRect)rect
{
    // 1.获取上下文
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    // 遍历大数组，取出所的小数组(每一个小数组代表一条线段)
    for (NSMutableArray *subPoints in self.totalPoints) {
        // 遍历小数组，取出小数组中所有的点
        for (int index = 0 ; index < subPoints.count; index++) {
            // 1.取出小数组中的每一个点
            CGPoint point = [subPoints[index] CGPointValue];
            // 2.绘制线段
            if (0 == index) {
                // 2.1.设置线段的起点
                CGContextMoveToPoint(ctx, point.x, point.y);
            }else
            {
                // 2.2.设置线段的重点
                CGContextAddLineToPoint(ctx, point.x, point.y);
            }
        }
    }
    
    CGContextSetLineCap(ctx, kCGLineCapRound);
    CGContextSetLineJoin(ctx, kCGLineJoinRound);
    CGContextSetLineWidth(ctx, 10);
    
    // 3.渲染
    CGContextStrokePath(ctx);
}

- (void)clearView
{
    [self.totalPoints removeAllObjects];
    [self setNeedsDisplay];
}

- (void)blackView
{
    [self.totalPoints removeLastObject];
    [self setNeedsDisplay];
}





@end
