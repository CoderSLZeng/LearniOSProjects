//
//  ViewController.m
//  04-图片查看器
//
//  Created by Luffy on 15/7/17.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

/**
 开发步骤
 1.先确定视图界面元素的内容
 2.编写代码完成视图界面的布局
 3.实现界面里面的功能
 */


#import "ViewController.h"

@interface ViewController ()

/** 步骤1 */
@property (nonatomic, strong) UILabel *noLabel; // 序列
@property (nonatomic, strong) UIImageView *iconImage; // 图片
@property (nonatomic, strong) UILabel *descLabel; // 描述
@property (nonatomic, strong) UIButton *leftButton; // 左箭头
@property (nonatomic, strong) UIButton *rightButton; // 右箭头

@property (nonatomic, assign) int index; // 当前显示的照片索引

@property (nonatomic, strong) NSArray *imageList; // 图片信息的数组
@end

@implementation ViewController

/**
 懒加载(延时加载)，通过getter方法实现
 效果：让对象在最需要的时候创建
 */
- (NSArray *)imageList
{
    NSLog(@"加载图像信息");
    if (_imageList == nil) {
        NSLog(@"实例化图像信息");
        // "包" NSBudle
        NSString *path = [[NSBundle mainBundle] pathForResource:@"imageList" ofType:@"plist"];
        NSLog(@"%@", path);
        
        _imageList = [NSArray arrayWithContentsOfFile:path];
        NSLog(@"%@", _imageList);
        
    }
    return _imageList;
}

/** 序号 */
- (UILabel *)noLabel
{
    if (_noLabel == nil) {
        _noLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 20, self.view.bounds.size.width, 40)];
        _noLabel.textAlignment = NSTextAlignmentCenter; // 文本居中对齐
        [self.view addSubview:_noLabel]; // 添加到视图
    }
    return _noLabel;
}

/** 图片 */
- (UIImageView *)iconImage
{
    if (_imageList == nil) {
        CGFloat imageW = 200, imageH = 200; // 图片的宽和高的值
        CGFloat imageY = CGRectGetMaxY(self.noLabel.frame) + 20; // 计算出图片的Y点值
        CGFloat imageX = (self.noLabel.bounds.size.width - imageW) * 0.5; // 计算出图片的X点值
        _iconImage = [[UIImageView alloc] initWithFrame:CGRectMake(imageX, imageY, imageW, imageH)];
        [self.view addSubview:_iconImage];
    }
    return _iconImage;
}

/** 描述 */
- (UILabel *)descLabel
{
    if (_descLabel == nil) {
        CGFloat descY = CGRectGetMaxY(self.iconImage.frame) + 20; // 计算出描述
        _descLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, descY, self.view.bounds.size.width, 100)];
        _descLabel.textAlignment = NSTextAlignmentCenter;
        
        // 需要Label要有“足够的高度”，不限制显示的行数
        _descLabel.numberOfLines = 0;
        [self.view addSubview:_descLabel];
    }
    return _descLabel;
}

- (UIButton *)leftButton
{
    if (_leftButton == nil) {
        _leftButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 40, 40)]; // 设置箭头按钮的大小
        CGFloat centerY = self.iconImage.center.y; // 计算出左箭头按钮的中心Y点值（等于图片中心Y点值）
        CGFloat centerX = self.iconImage.frame.origin.x * 0.5;
        _leftButton.center = CGPointMake(centerX, centerY);
        [_leftButton setImage:[UIImage imageNamed:@"left_normal"] forState:UIControlStateNormal];
        [_leftButton setImage:[UIImage imageNamed:@"left_highlighted"] forState:UIControlStateHighlighted];
        
        [self.view addSubview:_leftButton];
        
        _leftButton.tag = -1;
        
        // 设置左箭头按钮的监听器
        [_leftButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _leftButton;
}

- (UIButton *)rightButton
{
    if (_rightButton == nil) {
        // 右箭头按钮
        _rightButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 40, 40)]; // 设置箭头按钮的大小
        CGFloat centerY = self.iconImage.center.y; // 计算出左箭头按钮的中心Y点值（等于图片中心Y点值）
        CGFloat centerX = self.iconImage.frame.origin.x * 0.5;
        _rightButton.center = CGPointMake(self.view.bounds.size.width - centerX, centerY);
        [_rightButton setImage:[UIImage imageNamed:@"right_normal"] forState:UIControlStateNormal];
        [_rightButton setImage:[UIImage imageNamed:@"right_highlighted"] forState:UIControlStateHighlighted];
        
        [self.view addSubview:_rightButton];
        
        _rightButton.tag  = 1;
        
        // 设置右箭头按钮的监听器
        [_rightButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _rightButton;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 显示图片
    [self showPhotoInfo];
}

/** 代码优化
 让重复的代码出现一次
 */

- (void)showPhotoInfo
{
    // 设置序号
    self.noLabel.text = [NSString stringWithFormat:@"%i/%i", self.index + 1, 5];
    
    // 设置图片和描述
    self.iconImage.image = [UIImage imageNamed:self.imageList[self.index][@"imageName"]];
    self.descLabel.text = self.imageList[self.index][@"desc"];

    self.leftButton.enabled = (self.index != 0);
    self.rightButton.enabled = (self.index != 4);

}

- (void)clickButton:(UIButton *)button
{
    self.index += (int)button.tag;

    [self showPhotoInfo];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

