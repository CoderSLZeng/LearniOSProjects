//
//  ViewController.m
//  04-图片查看器
//
//  Created by Luffy on 15/7/17.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

/**
 开发步骤
 1.先确定视图界面元素的内容
 2.编写代码完成视图界面的布局
 3.实现界面里面的功能
 */


#import "ViewController.h"

@interface ViewController ()

/** 步骤1 */
@property (nonatomic, strong) UILabel *noLabel; // 序列
@property (nonatomic, strong) UIImageView *iconImage; // 图片
@property (nonatomic, strong) UILabel *descLabel; // 描述
@property (nonatomic, strong) UIButton *leftButton; // 左箭头
@property (nonatomic, strong) UIButton *rightButton; // 右箭头

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    /** 步骤2 */
    // 序号
    _noLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 20, self.view.bounds.size.width, 40)];
    _noLabel.text = @"1/5"; // 文本内容
    _noLabel.textAlignment = NSTextAlignmentCenter; // 文本居中对齐
    [self.view addSubview:_noLabel]; // 添加到视图
    
    
    // 图片
    CGFloat imageW = 200, imageH = 200; // 图片的宽和高的值
    CGFloat imageY = CGRectGetMaxY(self.noLabel.frame) + 20; // 计算出图片的Y点值
    CGFloat imageX = (self.noLabel.bounds.size.width - imageW) * 0.5; // 计算出图片的X点值

    _iconImage = [[UIImageView alloc] initWithFrame:CGRectMake(imageX, imageY, imageW, imageH)];
    
    _iconImage.image = [UIImage imageNamed:@"biaoqingdi"];
    
    [self.view addSubview:_iconImage];
    
    // 描述
    CGFloat descY = CGRectGetMaxY(self.iconImage.frame) + 20; // 计算出描述
    _descLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, descY, self.view.bounds.size.width, 100)];
    
    _descLabel.text = @"神马表情";
    _descLabel.textAlignment = NSTextAlignmentCenter;
    
    [self.view addSubview:_descLabel];
    
    // 左箭头按钮
    _leftButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 40, 40)]; // 设置箭头按钮的大小
    CGFloat centerY = self.iconImage.center.y; // 计算出左箭头按钮的中心Y点值（等于图片中心Y点值）
    CGFloat centerX = self.iconImage.frame.origin.x * 0.5;
    _leftButton.center = CGPointMake(centerX, centerY);
    [_leftButton setImage:[UIImage imageNamed:@"left_normal"] forState:UIControlStateNormal];
    [_leftButton setImage:[UIImage imageNamed:@"left_highlighted"] forState:UIControlStateHighlighted];
    
    [self.view addSubview:_leftButton];
    
    // 右箭头按钮
    _rightButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 40, 40)]; // 设置箭头按钮的大小
    _rightButton.center = CGPointMake(self.view.bounds.size.width - centerX, centerY);
    [_rightButton setImage:[UIImage imageNamed:@"right_normal"] forState:UIControlStateNormal];
    [_rightButton setImage:[UIImage imageNamed:@"right_highlighted"] forState:UIControlStateHighlighted];
    
    [self.view addSubview:_rightButton];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

