//
//  ViewController.m
//  02-按钮操作
//
//  Created by Luffy on 15/7/16.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

typedef enum {
    kMovingDirTop = 10,
    kMovingDirBottom,
    kMovingDirLeft,
    kMovingDirRight,
} kMovingDir;

#define kMovingDelta 20.0f
@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIButton *iconButton;
// @property (nonatomic, assign) CGFloat delta; // 每次形变的累加
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIButton *btn1 = [UIButton buttonWithType:UIButtonTypeContactAdd];
    btn1.center = CGPointMake(20, 40);
    [self.view addSubview:btn1];
    
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(110, 200, 100, 100)];
    self.iconButton = btn;
    btn.backgroundColor = [UIColor redColor];
    
    // 设置背景图片
    [btn setBackgroundImage:[UIImage imageNamed:@"btn_01"] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:@"btn_02"] forState:UIControlStateHighlighted];
    
    // 设置文字
    [btn setTitle:@"点我啊" forState:UIControlStateNormal];
    [btn setTitle:@"摸我干啥" forState:UIControlStateNormal];
    
    // 设置文字的颜色
    [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor blueColor] forState:UIControlStateHighlighted];
    
    // 设置文字的垂直对齐
    btn.contentVerticalAlignment = UIControlContentVerticalAlignmentBottom;
    
    // 将按钮添加到视图
    [self.view addSubview:btn];
    
    }


#pragma mark - 按钮操作
/**
 代码优化
 1. 让重复的代码只出现一次
 */
- (IBAction)move:(UIButton *)button {
   
    
//    /** 形变 */
    
//    self.delta = -20;
    // 需要增加一个成员变量做参数
//    CGAffineTransform transform = CGAffineTransformMakeTranslation( 0, self.delta);
//    self.iconButton.transform = transform;
//    // 优化上面代码，直接更改结构体的成员变量
//    self.iconButton.transform = CGAffineTransformMakeTranslation(0, self.delta);
    
    CGFloat dx = 0, dy = 0;
    
    if (button.tag == kMovingDirTop || button.tag == kMovingDirBottom) {
        dy = (button.tag == kMovingDirTop) ? -kMovingDelta : kMovingDelta;
    }
    if (button.tag == kMovingDirLeft || button.tag == kMovingDirRight) {
        dx = (button.tag == kMovingDirLeft) ? -kMovingDelta : kMovingDelta;
    }
    
//    switch (button.tag) {
//        case kMovingDirTop:
//            dy = -kMovingDelta;
//            break;
//        case kMovingDirBottom:
//            dy = kMovingDelta;
//            break;
//        case kMovingDirLeft:
//            dx = -kMovingDelta;
//            break;
//        case kMovingDirRight:
//            dx = kMovingDelta;
//            break;
//    }

    self.iconButton.transform = CGAffineTransformTranslate(self.iconButton.transform, dx, dy);
    NSLog(@"%@", NSStringFromCGAffineTransform(self.iconButton.transform));
    
}

- (void)demo:(UIButton *)button
{
        CGRect frame = self.iconButton.frame;
    
        switch (button.tag) {
            case kMovingDirTop:
                frame.origin.y -= kMovingDelta;
                break;
            case kMovingDirBottom:
                frame.origin.y += kMovingDelta;
                break;
            case kMovingDirLeft:
                frame.origin.x -= kMovingDelta;
                break;
            case kMovingDirRight:
                frame.origin.x += kMovingDelta;
                break;
    
        }
        
        self.iconButton.frame = frame;
}

/** 图片缩放 */
- (IBAction)zoom:(UIButton *)button {

    /**
    CGRect bounds = self.iconButton.bounds;
    if (button.tag) {
        bounds.size.height += kMovingDelta;
        bounds.size.width += kMovingDelta;
    } else {
        bounds.size.height -= kMovingDelta;
        bounds.size.width -= kMovingDelta;
    } */
    
    /** 代码优化 */
    CGFloat scale = (button.tag) ? 1.2 : 0.8;
    
    // 首尾式动画
    [UIView beginAnimations:nil context:nil]; // 动画开始
    [UIView setAnimationDuration:1.0]; // 设置动画时长（延时）
    
//    self.iconButton.bounds = bounds;
    self.iconButton.transform = CGAffineTransformScale(self.iconButton.transform, scale, scale);
    NSLog(@"%@", NSStringFromCGAffineTransform(self.iconButton.transform));

    [UIView commitAnimations]; // 动画结束
}

/** 旋转 */
- (IBAction)rotate:(UIButton *)button {
    CGFloat angle = (button.tag) ? -M_PI_4 : M_PI_4;
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:2.0];
    
    self.iconButton.transform = CGAffineTransformRotate(self.iconButton.transform, angle);
    
    [UIView commitAnimations];
    
    NSLog(@"%@",NSStringFromCGAffineTransform(self.iconButton.transform));
    NSLog(@"%@", NSStringFromCGRect(self.iconButton.frame));
    
}

/** frame */
- (IBAction)top:(UIButton *)button {
    CGRect frame = self.iconButton.frame;
    frame.origin.y -= 20;
    self.iconButton.frame = frame;
    
}

- (IBAction)bottom:(UIButton *)button {
    CGRect frame = self.iconButton.frame;
    frame.origin.y += 20;
    self.iconButton.frame = frame;
    
}
- (IBAction)left:(UIButton *)button {
    CGRect frame = self.iconButton.frame;
    frame.origin.x -= 20;
    self.iconButton.frame = frame;
    
}
- (IBAction)right:(UIButton *)button {
    CGRect frame = self.iconButton.frame;
    frame.origin.x += 20;
    self.iconButton.frame = frame;
    
}


@end
