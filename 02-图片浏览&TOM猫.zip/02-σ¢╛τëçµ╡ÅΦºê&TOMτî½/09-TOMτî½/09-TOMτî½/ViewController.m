//
//  ViewController.m
//  09-TOM猫
//
//  Created by Luffy on 15/7/18.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *tom;

@end

@implementation ViewController

/** 
 代码重构
 */
- (void)tomAnimationWithName:(NSString *)name AndCount:(NSInteger)count
{
    
    NSLog(@"%s", __func__);
    
    // 如果正在动画，直接退出
    if ([self.tom isAnimating]) return;
    
    NSMutableArray *arrayM = [NSMutableArray array];
    
    // 添加动画播放的图片
    for (int i=0; i<count; i++) {
        // 图片名称
        NSString *imageName = [NSString stringWithFormat:@"%@_%02d.jpg", name, i];
        NSLog(@"%@", imageName);
        
        UIImage *image = [UIImage imageNamed:imageName];
        [arrayM addObject:image];
        
        // 设置动画数组
        self.tom.animationImages = arrayM;
    }
    // 动画重复次数
    self.tom.animationRepeatCount = 1;
    // 动画时长
    self.tom.animationDuration = self.tom.animationImages.count * 0.075;
    
    // 开始动画
    [self.tom startAnimating];
}

- (IBAction)knockout {
    NSLog(@"%s", __func__);
    
    [self tomAnimationWithName:@"knockout" AndCount:81];
}


- (IBAction)eatBird {
    
    NSLog(@"%s", __func__);
    
    [self tomAnimationWithName:@"eat" AndCount:40];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
