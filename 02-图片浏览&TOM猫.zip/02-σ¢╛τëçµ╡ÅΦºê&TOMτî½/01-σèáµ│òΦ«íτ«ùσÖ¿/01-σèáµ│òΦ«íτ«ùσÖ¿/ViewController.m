//
//  ViewController.m
//  01-加法计算器
//
//  Created by Luffy on 15/7/17.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (nonatomic, strong) UITextField *num1;
@property (nonatomic, strong) UILabel *jia;
@property (nonatomic, strong) UITextField *num2;
@property (nonatomic, strong) UILabel *dengyu;
@property (nonatomic, strong) UILabel *result;
@property (nonatomic, strong) UIButton *jisuan;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    CGFloat num1W = self.view.frame.size.width * 0.2;
    _num1 = [[UITextField alloc] initWithFrame:CGRectMake(10, 20, num1W, 40)];
    [_num1 setBackgroundColor:[UIColor redColor]];
    [self.view addSubview:_num1];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
