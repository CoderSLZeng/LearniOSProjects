//
//  NJContactCell.m
//  01-私人通讯录
//
//  Created by Luffy on 15/8/28.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJContactCell.h"
#import "NJContactModel.h"

@interface NJContactCell ()

@property (nonatomic, strong) UIView *divider;

@end

@implementation NJContactCell

+ (instancetype)contactCellWithTableView:(UITableView *)tableView
{
    static NSString *identifier = @"contacts";
    
    NJContactCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    return cell;
}

- (void)setContact:(NJContactModel *)contact
{
    _contact = contact;
    
    self.textLabel.text = _contact.name;
    self.detailTextLabel.text = _contact.phoneNum;
}

- (void)awakeFromNib {
    
    UIView *view = [[UIView alloc] init];
    view.backgroundColor = [UIColor blackColor];
    view.alpha = 0.5;
    self.divider = view;

    [self.contentView addSubview:view];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    CGFloat x = 0;
    CGFloat w = self.bounds.size.width;
    CGFloat h = 1;
    CGFloat y = self.bounds.size.height - h;
    self.divider.frame = CGRectMake(x, y, w, h);

}


@end
