//
//  NJEidtViewController.m
//  01-私人通讯录
//
//  Created by Luffy on 15/8/27.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJEidtViewController.h"
#import "NJContactModel.h"

@interface NJEidtViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameField;
@property (weak, nonatomic) IBOutlet UITextField *phoneNumField;
@property (weak, nonatomic) IBOutlet UIButton *saveBtn;

/**
 *  编辑按钮点击时间
 */
- (IBAction)editBtnOnClick:(UIBarButtonItem *)sender;

/**
 *  保存按钮点击时间
 */
- (IBAction)saveBtnOnClick:(UIButton *)sender;

@end

@implementation NJEidtViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.nameField.text = _contact.name;
    self.phoneNumField.text = _contact.phoneNum;
    
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center addObserver:self selector:@selector(textChange) name:UITextFieldTextDidChangeNotification object:self.nameField];
    [center addObserver:self selector:@selector(textChange) name:UITextFieldTextDidChangeNotification object:self.phoneNumField];
    
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)textChange
{
    self.saveBtn.enabled = (self.nameField.text.length > 0 && self.phoneNumField.text.length > 0);
}



- (IBAction)editBtnOnClick:(UIBarButtonItem *)sender {
    
    if (self.nameField.enabled) {
        self.nameField.enabled = NO;
        self.phoneNumField.enabled = NO;
        
        self.saveBtn.hidden = YES;
        
        [self.view endEditing:YES];
        
        sender.title = @"编辑";
        
        self.nameField.text = _contact.name;
        self.phoneNumField.text = _contact.phoneNum;
    }else {
        self.nameField.enabled = YES;
        self.phoneNumField.enabled = YES;
        self.saveBtn.hidden =  NO;
        
        [self.phoneNumField becomeFirstResponder];
        sender.title = @"取消";
    }
}

- (IBAction)saveBtnOnClick:(UIButton *)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
    self.contact.name = self.nameField.text;
    self.contact.phoneNum = self.phoneNumField.text;
    
    if ([self.delegate respondsToSelector:@selector(eidtViewControllerDidSaveBtnOnClik:WithContact:)]) {
        [self.delegate eidtViewControllerDidSaveBtnOnClik:self WithContact:self.contact];
    }
}
@end
