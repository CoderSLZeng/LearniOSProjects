//
//  NJEidtViewController.h
//  01-私人通讯录
//
//  Created by Luffy on 15/8/27.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>
@class NJEidtViewController, NJContactModel;

@protocol NJEidtViewControllerDelegate <NSObject>

- (void)eidtViewControllerDidSaveBtnOnClik:(NJEidtViewController *)eidtViewController WithContact:(NJContactModel *)contact;

@end

@interface NJEidtViewController : UIViewController

@property (nonatomic, strong) NJContactModel *contact;

@property (weak, nonatomic) id<NJEidtViewControllerDelegate> delegate;

@end
