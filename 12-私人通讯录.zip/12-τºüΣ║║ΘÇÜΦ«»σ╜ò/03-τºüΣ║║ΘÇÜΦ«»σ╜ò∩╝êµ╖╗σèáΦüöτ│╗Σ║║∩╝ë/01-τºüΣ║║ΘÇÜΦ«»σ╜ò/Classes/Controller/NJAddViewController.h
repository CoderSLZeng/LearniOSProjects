//
//  NJAddViewController.h
//  01-私人通讯录
//
//  Created by Luffy on 15/8/27.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>
@class NJAddViewController, NJContactModel;

@protocol NJAddViewControllerDelegate <NSObject>

- (void)addViewControllerDidAddBtnOnClick:(NJAddViewController *)addViewController WithContact:(NJContactModel *)contact;

@end

@interface NJAddViewController : UIViewController

@property (weak, nonatomic) id<NJAddViewControllerDelegate> delegate;

@end
