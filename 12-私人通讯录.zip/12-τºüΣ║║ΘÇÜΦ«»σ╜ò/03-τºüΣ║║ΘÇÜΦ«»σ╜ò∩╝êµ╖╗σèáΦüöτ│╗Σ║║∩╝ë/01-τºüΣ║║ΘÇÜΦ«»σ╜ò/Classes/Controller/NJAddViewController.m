//
//  NJAddViewController.m
//  01-私人通讯录
//
//  Created by Luffy on 15/8/27.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJAddViewController.h"
#import "NJContactModel.h"

@interface NJAddViewController ()
/**
 *  姓名
 */
@property (weak, nonatomic) IBOutlet UITextField *nameField;

/**
 *  手机号码
 */
@property (weak, nonatomic) IBOutlet UITextField *phoneNumField;

/**
 *  添加
 */
@property (weak, nonatomic) IBOutlet UIButton *addBtn;

/**
 *  点击了添加按钮
 */
- (IBAction)addBtnOnClick:(UIButton *)sender;
@end

@implementation NJAddViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 1.获取通知中心
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    
    // 2.注册监听
    [center addObserver:self selector:@selector(textChange) name:UITextFieldTextDidChangeNotification object:self.nameField];
    [center addObserver:self selector:@selector(textChange) name:UITextFieldTextDidChangeNotification object:self.phoneNumField];

}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)textChange {
    
    self.addBtn.enabled = (self.nameField.text.length > 0 && self.phoneNumField.text.length > 0);
}

- (IBAction)addBtnOnClick:(UIButton *)sender {
    
    //      NSLog(@"%s", __func__);
    [self.navigationController popViewControllerAnimated:YES];
    
    // 1.获取用户输入的数据
    NSString *name = self.nameField.text;
    NSString *phoneNum = self.phoneNumField.text;
    
    // 2.传递模型
    NJContactModel *c = [[NJContactModel alloc] init];
    c.name = name;
    c.phoneNum = phoneNum;
    
    // 3.通知代理
    if ([self.delegate respondsToSelector:@selector(addViewControllerDidAddBtnOnClick:WithContact:)]) {
        [self.delegate addViewControllerDidAddBtnOnClick:self WithContact:c];
    }
    
}
@end
