//
//  NJContactViewController.m
//  01-私人通讯录
//
//  Created by Luffy on 15/8/26.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJContactViewController.h"
#import "NJAddViewController.h"
#import "NJContactModel.h"

@interface NJContactViewController () <UIActionSheetDelegate, NJAddViewControllerDelegate>
/**
 *  点击注销按钮
 */
- (IBAction)logout:(UIBarButtonItem *)sender;
/**
 *  可以保存数据的数组
 */
@property (nonatomic, strong) NSMutableArray *contacts;

@end

@implementation NJContactViewController

#pragma mark - 懒加载
- (NSMutableArray *)contacts
{
    if (_contacts == nil) _contacts = [NSMutableArray array];
    return _contacts;
}

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
//      NSLog(@"%s", __func__);
    
    NJAddViewController *addVc = segue.destinationViewController; // 获取目标控制器
    addVc.delegate = self; // 设置代理
}

- (IBAction)logout:(UIBarButtonItem *)sender {
    UIActionSheet *sheet = [[UIActionSheet alloc] initWithTitle:@"确定要注销" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"确定" otherButtonTitles: nil];
    [sheet showInView:self.view];
}

#pragma mark - UIActionSheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (0 == buttonIndex) {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

#pragma mark - NJAddViewControllerDelegate
- (void)addViewControllerDidAddBtnOnClick:(NJAddViewController *)addViewController WithContact:(NJContactModel *)contact
{
    NSLog(@"添加联系人");
    
    [self.contacts addObject:contact];
    
    [self.tableView reloadData];
}

#pragma mark - 数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.contacts.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"contacts";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
    
    NJContactModel *c = self.contacts[indexPath.row];
    
    cell.textLabel.text = c.name;
    cell.detailTextLabel.text = c.phoneNum;
    
    NSLog(@"%@ %@", cell.textLabel, cell.detailTextLabel);
    
    return cell;
    
}

@end
