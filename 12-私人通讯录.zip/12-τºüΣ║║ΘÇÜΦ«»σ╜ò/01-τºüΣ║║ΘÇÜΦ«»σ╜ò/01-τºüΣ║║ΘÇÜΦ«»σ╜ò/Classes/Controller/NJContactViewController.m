//
//  NJContactViewController.m
//  01-私人通讯录
//
//  Created by Luffy on 15/8/26.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJContactViewController.h"

@interface NJContactViewController () <UIActionSheetDelegate>
- (IBAction)logout:(UIBarButtonItem *)sender;

@end

@implementation NJContactViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (IBAction)logout:(UIBarButtonItem *)sender {
    UIActionSheet *sheet = [[UIActionSheet alloc] initWithTitle:@"确定要注销" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"确定" otherButtonTitles: nil];
    [sheet showInView:self.view];
}

#pragma mark - UIActionSheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (0 == buttonIndex) {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

@end
