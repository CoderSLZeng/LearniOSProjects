//
//  NJLoginViewController.m
//  01-私人通讯录
//
//  Created by Luffy on 15/8/26.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJLoginViewController.h"

@interface NJLoginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *accountField;
@property (weak, nonatomic) IBOutlet UITextField *pwdField;
@property (weak, nonatomic) IBOutlet UISwitch *remPwdSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *autoLoginSwitch;

@property (weak, nonatomic) IBOutlet UIButton *loginButton;

- (IBAction)remPwdChange:(id)sender;

- (IBAction)autoLoginChange:(id)sender;
@end

@implementation NJLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 注册通知
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    
    [center addObserver:self selector:@selector(textChange) name:UITextFieldTextDidChangeNotification object:self.accountField];
    
    [center addObserver:self selector:@selector(textChange) name:UITextFieldTextDidChangeNotification object:self.pwdField];
}

- (void)textChange
{
    /**
    // 判断输入框是否有字符
    if (self.accountField.text.length > 0 && self.pwdField.text.length > 0)
    {
        self.loginButton.enabled = YES;
    } else {
        self.loginButton.enabled = NO;
    }
     */
    
    self.loginButton.enabled = (self.accountField.text.length > 0 && self.pwdField.text.length > 0);
}


- (IBAction)remPwdChange:(id)sender {
    
    if (self.remPwdSwitch.isOn == 0) {
        [self.autoLoginSwitch setOn:NO animated:YES];
    }
    
}
- (IBAction)autoLoginChange:(id)sender {
    if (self.autoLoginSwitch.isOn) {
        [self.remPwdSwitch setOn:YES animated:YES];
    }
}

@end
