//
//  NJLoginViewController.m
//  01-私人通讯录
//
//  Created by Luffy on 15/8/26.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJLoginViewController.h"
#import "MBProgressHUD+NJ.h"


@interface NJLoginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *accountField; // 输入账号
@property (weak, nonatomic) IBOutlet UITextField *pwdField; // 输入密码
@property (weak, nonatomic) IBOutlet UISwitch *remPwdSwitch; // 记住密码
@property (weak, nonatomic) IBOutlet UISwitch *autoLoginSwitch; // 自动登录

@property (weak, nonatomic) IBOutlet UIButton *loginButton; // 登录按钮

- (IBAction)remPwdChange:(id)sender; // 点击记住密码

- (IBAction)autoLoginChange:(id)sender; // 点击自动登录
- (IBAction)loginOnClick:(id)sender;
@end

@implementation NJLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 拿到通知中心
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    // 注册监听
    [center addObserver:self selector:@selector(textChange) name:UITextFieldTextDidChangeNotification object:self.accountField];
    
    [center addObserver:self selector:@selector(textChange) name:UITextFieldTextDidChangeNotification object:self.pwdField];
}

- (void)textChange
{
    /**
    // 判断输入框是否有字符
    if (self.accountField.text.length > 0 && self.pwdField.text.length > 0)
    {
        self.loginButton.enabled = YES;
    } else {
        self.loginButton.enabled = NO;
    }
     */
    
    self.loginButton.enabled = (self.accountField.text.length > 0 && self.pwdField.text.length > 0);
}


- (IBAction)remPwdChange:(id)sender {
    // 判断是否记住密码
    if (self.remPwdSwitch.isOn == 0) {
        [self.autoLoginSwitch setOn:NO animated:YES];
    }
    
}
- (IBAction)autoLoginChange:(id)sender {
    // 判断是否自动登录
    if (self.autoLoginSwitch.isOn) {
        [self.remPwdSwitch setOn:YES animated:YES];
    }
}

- (IBAction)loginOnClick:(id)sender {
    
//      NSLog(@"%s", __func__);
    // 添加蒙版禁止用户操作，并且提示用户正在登录
    [MBProgressHUD showMessage:@"正在拼命加载中..."];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
       /*
        // 1.判断账号密码是否正确
        if ([self.accountField.text isEqualToString:@"lnj"] && [self.pwdField.text isEqualToString:@"123"]) {
            // 2.如果正确，跳转到联系人界面（手动执行segue）
            [self performSegueWithIdentifier:@"login2contatc" sender:nil];
            
            // 3.登录成功后移除蒙版
            [MBProgressHUD hideHUD];
            
        } else {
            // 提示用户账号或者密码不正确
          //  UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"账户或者密码不正确" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
          //  [alert show];
            
            [MBProgressHUD hideHUD];
            [MBProgressHUD showError:@"账号或者密码不正确"];
        }
        */
        
        if (![self.accountField.text isEqualToString:@"lnj"]) {
            [MBProgressHUD hideHUD];
            [MBProgressHUD showError:@"账户不正确"];
            return;
        }
        
        if (![self.pwdField.text isEqualToString:@"123"]) {
            [MBProgressHUD hideHUD];
            [MBProgressHUD showError:@"密码不正确"];
            return;
        }
        
        [MBProgressHUD hideHUD];
        [self performSegueWithIdentifier:@"login2contatc" sender:nil];
    });
}


// 在segue跳转之前调用，会传入performSegueWithIndentifier方法闯将好segue对象
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    NSLog(@"%@ %@ %@", segue.identifier, segue.sourceViewController, segue.destinationViewController);
    
    // 1.拿到目标控制器
    UIViewController *vc = segue.destinationViewController;
    
    // 2.设置目标控制器的标题
    vc.navigationItem.title = [NSString stringWithFormat:@"%@ 的联系人列表", self.accountField.text];
    
}




@end
