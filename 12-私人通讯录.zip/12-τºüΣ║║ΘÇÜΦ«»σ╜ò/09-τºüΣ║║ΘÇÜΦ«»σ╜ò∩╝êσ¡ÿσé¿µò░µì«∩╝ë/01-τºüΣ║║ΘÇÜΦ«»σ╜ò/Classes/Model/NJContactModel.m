//
//  NJContactModel.m
//  01-私人通讯录
//
//  Created by Luffy on 15/8/27.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJContactModel.h"

@implementation NJContactModel

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self.name forKey:@"name"];
    [aCoder encodeObject:self.phoneNum forKey:@"number"];
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super init]) {
        self.name = [aDecoder decodeObjectForKey:@"name"];
        self.phoneNum = [aDecoder decodeObjectForKey:@"number"];
    }
    return self;
}

@end
