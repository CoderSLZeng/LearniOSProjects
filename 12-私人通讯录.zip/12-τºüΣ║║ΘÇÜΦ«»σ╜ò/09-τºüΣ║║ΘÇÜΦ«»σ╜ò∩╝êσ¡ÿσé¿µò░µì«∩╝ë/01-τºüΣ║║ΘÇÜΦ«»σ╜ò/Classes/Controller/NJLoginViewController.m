//
//  NJLoginViewController.m
//  01-私人通讯录
//
//  Created by Luffy on 15/8/26.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJLoginViewController.h"
#import "MBProgressHUD+NJ.h"


@interface NJLoginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *accountField; // 输入账号
@property (weak, nonatomic) IBOutlet UITextField *pwdField; // 输入密码
@property (weak, nonatomic) IBOutlet UISwitch *remPwdSwitch; // 记住密码
@property (weak, nonatomic) IBOutlet UISwitch *autoLoginSwitch; // 自动登录

@property (weak, nonatomic) IBOutlet UIButton *loginButton; // 登录按钮

- (IBAction)remPwdChange:(id)sender; // 点击记住密码

- (IBAction)autoLoginChange:(id)sender; // 点击自动登录
- (IBAction)loginOnClick:(id)sender;
@end

@implementation NJLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 拿到通知中心
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    // 注册监听
    [center addObserver:self selector:@selector(textChange) name:UITextFieldTextDidChangeNotification object:self.accountField];
    
    [center addObserver:self selector:@selector(textChange) name:UITextFieldTextDidChangeNotification object:self.pwdField];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    self.accountField.text = [defaults objectForKey:@"accountField"];
    self.remPwdSwitch.on = [defaults boolForKey:@"remPwdSwitch"];
    if (self.remPwdSwitch.isOn) {
        self.pwdField.text = [defaults objectForKey:@"pwdField"];
    }
    
    self.autoLoginSwitch.on = [defaults boolForKey:@"autoLoginSwitch"];
    if (self.autoLoginSwitch.isOn) {
        [self loginOnClick:nil];
    }
}

- (void)viewDidAppear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)textChange
{
    self.loginButton.enabled = (self.accountField.text.length > 0 && self.pwdField.text.length > 0);
}


- (IBAction)remPwdChange:(id)sender {
    // 判断是否记住密码
    if (self.remPwdSwitch.isOn == 0) {
        [self.autoLoginSwitch setOn:NO animated:YES];
    }
    
}
- (IBAction)autoLoginChange:(id)sender {
    // 判断是否自动登录
    if (self.autoLoginSwitch.isOn) {
        [self.remPwdSwitch setOn:YES animated:YES];
    }
}

- (IBAction)loginOnClick:(id)sender {
    
    
    if ([self.accountField.text isEqualToString:@"lnj"] && [self.pwdField.text isEqualToString:@"123"])
    {
        [MBProgressHUD showMessage:@"正在登录中..."];
        
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        
        [defaults setObject:self.accountField.text forKey:@"accountField"];
        [defaults setObject:self.pwdField.text forKey:@"pwdField"];
        [defaults setBool:self.remPwdSwitch.isOn forKey:@"remPwdSwitch"];
        [defaults setBool:self.autoLoginSwitch.isOn forKey:@"autoLoginSwitch"];
        
        [defaults synchronize];
        
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            
            
            [self performSegueWithIdentifier:@"login2Contact" sender:nil];
            
            [MBProgressHUD hideHUD];
            
            [self.accountField resignFirstResponder];
            [self.pwdField resignFirstResponder];
            
        });
    } else {
        
        [MBProgressHUD showError:@"用户名或者密码不正确"];
    }
    
//    [MBProgressHUD hideHUD];
}


// 在segue跳转之前调用，会传入performSegueWithIndentifier方法闯将好segue对象
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    NSLog(@"%@ %@ %@", segue.identifier, segue.sourceViewController, segue.destinationViewController);
    
    // 1.拿到目标控制器
    UIViewController *vc = segue.destinationViewController;
    
    // 2.设置目标控制器的标题
    vc.navigationItem.title = [NSString stringWithFormat:@"%@ 的联系人列表", self.accountField.text];
    
}




@end
