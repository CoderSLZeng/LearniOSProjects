//
//  NJContactViewController.m
//  01-私人通讯录
//
//  Created by Luffy on 15/8/26.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJContactViewController.h"
#import "NJAddViewController.h"
#import "NJContactModel.h"
#import "NJEidtViewController.h"
#import "NJContactCell.h"

#define NJFilePath [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"contacts.arc"]

@interface NJContactViewController () <UIActionSheetDelegate, NJAddViewControllerDelegate, NJEidtViewControllerDelegate>
/**
 *  点击注销按钮
 */
- (IBAction)logout:(UIBarButtonItem *)sender;
/**
 *  可以保存数据的数组
 */
@property (nonatomic, strong) NSMutableArray *contacts;

@end

@implementation NJContactViewController

#pragma mark - 懒加载
- (NSMutableArray *)contacts
{
    if (_contacts == nil) {
        _contacts = [NSKeyedUnarchiver unarchiveObjectWithFile:NJFilePath];
        
        if (_contacts == nil) {
            _contacts = [NSMutableArray array];
        }
    }
    
    return _contacts;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    UIBarButtonItem *addBtn = self.navigationItem.rightBarButtonItem;
    UIBarButtonItem *editBtn = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemEdit target:self action:@selector(editBtnClick)];
    
    self.navigationItem.rightBarButtonItems = @[editBtn, addBtn];
}

- (void)editBtnClick {
    
    // 开启tableView的编辑模式
    [self.tableView setEditing:!self.tableView.editing animated:YES];
}



- (IBAction)logout:(UIBarButtonItem *)sender {
    UIActionSheet *sheet = [[UIActionSheet alloc] initWithTitle:@"确定要注销" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"确定" otherButtonTitles: nil];
    [sheet showInView:self.view];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
//      NSLog(@"%s", __func__);
    
//    NJAddViewController *addVc = segue.destinationViewController; // 获取目标控制器
//    addVc.delegate = self; // 设置代理
    UIViewController *vc = segue.destinationViewController;
    
    if ([vc isKindOfClass:[NJAddViewController class]]) {
        NJAddViewController *addVc = (NJAddViewController *)vc;
        addVc.delegate = self;
    }else if ([vc isKindOfClass:[NJEidtViewController class]]) {
        NJEidtViewController *eidtVc = (NJEidtViewController *)vc;
        NSIndexPath *path = [self.tableView indexPathForSelectedRow];
//        self.contacts[path.row] = contact;
        NJContactModel *c = self.contacts[path.row];
        
        eidtVc.contact = c;
        
        eidtVc.delegate = self;
    }
    
}

#pragma mark - NJEidtViewControllerDelegate
- (void)eidtViewControllerDidSaveBtnOnClik:(NJEidtViewController *)eidtViewController WithContact:(NJContactModel *)contact
{
    // 1.修改模型
//    NSIndexPath *path = [self.tableView indexPathForSelectedRow];
//    self.contacts[path.row] = contact;
    [NSKeyedArchiver archiveRootObject:self.contacts toFile:NJFilePath];
    
    // 2.刷新表格
    [self.tableView reloadData];
}

#pragma mark - UIActionSheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (0 == buttonIndex) {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

#pragma mark - NJAddViewControllerDelegate
- (void)addViewControllerDidAddBtnOnClick:(NJAddViewController *)addViewController WithContact:(NJContactModel *)contact
{
//    NSLog(@"添加联系人");
    
    [self.contacts addObject:contact];
    
    [NSKeyedArchiver archiveRootObject:self.contacts toFile:NJFilePath];
    
    
    [self.tableView reloadData];
}

#pragma mark - 数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.contacts.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    static NSString *identifier = @"contacts";
//    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    NJContactCell *cell = [NJContactCell contactCellWithTableView:tableView];

    NJContactModel *c = self.contacts[indexPath.row];
    
    cell.contact = c;
    
    NSLog(@"%@ %@", cell.textLabel, cell.detailTextLabel);
    
    return cell;
    
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (UITableViewCellEditingStyleDelete == editingStyle) {
        [self.contacts removeObjectAtIndex:indexPath.row];
        
        [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationTop];
        
        [NSKeyedArchiver archiveRootObject:self.contacts toFile:NJFilePath];
        
    }else if (UITableViewCellEditingStyleInsert == editingStyle) {
        NJContactModel *c = [[NJContactModel alloc] init];
        c.name = @"luffy";
        c.phoneNum = @"15015268866";
        
        [self.contacts insertObject:c atIndex:indexPath.row + 1];
        
        NSIndexPath *path = [NSIndexPath indexPathForItem:indexPath.row + 1 inSection:0];
        
        [self.tableView insertRowsAtIndexPaths:@[path] withRowAnimation:UITableViewRowAnimationBottom];
    }
}


- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row % 2) {
        return UITableViewCellEditingStyleInsert;
    } else {
        return UITableViewCellEditingStyleDelete;
    }
}

@end
