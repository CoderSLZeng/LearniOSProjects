//
//  ViewController.m
//  08-归档
//
//  Created by Luffy on 15/8/29.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "Person.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)saveOBJOnClick:(UIButton *)sender {
    
    Person *p = [[Person alloc] init];
    p.name = @"Luffy";
    p.age = @"27";
    
    NSString *docPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES) lastObject];
    
    NSString *path = [docPath stringByAppendingPathComponent:@"abc.arc"];
    
   [NSKeyedArchiver archiveRootObject:p toFile:path];
    
    NSLog(@"%@", path);
    
}

- (IBAction)readOBJOnClick:(UIButton *)sender {
    
    NSString *docPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSString *path = [docPath stringByAppendingPathComponent:@"abc.arc"];
    
    Person *p = [NSKeyedUnarchiver unarchiveObjectWithFile:path];
    
    NSLog(@"%@ %@", p.name, p.age);
    
}

@end
