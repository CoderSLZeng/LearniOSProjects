//
//  ViewController.m
//  07-偏好设定
//
//  Created by Luffy on 15/8/29.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)saveDataOnClick:(UIButton *)sender {
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    [defaults setObject:@"luffy" forKey:@"name"];
    [defaults setInteger:27 forKey:@"age"];
    [defaults setDouble:1.76f forKey:@"height"];
    
    NSLog(@"%@", defaults);
    
}
- (IBAction)readDataOnClick:(UIButton *)sender {
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    NSString *name = [defaults objectForKey:@"name"];
    int age = [defaults integerForKey:@"age"];
    double height = [defaults doubleForKey:@"height"];
    
    NSLog(@"name = %@, age = %d, height = %f", name, age, height);
}

@end
