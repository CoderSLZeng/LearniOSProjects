//
//  ViewController.m
//  06-plist存储数据
//
//  Created by Luffy on 15/8/28.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
- (IBAction)saveBtnOnClick:(UIButton *)sender;
- (IBAction)readBtnOnClick:(UIButton *)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)saveBtnOnClick:(UIButton *)sender {
    
    // 1.获取应用程序沙盒目录
//    NSString *home = NSHomeDirectory();
    
    // 不建议写
//    NSString *path = [home stringByAppendingString:@"/Documents"];
    // 不建议Doucuments写死
//    NSString *path = [home stringByAppendingPathComponent:@"Documents"];
    
    NSString *doc = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    
    NSString *path = [doc stringByAppendingPathComponent:@"abc.plist"];
    
    NSLog(@"%@", path);
    
    
    NSDictionary *dict = @{@"name" : @"lnj", @"age" : @"27"};
    
    [dict writeToFile:path atomically:YES];
}

- (IBAction)readBtnOnClick:(UIButton *)sender {
    NSString *doc = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    
    NSString *path = [doc stringByAppendingPathComponent:@"abc.plist"];
    
    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile:path];
    
    NSLog(@"%@", dict);
}
@end
