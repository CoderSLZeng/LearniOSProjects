//
//  ViewController.m
//  05-线程的安全问题（了解）
//
//  Created by Zeng on 16/1/5.
//  Copyright © 2016年 HM. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (nonatomic, strong) NSThread *thread1;
@property (nonatomic, strong) NSThread *thread2;
@property (nonatomic, strong) NSThread *thread3;

/**
 *  剩余票数
 */
@property (nonatomic, assign) int leftTickecCount;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.leftTickecCount = 50;
    
    self.thread1 = [[NSThread alloc] initWithTarget:self selector:@selector(saleTicket) object:nil];
    self.thread1.name = @"1号窗口";
    
    self.thread2 = [[NSThread alloc] initWithTarget:self selector:@selector(saleTicket) object:nil];
    self.thread2.name = @"2号窗口";
    
    self.thread3 = [[NSThread alloc] initWithTarget:self selector:@selector(saleTicket) object:nil];
    self.thread3.name = @"3号窗口";

}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.thread1 start];
    [self.thread2 start];
    [self.thread3 start];
}

/**
 *  卖票
 */
- (void)saleTicket
{
    while (1) {
        @synchronized(self) { // 开始加锁
            int count = self.leftTickecCount;
            if (count > 0) {
                [NSThread sleepForTimeInterval:0.05];
                
                self.leftTickecCount = count - 1;
                
                NSLog(@"%@卖了一张票，剩余%d张票", [NSThread currentThread].name, self.leftTickecCount);
            } else {
                return;
            } // 解锁
        }
    }
}

@end
