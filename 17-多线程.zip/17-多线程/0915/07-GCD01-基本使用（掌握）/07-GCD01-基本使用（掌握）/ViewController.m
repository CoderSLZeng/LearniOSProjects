//
//  ViewController.m
//  07-GCD01-基本使用（掌握）
//
//  Created by Zeng on 16/1/5.
//  Copyright © 2016年 HM. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    dispatch_async(queue, ^{
        NSLog(@"---下载图片1---%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"---下载图片2---%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"---下载图片3---%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"---下载图片4---%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"---下载图片5---%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"---下载图片6---%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"---下载图片7---%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"---下载图片8---%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"---下载图片9---%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"---下载图片10---%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"---下载图片11---%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"---下载图片12---%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"---下载图片13---%@", [NSThread currentThread]);
    });
}
@end
