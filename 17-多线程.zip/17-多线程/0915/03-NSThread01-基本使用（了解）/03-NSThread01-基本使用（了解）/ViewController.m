//
//  ViewController.m
//  03-NSThread01-基本使用（了解）
//
//  Created by Zeng on 16/1/5.
//  Copyright © 2016年 HM. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)download:(NSString *)url
{
    NSLog(@"下载东西---%@---%@", url, [NSThread currentThread]);

}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
//    [self createThread1];
//    [self createThread2];
    [self createThread3];
}

/**
 *  创建线程的方式3
 */
- (void)createThread3
{
    // 创建线程
    [self performSelectorInBackground:@selector(download:) withObject:@"http://c.png"];
}


/**
 *  创建线程的方式2
 */
- (void)createThread2
{
    // 创建线程
    [NSThread detachNewThreadSelector:@selector(download:) toTarget:self withObject:@"http://b.png"];
}


/**
 *  创建线程的方式1
 */
- (void)createThread1
{
    // 创建线程
    NSThread *thread = [[NSThread alloc] initWithTarget:self selector:@selector(download:) object:@"http://a.png"];
    
    // 启动线程
    [thread start];
}


@end
