//
//  ViewController.m
//  02-pthread（演示）
//
//  Created by Zeng on 16/1/5.
//  Copyright © 2016年 HM. All rights reserved.
//

#import "ViewController.h"
#import <pthread.h>

@interface ViewController ()

@end

@implementation ViewController

void *run(void *data)
{
    for (int i = 0; i <= 999; i++) {
        NSLog(@"touchesBegan----%d----%@", i, [NSThread currentThread]);

    }
    return NULL;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    // 创建线程
    pthread_t myRestrict;
    pthread_create(&myRestrict, NULL, run, NULL);
    
}

@end
