//
//  ViewController.m
//  09-GCD03-线程间的通信（掌握）
//
//  Created by Zeng on 16/1/5.
//  Copyright © 2016年 HM. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
//@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UIButton *button;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    dispatch_async(queue, ^{
       
        NSLog(@"download--%@", [NSThread currentThread]);

        
        NSString *str = @"http://ww4.sinaimg.cn/bmiddle/678d3a95gw1ex0n6j9633j20nq0zkq6p.jpg";
        
        NSURL *url = [NSURL URLWithString:str];
        
        NSData *data = [NSData dataWithContentsOfURL:url];
        
        UIImage *image = [UIImage imageWithData:data];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            NSLog(@"setting--%@", [NSThread currentThread]);

            [self.button setImage:image forState:UIControlStateNormal];
//            [self.button setBackgroundImage:image forState:UIControlStateNormal];
        });
    });
    
}

@end
