//
//  ViewController.m
//  06-线程间的通信（掌握）
//
//  Created by Zeng on 16/1/5.
//  Copyright © 2016年 HM. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self performSelectorInBackground:@selector(download) withObject:nil];
}

/**
 *  下载图片
 */
- (void)download
{
    NSLog(@"download---%@", [NSThread currentThread]);
    
    // 1.图片地址
//    NSString *urlStr = @"http://ww3.sinaimg.cn/bmiddle/678d3a95gw1ewurqzo7czj20vh1bbajy.jpg";
    NSString *urlStr = @"http://ww4.sinaimg.cn/bmiddle/678d3a95gw1evv7at6l96j20zi1bc45j.jpg";

    NSURL *url = [NSURL URLWithString:urlStr];
    
    // 2.根据地址下载图片的二进制数据（这句代码最耗时）
    NSLog(@"---begin");
    NSData *data = [NSData dataWithContentsOfURL:url];
    NSLog(@"----end");

    // 3.设置图片
    UIImage *image = [UIImage imageWithData:data];
    
    // 4.回到主线程，刷新UI界面（为了线程安全）
    [self performSelectorOnMainThread:@selector(downloadFinished:) withObject:image waitUntilDone:YES];
//    [self performSelector:@selector(downloadFinished:) onThread:[NSThread mainThread] withObject:image waitUntilDone:YES];
//    [self.imageView performSelectorOnMainThread:@selector(setImage:) withObject:image waitUntilDone:YES];
    
    NSLog(@"-----done-----");

}

- (void)downloadFinished:(UIImage *)image
{
    self.imageView.image = image;
    
    NSLog(@"downloadFinished---%@", [NSThread currentThread]);

}

@end
