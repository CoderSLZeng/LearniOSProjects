//
//  ViewController.m
//  04-NSThread02-线程状态（了解）
//
//  Created by Zeng on 16/1/5.
//  Copyright © 2016年 HM. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (nonatomic, strong) NSThread *thread;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.thread = [[NSThread alloc] initWithTarget:self selector:@selector(download) object:nil];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)download
{
    NSLog(@"----begin--%@", [NSThread currentThread]);
    // 睡眠3秒钟
//    [NSThread sleepForTimeInterval:3];
    
//    NSDate *date = [NSDate dateWithTimeIntervalSinceNow:3];
//    [NSThread sleepUntilDate:date];
    
    for (int i = 0; i <= 99; i++) {
        NSLog(@"----%d", i);
//        return;
        if (i == 49) {
            [NSThread exit];
        }

    }

    
    NSLog(@"----end");

}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
//    NSThread *thread = [[NSThread alloc] initWithTarget:self selector:@selector(download) object:nil];
//    [thread start];
    
//    [NSThread detachNewThreadSelector:@selector(download) toTarget:self withObject:nil];
    
    [self performSelectorInBackground:@selector(download) withObject:nil];
}

@end
