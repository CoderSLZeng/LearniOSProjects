//
//  ViewController.m
//  08-GCD02-队列的使用（了解）
//
//  Created by Zeng on 16/1/5.
//  Copyright © 2016年 HM. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self syncMainQueue];
}

/**
 *  async -- 并发队列（最常用）
 *  会不会创建线程：会
 *  任务的执行方式：并发执行
 */
- (void)asyncGlobaQueue
{
    // 获得全局的并发队列
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    dispatch_async(queue, ^{
        NSLog(@"------下载图片1-----%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"------下载图片2-----%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"------下载图片3-----%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"------下载图片4-----%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"------下载图片5-----%@", [NSThread currentThread]);
    });
}

/**
 *  async -- 串行队列（有时候用）
 *  会不会创建线程：会，一般只会开1条线程
 *  任务的执行方式：串行执行（一个认为执行完毕后在执行下一个任务）
 */
- (void)asyncSerialQueue
{
    dispatch_queue_t queue = dispatch_queue_create("cn.heima.queue", NULL);
    
    dispatch_async(queue, ^{
         NSLog(@"------下载图片1-----%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"------下载图片2-----%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"------下载图片3-----%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"------下载图片4-----%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"------下载图片5-----%@", [NSThread currentThread]);
    });
    
    // 非ARC，需要释放创建的队列
//    dispatch_release(queue);
}


/**
 *  async -- 主队列（很常用）
 */
- (void)asyncMainQueue
{
    dispatch_queue_t queue = dispatch_get_main_queue();
    
    dispatch_async(queue, ^{
        NSLog(@"------下载图片1-----%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"------下载图片2-----%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"------下载图片3-----%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"------下载图片4-----%@", [NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"------下载图片5-----%@", [NSThread currentThread]);
    });
}

/**
 *  sync -- 主队列（不能用---会卡死）
 */
- (void)syncMainQueue
{
    NSLog(@"syncMainQueue ---- begin ---");
    
    dispatch_queue_t queue = dispatch_get_main_queue();
    
    dispatch_sync(queue, ^{
        NSLog(@"------下载图片2-----%@", [NSThread currentThread]);
    });
    dispatch_sync(queue, ^{
        NSLog(@"------下载图片3-----%@", [NSThread currentThread]);
    });
    dispatch_sync(queue, ^{
        NSLog(@"------下载图片4-----%@", [NSThread currentThread]);
    });
    NSLog(@"syncMainQueue ---- end ---");

}

/**-------------------------------------华丽的分割线-----------------------------------------------------**/

/**
 *  sync -- 并发队列
 *  会不会创建线程：不会
 *  任务的执行方式：串行执行（一个认为执行完毕后在执行下一个任务）
 *  并发队列失去了并发功能
 */
- (void)syncGlobaQueue
{
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_sync(queue, ^{
         NSLog(@"------下载图片1-----%@", [NSThread currentThread]);
    });
    dispatch_sync(queue, ^{
        NSLog(@"------下载图片2----%@", [NSThread currentThread]);
    });
    dispatch_sync(queue, ^{
        NSLog(@"------下载图片3-----%@", [NSThread currentThread]);
    });
    dispatch_sync(queue, ^{
        NSLog(@"------下载图片4-----%@", [NSThread currentThread]);
    });
    dispatch_sync(queue, ^{
        NSLog(@"------下载图片5-----%@", [NSThread currentThread]);
    });
}


/**
 *  sync -- 串行队列
 *  会不会创建线程：不会
 *  任务的执行方式：串行执行（一个认为执行完毕后在执行下一个任务）
 */
- (void)syncSerialQueue
{
    dispatch_queue_t queue = dispatch_queue_create("cn.heima.queue", NULL);
    
    dispatch_sync(queue, ^{
        NSLog(@"------下载图片1-----%@", [NSThread currentThread]);
    });
    dispatch_sync(queue, ^{
        NSLog(@"------下载图片2-----%@", [NSThread currentThread]);
    });
    dispatch_sync(queue, ^{
        NSLog(@"------下载图片3-----%@", [NSThread currentThread]);
    });
    dispatch_sync(queue, ^{
        NSLog(@"------下载图片4-----%@", [NSThread currentThread]);
    });
    dispatch_sync(queue, ^{
        NSLog(@"------下载图片5-----%@", [NSThread currentThread]);
    });
}

@end
