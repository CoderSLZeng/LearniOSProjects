//
//  HMImageDownloader.m
//  02-一次性代码（掌握）
//
//  Created by Zeng on 16/1/5.
//  Copyright © 2016年 HM. All rights reserved.
//

#import "HMImageDownloader.h"

@implementation HMImageDownloader

- (void)download
{
    NSLog(@"-----下载图片-----");

}

@end
