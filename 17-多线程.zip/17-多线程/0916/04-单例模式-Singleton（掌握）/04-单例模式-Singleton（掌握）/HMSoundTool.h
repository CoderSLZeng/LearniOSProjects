//
//  HMSoundTool.h
//  04-单例模式-Singleton（掌握）
//
//  Created by Zeng on 16/1/5.
//  Copyright © 2016年 HM. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HMSoundTool : NSObject
+ (instancetype)sharedSoundTool;

@end
