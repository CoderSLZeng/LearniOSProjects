//
//  ViewController.m
//  04-单例模式-Singleton（掌握）
//
//  Created by Zeng on 16/1/5.
//  Copyright © 2016年 HM. All rights reserved.
//

#import "ViewController.h"
#import "HMMusicTool.h"
#import "HMSoundTool.h"
#import "HMDataTool.h"
#import "HMPerson.h"
#import "HMStudent.h"
#import "HMGoodStudent.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[HMGoodStudent alloc] init];
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{

}

- (void)test4
{
    HMDataTool *tool1 = [HMDataTool sharedDataTool];
    HMDataTool *tool2 = [HMDataTool sharedDataTool];
    HMDataTool *tool3 = [[HMDataTool alloc] init];
    HMDataTool *tool4 = [[HMDataTool alloc] init];
    HMDataTool *tool5 = [tool4 copy];
    
    NSLog(@"\n--tool1=%@\n--tool2=%@\n--tool3=%@\n--tool4=%@\n--tool5=%@\n", tool1, tool2, tool3, tool4, tool5);
}

/**
 *  饿汗式
 */
- (void)test3
{
    HMSoundTool *tool1 = [HMSoundTool sharedSoundTool];
    HMSoundTool *tool2 = [HMSoundTool sharedSoundTool];
    HMSoundTool *tool3 = [HMSoundTool sharedSoundTool];
    HMSoundTool *tool4 = [[HMSoundTool alloc] init];
    HMSoundTool *tool5 = [tool4 copy];
    NSLog(@"\n--tool1=%@\n--tool2=%@\n--tool3=%@\n--tool4=%@\n--tool5=%@\n", tool1, tool2, tool3, tool4, tool5);

}

/**
 *  懒汗式
 */
- (void)test2
{
    NSLog(@"begin-%@", [HMMusicTool sharedMusicTool]);
    NSLog(@"begin-%@", [HMMusicTool sharedMusicTool]);
    
    //    extern id _musicTool;
    //    _musicTool = nil;
    
    NSLog(@"end-%@", [HMMusicTool sharedMusicTool]);
    NSLog(@"end-%@", [HMMusicTool sharedMusicTool]);
    
}

/**
 *  懒汗式
 */
- (void)test
{
    HMMusicTool *tool1 = [[HMMusicTool alloc] init];
    HMMusicTool *tool2 = [[HMMusicTool alloc] init];
    HMMusicTool *tool3 = [[HMMusicTool alloc] init];
    HMMusicTool *tool4 = [[HMMusicTool alloc] init];
    
    HMMusicTool *tool5 = [tool4 copy];
    
    NSLog(@"\--ntool1=%@\n--tool2=%@\n--tool3=%@\n--tool4=%@\n--tool5=%@\n", tool1, tool2, tool3, tool4, tool5);
}

@end
