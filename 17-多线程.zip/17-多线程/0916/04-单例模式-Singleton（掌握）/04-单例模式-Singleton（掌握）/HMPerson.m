//
//  HMPerson.m
//  04-单例模式-Singleton（掌握）
//
//  Created by Zeng on 16/1/5.
//  Copyright © 2016年 HM. All rights reserved.
//

#import "HMPerson.h"

@implementation HMPerson

+ (void)load
{
    NSLog(@"load---HMPerson");

}

+ (void)initialize
{
    NSLog(@"initialize---HMPerson");

}

@end
