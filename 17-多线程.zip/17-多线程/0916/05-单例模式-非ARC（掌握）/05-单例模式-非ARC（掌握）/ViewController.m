//
//  ViewController.m
//  05-单例模式-非ARC（掌握）
//
//  Created by Zeng on 16/1/5.
//  Copyright © 2016年 HM. All rights reserved.
//

#import "ViewController.h"
#import "HMDataTool.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    HMDataTool *tool1 = [[HMDataTool alloc] init];
    HMDataTool *tool2 = [[HMDataTool alloc] init];
    HMDataTool *tool3 = [HMDataTool sharedDataTool];
    HMDataTool *tool4 = [HMDataTool sharedDataTool];
    
    [tool4 autorelease];
    
    NSLog(@"\n--tool1%@--\n--tool2%@--\n--tool3%@--\n--tool4%@--", tool1, tool2, tool3, tool4);
}

@end
