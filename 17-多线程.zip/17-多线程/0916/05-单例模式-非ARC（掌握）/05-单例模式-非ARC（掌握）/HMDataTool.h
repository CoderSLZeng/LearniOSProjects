//
//  HMDataTool.h
//  05-单例模式-非ARC（掌握）
//
//  Created by Zeng on 16/1/5.
//  Copyright © 2016年 HM. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HMDataTool : NSObject <NSCopying>
+ (instancetype)sharedDataTool;
@end
