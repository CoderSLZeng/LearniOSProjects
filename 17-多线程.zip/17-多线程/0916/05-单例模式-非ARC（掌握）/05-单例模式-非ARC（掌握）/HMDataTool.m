//
//  HMDataTool.m
//  05-单例模式-非ARC（掌握）
//
//  Created by Zeng on 16/1/5.
//  Copyright © 2016年 HM. All rights reserved.
//

#import "HMDataTool.h"

@implementation HMDataTool
static id _instance;

+ (instancetype)allocWithZone:(struct _NSZone *)zone
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [super allocWithZone:zone];
    });
    return _instance;
}

+ (instancetype)sharedDataTool
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [[self alloc] init];
    });
    return _instance;
}

- (id)copyWithZone:(NSZone *)zone
{
    return _instance;
}

- (oneway void)release {}
- (id)retain {return self; }
- (NSUInteger)retainCount { return 1; }
- (instancetype)autorelease { return self; }


@end
