//
//  ViewController.h
//  06-简化单例模式
//
//  Created by Zeng on 16/1/5.
//  Copyright © 2016年 HM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

