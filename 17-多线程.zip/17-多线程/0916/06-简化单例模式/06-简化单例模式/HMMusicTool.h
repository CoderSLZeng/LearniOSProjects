//
//  HMMusicTool.h
//  06-简化单例模式
//
//  Created by Zeng on 16/1/5.
//  Copyright © 2016年 HM. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HMSingleton.h"

@interface HMMusicTool : NSObject
HMSingletonH
@end
