//
//  ViewController.m
//  06-简化单例模式
//
//  Created by Zeng on 16/1/5.
//  Copyright © 2016年 HM. All rights reserved.
//

#import "ViewController.h"
#import "HMMusicTool.h"
#import "HMMovieTool.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    HMMusicTool *tool1 = [HMMusicTool sharedInstance];
    HMMusicTool *tool2 = [HMMusicTool sharedInstance];
    
    HMMovieTool *tool3 = [HMMovieTool sharedInstance];
    HMMovieTool *tool4 = [HMMovieTool sharedInstance];
    
    NSLog(@"\n--tool1%@--\n--tool2%@--\n--tool3%@--\n--tool4%@--", tool1, tool2, tool3, tool4);
}

@end
