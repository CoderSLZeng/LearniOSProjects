//
//  ViewController.m
//  03-队列组（了解）
//
//  Created by Zeng on 16/1/5.
//  Copyright © 2016年 HM. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (nonatomic, strong) UIImage *image1;
@property (nonatomic, strong) UIImage *image2;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    // 1.队列组
    dispatch_group_t group = dispatch_group_create();
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    // 2.下载图片1
    dispatch_group_async(group, queue, ^{
       
        NSURL *url1 = [NSURL URLWithString:@"http://ww4.sinaimg.cn/mw690/005XCQVTgw1ezorxvw3lyj30gu0m8762.jpg"];
        NSData *data1 = [NSData dataWithContentsOfURL:url1];
        self.image1 = [UIImage imageWithData:data1];
    });
    
    // 3.下载图片2
    dispatch_group_async(group, queue, ^{
        
        NSURL *url2 = [NSURL URLWithString:@"http://su.bdimg.com/static/superplus/img/logo_white_ee663702.png"];
        NSData *data2 = [NSData dataWithContentsOfURL:url2];
        self.image2 = [UIImage imageWithData:data2];
    });
    // 4.合并图片
    dispatch_group_notify(group, queue, ^{
        UIGraphicsBeginImageContextWithOptions(self.image1.size, NO, 0.0);
        
        CGFloat image1W = self.image1.size.width;
        CGFloat image1H = self.image1.size.height;
        [self.image1 drawInRect:CGRectMake(0, 0, image1W, image1H)];
        
        
        CGFloat image2W = self.image2.size.width;
        CGFloat image2H = self.image2.size.height;
        CGFloat image2X = image1W - image2W;
        CGFloat image2Y = image1H - image2H;
        [self.image2 drawInRect:CGRectMake(image2X, image2Y, image2W, image2H)];
        
        UIImage *fullImage = UIGraphicsGetImageFromCurrentImageContext();
        
        UIGraphicsEndImageContext();
        
        // 5.回到主线程显示图片
        dispatch_async(dispatch_get_main_queue(), ^{
            self.imageView.image = fullImage;
        });
    });
    
    
}

/**
 *  合并图片
 */
- (void)bindImages
{
    if (self.image1 == nil || self.image2 == nil) return;
    
    UIGraphicsBeginImageContextWithOptions(self.image1.size, NO, 0.0);
    
    CGFloat image1W = self.image1.size.width;
    CGFloat image1H = self.image1.size.height;
    [self.image1 drawInRect:CGRectMake(0, 0, image1W, image1H)];
    
    CGFloat image2W = self.image2.size.width * 0.5;
    CGFloat image2H = self.image2.size.height * 0.5;
    CGFloat image2X = image1W - image2W;
    CGFloat image2Y = image1H - image2H;
    [self.image2 drawInRect:CGRectMake(image2X, image2Y, image2W, image2H)];
    
    UIImage *fullImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    dispatch_async(dispatch_get_main_queue(), ^{
        self.imageView.image = fullImage;
    });
}

- (void)test2
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        // 1.下载第一张图片
        NSString *str = @"http://ww4.sinaimg.cn/mw690/005XCQVTgw1ezosr53q02j30qo140tgq.jpg";
        NSURL *url = [NSURL URLWithString:str];
        NSData *data = [NSData dataWithContentsOfURL:url];
        self.image1 = [UIImage imageWithData:data];
        
        [self bindImages];
    });
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        // 2.下载第二张图片
        NSURL *url2 = [NSURL URLWithString:@"http://su.bdimg.com/static/superplus/img/logo_white_ee663702.png"];
        NSData *data2 = [NSData dataWithContentsOfURL:url2];
        self.image2 = [UIImage imageWithData:data2];
        
        [self bindImages];
    });

}

- (void)test1
{
    // 异步下载
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        // 1.下载第一张图片
        NSString *str = @"http://ww2.sinaimg.cn/mw690/005XCQVTgw1ezosqz8kvpj30qo140q9m.jpg";
        NSURL *url = [NSURL URLWithString:str];
        NSData *data = [NSData dataWithContentsOfURL:url];
        UIImage *image1 = [UIImage imageWithData:data];
        
        // 2.下载第二张图片
        NSString *str2 = @"http://su.bdimg.com/static/superplus/img/logo_white_ee663702.png";
        NSURL *url2 = [NSURL URLWithString:str2];
        NSData *data2 = [NSData dataWithContentsOfURL:url2];
        UIImage *image2 = [UIImage imageWithData:data2];
        
        // 3.合并图片
        // 3.1开启一个位图上下文
        UIGraphicsBeginImageContextWithOptions(image1.size, NO, 0.0);
        
        // 3.2绘制第1张图片
        CGFloat image1W = image1.size.width;
        CGFloat image1H = image1.size.height;
        CGRect rect  = CGRectMake(0, 0, image1W, image1H);
        [image1 drawInRect:rect];
        
        // 3.3绘制第2张图片
        CGFloat image2W = image2.size.width * 0.5;
        CGFloat image2H = image2.size.height * 0.5;
        CGFloat image2Y = image1H - image2H;
        CGFloat image2X = image1W - image2W;
        CGRect rect2 =  CGRectMake(image2X, image2Y, image2W, image2H);
        [image2 drawInRect:rect2];
        
        // 3.4得到上下文中的图片
        UIImage *fullImage = UIGraphicsGetImageFromCurrentImageContext();
        
        // 3.5结束上下文
        UIGraphicsEndImageContext();
        
        // 4.回到主线程显示图片
        dispatch_async(dispatch_get_main_queue(), ^{
            self.imageView.image = fullImage;
        });
        
    });
}


@end
