//
//  ViewController.m
//  02-UIDynamic-01-重力行为
//
//  Created by Anthony on 16/4/8.
//  Copyright © 2016年 Anthony. All rights reserved.
//

/**
 *   步骤
 创建一个物理仿真器（顺便设置仿真范围）
 
 创建相应的物理仿真行为（顺便添加物理仿真元素）
 
 将物理仿真行为添加到物理仿真器中 开始仿真
 */

#import "ViewController.h"

@interface ViewController ()
/**
 *  物理仿真器
 */
@property (nonatomic, strong) UIDynamicAnimator *animator;
@property (weak, nonatomic) IBOutlet UIView *blueView;

@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentControl;
@end

@implementation ViewController

#pragma mark - 懒加载
- (UIDynamicAnimator *)animator
{
    if (!_animator) {
        // 创建物理仿真器（ReferenceView:仿真范围）
        _animator = [[UIDynamicAnimator alloc] initWithReferenceView:self.view];
    }
    
    return _animator;
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
   
    [self test3];
    
}

- (void)test3
{
    UIGravityBehavior *gravity = [[UIGravityBehavior alloc] initWithItems:@[self.blueView, self.segmentControl]];
    UICollisionBehavior *collision = [[UICollisionBehavior alloc] initWithItems:@[self.blueView, self.segmentControl]];
//    [collision addBoundaryWithIdentifier:@"line" fromPoint:CGPointMake(0, 200) toPoint:CGPointMake(320, 400)];
//    collision.translatesReferenceBoundsIntoBoundary = YES;
    
    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(0, 0, 320, 400)];
    [collision addBoundaryWithIdentifier:@"cirlce" forPath:path];
    
    [self.animator addBehavior:gravity];
    [self.animator addBehavior:collision];
    
}

- (void)test2
{
    UIGravityBehavior *gravity = [[UIGravityBehavior alloc] initWithItems:@[self.blueView, self.segmentControl]];
    // 加速度
    gravity.magnitude = 1000;
    
    [self.animator addBehavior:gravity];
    
    UICollisionBehavior *collision = [[UICollisionBehavior alloc] initWithItems:@[self.blueView, self.segmentControl]];
    collision.translatesReferenceBoundsIntoBoundary = YES;
    [self.animator addBehavior:collision];
}

- (void)test
{
    // 1.创建物理仿真行为--->重力行为（items：物理仿真元素）
    UIGravityBehavior *gravity = [[UIGravityBehavior alloc] initWithItems:@[self.blueView, self.segmentControl]];
    
    // 2.创建物理仿真行为--->碰撞检测行为
    UICollisionBehavior *collision = [[UICollisionBehavior alloc] initWithItems:@[self.blueView, self.segmentControl]];
    // 3.让参照视图的bounds成为碰撞检测的边框
    collision.translatesReferenceBoundsIntoBoundary = YES;
    
    // 3.添加 物理仿真行为 到 物理仿真器
    [self.animator addBehavior:gravity];
    [self.animator addBehavior:collision];
}

@end
