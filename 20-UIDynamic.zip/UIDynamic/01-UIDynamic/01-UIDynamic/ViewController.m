//
//  ViewController.m
//  01-UIDynamic
//
//  Created by Anthony on 16/4/8.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIView *redView;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentedControl;

/**
 *  物理仿真器
 */
@property (nonatomic, strong) UIDynamicAnimator *animator;

@end

@implementation ViewController

#pragma mark - 懒加载
- (UIDynamicAnimator *)animator
{
    if (!_animator) _animator = [[UIDynamicAnimator alloc] initWithReferenceView:self.view];
    
    return _animator;
}


- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
//    [self test4];
    
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:touch.view];
    
    UISnapBehavior *snapB = [[UISnapBehavior alloc] initWithItem:self.redView snapToPoint:point];
    snapB.damping = 0;
    
    UISnapBehavior *snapB2 = [[UISnapBehavior alloc] initWithItem:self.segmentedControl snapToPoint:point];
    
    [self.animator removeAllBehaviors];
    
    [self.animator addBehavior:snapB];
    [self.animator addBehavior:snapB2];
}



- (void)test4
{
    UIGravityBehavior *gravityB = [[UIGravityBehavior alloc] initWithItems:@[self.redView, self.segmentedControl]];
    [self.animator addBehavior:gravityB];
    
    UICollisionBehavior *collisionB = [[UICollisionBehavior alloc] initWithItems:@[self.redView, self.segmentedControl]];
    // 设置图形边界
    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(20, 100, 300, 400)];
    [collisionB addBoundaryWithIdentifier:@"crilce" forPath:path];
    collisionB.translatesReferenceBoundsIntoBoundary = YES;
    
    [self.animator addBehavior:collisionB];
}


- (void)test3
{
    UIGravityBehavior *gravityB = [[UIGravityBehavior alloc] initWithItems:@[self.redView, self.segmentedControl]];
    [self.animator addBehavior:gravityB];
    
    UICollisionBehavior *collisionB = [[UICollisionBehavior alloc] initWithItems:@[self.redView, self.segmentedControl]];
    // 设置直线边界
    [collisionB addBoundaryWithIdentifier:@"line" fromPoint:CGPointMake(0, 200) toPoint:CGPointMake(320, 500)];
    
    
    [self.animator addBehavior:collisionB];
}


- (void)test2
{
    UIGravityBehavior *gravityB = [[UIGravityBehavior alloc] initWithItems:@[self.redView, self.segmentedControl]];
    [self.animator addBehavior:gravityB];
    
    UICollisionBehavior *collisionB = [[UICollisionBehavior alloc] initWithItems:@[self.redView, self.segmentedControl]];
    collisionB.translatesReferenceBoundsIntoBoundary = YES;
    
    [self.animator addBehavior:collisionB];
}

- (void)test {
    UIGravityBehavior *gravityB = [[UIGravityBehavior alloc] initWithItems:@[self.redView, self.segmentedControl]];
    
    gravityB.gravityDirection = CGVectorMake(1, 0);

    gravityB.magnitude = 100.0;
    
    [self.animator addBehavior:gravityB];
}
@end
