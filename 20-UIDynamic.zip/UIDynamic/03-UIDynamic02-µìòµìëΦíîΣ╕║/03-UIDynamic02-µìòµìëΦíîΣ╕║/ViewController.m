//
//  ViewController.m
//  03-UIDynamic02-捕捉行为
//
//  Created by Anthony on 16/4/8.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *iconView;

/**
 *  物理仿真器
 */
@property (nonatomic, strong) UIDynamicAnimator *animator;

@end

@implementation ViewController

#pragma mark - 懒加载
- (UIDynamicAnimator *)animator
{
    if (!_animator) {
        // 创建物理仿真器并指定范围
        _animator = [[UIDynamicAnimator alloc] initWithReferenceView:self.view];
    }
    
    return _animator;
}


- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:touch.view];
    
    UISnapBehavior *snap = [[UISnapBehavior alloc] initWithItem:self.iconView snapToPoint:point];
    // 减震
    snap.damping = arc4random_uniform(5)/5.0;
    
    // 移除之前的所有行为
    [self.animator removeAllBehaviors];
    // 添加行为
    [self.animator addBehavior:snap];
}

@end
