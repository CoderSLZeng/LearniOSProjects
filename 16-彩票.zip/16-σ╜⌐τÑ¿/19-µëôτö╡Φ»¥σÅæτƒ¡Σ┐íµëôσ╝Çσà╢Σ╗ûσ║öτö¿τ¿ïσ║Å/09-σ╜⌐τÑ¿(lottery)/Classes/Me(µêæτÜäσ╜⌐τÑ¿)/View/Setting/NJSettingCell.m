//
//  NJProductCell.m
//  09-彩票(lottery)
//
//  Created by apple on 14-6-17.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "NJSettingCell.h"
#import "NJSettingItem.h"
#import "NJSettingArrowItem.h"
#import "NJSettingSwitchItem.h"
#import "NJSettingLabelItem.h"

@interface NJSettingCell ()
@property (nonatomic, strong) UIImageView *arrowIv;
@property (nonatomic, strong) UISwitch *switchBtn;
@property (nonatomic, strong) UILabel *labelView;
@property (weak, nonatomic) UIView *divider;

@end

@implementation NJSettingCell

- (UIImageView *)arrowIv
{
    if (_arrowIv == nil) {
       _arrowIv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"CellArrow"]];
    }
    return _arrowIv;
}

- (UISwitch *)switchBtn
{
    if (_switchBtn == nil) {
        _switchBtn = [[UISwitch alloc] init];
        // 添加switchBtn监听方法
        [_switchBtn addTarget:self action:@selector(switchBtnChange) forControlEvents:UIControlEventValueChanged];
    }
    return _switchBtn;
}

#pragma mark - switchBtn的监听方法
- (void)switchBtnChange
{
    // 存储数据
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    [defaults setBool:self.switchBtn.isOn forKey:self.item.tilte];
    
    [defaults synchronize];
}

- (UILabel *)labelView
{
    if (_labelView == nil) {
        _labelView = [[UILabel alloc] init];
        _labelView.frame = CGRectMake(250, 0, 100, 44);
        _labelView.backgroundColor = [UIColor redColor];
    }
    return _labelView;
}

+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    static NSString *identifier = @"cell";
    NJSettingCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[NJSettingCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        // 1.设置背景颜色
        [self setupBackgroud];
        // 2.清空子控件
        [self clearSubView];
        // 3.添加分割线
        [self addDivider];
        
        
        
    }
    return self;
}

#pragma mark - 添加分割线
- (void)addDivider
{
    if (!iOS7) {
        UIView *divider = [[UIView alloc] init];
        divider.backgroundColor = [UIColor blackColor];
        [self.contentView addSubview:divider];
        divider.alpha = 0.4;
        self.divider = divider;
    }
}

#pragma mark - 清空子控件
- (void)clearSubView
{
    // 清空子视图的背景颜色
    self.textLabel.backgroundColor = [UIColor clearColor];
    self.detailTextLabel.backgroundColor = [UIColor clearColor];
}

#pragma mark - 设置背景颜色
- (void)setupBackgroud
{
    UIView *selView = [[UIView alloc] init];
    selView.backgroundColor = [UIColor colorWithRed:232/255.0 green:228/255.0 blue:209/255.0 alpha:1];
    self.selectedBackgroundView = selView;
    
    UIView *norViem = [[UIView alloc] init];
    norViem.backgroundColor = [UIColor whiteColor];
    self.backgroundView = norViem;
    
}


- (void)setFrame:(CGRect)frame
{
    if (!iOS7) {
        frame.size.width += 20;
        frame.origin.x -= 20;
    }
    [super setFrame:frame];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    CGFloat dividerX = 0;
    CGFloat dividerW = [UIScreen mainScreen].bounds.size.width;
    CGFloat dividerH = 1;
    CGFloat dividerY = self.contentView.frame.size.height - dividerH;
    
    self.divider.frame = CGRectMake(dividerX, dividerY, dividerW, dividerH);
}

- (void)setHiddenLastDivider:(BOOL)hiddenLastDivider
{
    self.divider.hidden = YES;
}

- (void)setItem:(NJSettingItem *)item
{
    _item = item;
    // 设置数据
    self.textLabel.text = _item.tilte;
    self.imageView.image = [UIImage imageNamed:_item.icon];
    
    // 设置辅助视图
    if ([_item isKindOfClass:[NJSettingArrowItem class]]) {
        self.accessoryView = self.arrowIv;
        self.detailTextLabel.text = self.item.subTitle;
        
    }else if ([_item isKindOfClass:[NJSettingSwitchItem class]])
    {
        self.accessoryView = self.switchBtn;
        // 恢复存储的状态
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        self.switchBtn.on = [defaults boolForKey:self.item.tilte];
        
        // 设置没有选中样式
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }else if ([_item isKindOfClass:[NJSettingLabelItem class]]) {
        self.accessoryView = self.labelView;
    }else
    {
        self.accessoryView = nil;
    }
    
}
@end
