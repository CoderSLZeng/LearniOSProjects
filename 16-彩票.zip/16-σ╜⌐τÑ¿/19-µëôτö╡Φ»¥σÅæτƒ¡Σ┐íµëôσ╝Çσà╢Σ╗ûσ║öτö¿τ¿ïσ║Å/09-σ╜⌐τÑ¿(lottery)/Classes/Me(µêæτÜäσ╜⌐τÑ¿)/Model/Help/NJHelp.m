//
//  NJHelp.m
//  09-彩票(lottery)
//
//  Created by Zeng on 15/12/8.
//  Copyright © 2015年 heima. All rights reserved.
//

#import "NJHelp.h"

@implementation NJHelp
- (instancetype)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        self.title = dict[@"title"];
        self.html = dict[@"html"];
        self.tagId = dict[@"id"];
    }
    return self;
}

+ (instancetype)helpWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}
@end
