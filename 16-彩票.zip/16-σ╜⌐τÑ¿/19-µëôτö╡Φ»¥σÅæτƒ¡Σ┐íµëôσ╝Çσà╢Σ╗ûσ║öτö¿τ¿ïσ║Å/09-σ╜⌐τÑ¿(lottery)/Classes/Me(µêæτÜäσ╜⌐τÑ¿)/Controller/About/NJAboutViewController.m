//
//  NJAboutViewController.m
//  09-彩票(lottery)
//
//  Created by Zeng on 15/12/8.
//  Copyright © 2015年 heima. All rights reserved.
//

#import "NJAboutViewController.h"
#import "NJAboutHeaderView.h"

@interface NJAboutViewController ()

@property (nonatomic, strong) UIWebView *webView;

@end

@implementation NJAboutViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NJSettingItem *item00 = [[NJSettingArrowItem alloc] initWithIcon:nil title:@"评分支持"];
    item00.option = ^{
        NSString *appid = @"717804289";
        NSString *str = [NSString stringWithFormat:@"itms-apps://itunes.apple.com/cn/app/id%@?mt=8", appid];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
    };
    
    NJSettingItem *item01 = [[NJSettingArrowItem alloc] initWithIcon:nil title:@"客服电话"];
    item01.subTitle = @"15015268866";
    item01.option = ^{
        if (_webView == nil) {
            _webView = [[UIWebView alloc] initWithFrame:CGRectZero];
        }
        [_webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"tel://15015268866"]]];
        
    };
    
    NJSettingGroup *group = [[NJSettingGroup alloc] init];
    group.items = @[item00, item01];

    
    [self.datas addObject:group];
    
    self.tableView.tableHeaderView = [NJAboutHeaderView headerView];
    
    
}

@end
