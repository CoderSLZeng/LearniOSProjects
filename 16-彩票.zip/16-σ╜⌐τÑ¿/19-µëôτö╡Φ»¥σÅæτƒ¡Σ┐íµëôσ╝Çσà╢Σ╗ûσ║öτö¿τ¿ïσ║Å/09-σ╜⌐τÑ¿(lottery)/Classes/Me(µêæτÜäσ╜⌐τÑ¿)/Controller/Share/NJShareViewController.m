
//
//  NJShareViewController.m
//  09-彩票(lottery)
//
//  Created by Zeng on 15/12/8.
//  Copyright © 2015年 heima. All rights reserved.
//

#import "NJShareViewController.h"
#import "MessageUI/MessageUI.h"

@interface NJShareViewController () <MFMessageComposeViewControllerDelegate, MFMailComposeViewControllerDelegate>

@end

@implementation NJShareViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    NJSettingArrowItem *weibo = [[NJSettingArrowItem alloc] initWithIcon:@"WeiboSina" title:@"新浪微博"];
    
    NJSettingArrowItem *sms = [[NJSettingArrowItem alloc] initWithIcon:@"SmsShare" title:@"短信分享"];
    sms.option = ^{
      
        if (![MFMessageComposeViewController canSendText]) {
            NSLog(@"当前设备不能发送短信");
            return ;
        }
        
        MFMessageComposeViewController *vc = [[MFMessageComposeViewController alloc] init];
        // 设置短信内容
        vc.body = @"吃饭了没？";
        // 设置收件人列表
        vc.recipients = @[@"10010"];
        // 设置代理
        vc.messageComposeDelegate = self;
        // 显示控制器
        [self presentViewController:vc animated:YES completion:nil];
        
    };
    
    NJSettingArrowItem *mail = [[NJSettingArrowItem alloc] initWithIcon:@"MailShare" title:@"邮件分享"];
    mail.option = ^{
        if (![MFMailComposeViewController canSendMail]) {
            NSLog(@"当前设备不能发送邮件");
            return ;
        }
        
        MFMailComposeViewController *vc = [[MFMailComposeViewController alloc] init];
        // 设置邮件主题
        [vc setSubject:@"会议"];
        // 设置邮件内容
        [vc setMessageBody:@"今天下午开水吧" isHTML:NO];
        // 设置收件人列表
        [vc setToRecipients:@[@"359297567@qq.com"]];
        // 设置抄送人列表
        [vc setCcRecipients:@[@"mumu.zeng@icloud.com"]];
        // 设置密送人列表
        [vc setBccRecipients:@[@"321124168@qq.com"]];
        
        // 设置附件（一张图片）
        UIImage *image = [UIImage imageNamed:@"lufy.jpeg"];
        NSData *data = UIImageJPEGRepresentation(image, 0.5);
        [vc addAttachmentData:data mimeType:@"image/jepg" fileName:@"lufy.jpeg"];
        
        vc.mailComposeDelegate = self;
        
        [self presentViewController:vc animated:YES completion:nil];
        
    };
    
    NJSettingGroup *group = [[NJSettingGroup alloc] init];
    
    group.items = @[weibo, sms, mail];
    
    [self.datas addObject:group];
    
}
#pragma mark - MFMailComposeViewControllerDelegate
- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    [controller dismissViewControllerAnimated:YES completion:nil];
    
    if (result == MFMailComposeResultCancelled) {
        NSLog(@"取消发送");
    } else if (result == MFMailComposeResultSent) {
        NSLog(@"已经发送");
    } else {
        NSLog(@"发送失败");
    }
}

#pragma mark -  MFMessageComposeViewControllerDelegate
- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    NSLog(@"didFinishWithResult");
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
    
    if (MessageComposeResultCancelled == result) {
        NSLog(@"取消发送");
    } else if (MessageComposeResultSent == result)
    {
        NSLog(@"发送成功");
    }else {
        NSLog(@"发送失败");
    }
}

@end
