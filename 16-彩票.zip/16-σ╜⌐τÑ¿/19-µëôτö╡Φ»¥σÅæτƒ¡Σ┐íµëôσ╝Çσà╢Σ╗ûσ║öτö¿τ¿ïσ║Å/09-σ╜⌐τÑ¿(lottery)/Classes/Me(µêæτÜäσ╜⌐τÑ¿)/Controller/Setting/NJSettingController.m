//
//  NJSettingController.m
//  09-彩票(lottery)
//
//  Created by apple on 14-6-17.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "NJSettingController.h"
#import "MBProgressHUD+NJ.h"
#import "NJProductViewController.h"
#import "NJPushNoticeViewController.h"
#import "NJHelpViewController.h"
#import "NJAboutViewController.h"
#import "NJShareViewController.h"

@implementation NJSettingController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self add0SectionItems];
    [self add1SectionItems];
}

#pragma mark 添加第0组的模型数据
- (void)add0SectionItems
{
    // 1.1.推送和提醒
    NJSettingArrowItem *push = [[NJSettingArrowItem alloc]initWithIcon:@"MorePush" title:@"推送和提醒" destClass:[NJPushNoticeViewController class]];
    
    // 1.2.摇一摇机选
    NJSettingSwitchItem *shake = [[NJSettingSwitchItem alloc ]initWithIcon:@"handShake" title:@"摇一摇机选"];
    
    // 1.3.声音效果
    NJSettingSwitchItem *sound = [[NJSettingSwitchItem alloc] initWithIcon:@"sound_Effect" title:@"声音效果"];
    
    NJSettingGroup *group = [[NJSettingGroup alloc] init];
    group.items = @[push, shake, sound];
    [self.datas addObject:group];
}
#pragma mark 添加第1组的模型数据
- (void)add1SectionItems
{
    // 2.1.检查新版本
    NJSettingArrowItem *update = [[NJSettingArrowItem alloc ]initWithIcon:@"MoreUpdate" title:@"检查新版本"];
    update.option = ^{
        // 模拟发送网络请求
        [MBProgressHUD showMessage:@"正在拼命检查..."];
        // 2秒之后删除提示
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUD];
            // 提示没有新版本
            [MBProgressHUD showSuccess:@"亲~没有新版本"];
        });
    };
    
    // 2.2.帮助
    NJSettingArrowItem *help = [[NJSettingArrowItem alloc ]initWithIcon:@"MoreHelp" title:@"帮助" destClass:[NJHelpViewController class]];

    
    // 2.3.分享
    NJSettingArrowItem *share = [[NJSettingArrowItem alloc ]initWithIcon:@"MoreShare" title:@"分享" destClass:[NJShareViewController class]];

    
    // 2.4.查看消息
    NJSettingArrowItem *msg = [[NJSettingArrowItem alloc ]initWithIcon:@"MoreMessage" title:@"查看消息"];
    
    // 2.5.产品推荐
    NJSettingArrowItem *product = [[NJSettingArrowItem alloc ]initWithIcon:@"MoreNetease" title:@"产品推荐" destClass: [NJProductViewController class]];
    
    // 2.6.关于
    NJSettingArrowItem *about = [[NJSettingArrowItem alloc ]initWithIcon:@"MoreAbout" title:@"关于" destClass:[NJAboutViewController class]];
    
    NJSettingGroup *group = [[NJSettingGroup alloc] init ];
    group.items = @[update, help, share, msg, product, about];
    [self.datas addObject:group];
}

@end
