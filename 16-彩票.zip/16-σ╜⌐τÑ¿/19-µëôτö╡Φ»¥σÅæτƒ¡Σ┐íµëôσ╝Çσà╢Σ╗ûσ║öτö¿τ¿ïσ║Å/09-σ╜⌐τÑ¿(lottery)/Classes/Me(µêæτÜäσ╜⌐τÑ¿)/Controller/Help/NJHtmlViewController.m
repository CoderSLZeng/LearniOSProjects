//
//  NJHtmlViewController.m
//  09-彩票(lottery)
//
//  Created by Zeng on 15/12/8.
//  Copyright © 2015年 heima. All rights reserved.
//

#import "NJHtmlViewController.h"
#import "NJHelp.h"

@interface NJHtmlViewController () <UIWebViewDelegate>

@end

@implementation NJHtmlViewController

- (void)loadView
{
    self.view = [[UIWebView alloc] init];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title =  self.helpModel.title;
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"关闭" style:UIBarButtonItemStylePlain target:self action:@selector(closeVc)];
    
    UIWebView *webView = (UIWebView *)self.view;
    webView.delegate = self;
    
    NSString *path = [[NSBundle mainBundle] pathForResource:self.helpModel.html ofType:nil];
    
    NSURL *url = [[NSURL alloc] initFileURLWithPath:path];
    
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    
    [webView loadRequest:request];
}

- (void)closeVc
{
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
}

#pragma mark - UIWebViewDelegate
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    NSString *jsStr = [NSString stringWithFormat:@"window.location.href = '#%@';", self.helpModel.tagId];
    [webView stringByEvaluatingJavaScriptFromString:jsStr];
}

@end
