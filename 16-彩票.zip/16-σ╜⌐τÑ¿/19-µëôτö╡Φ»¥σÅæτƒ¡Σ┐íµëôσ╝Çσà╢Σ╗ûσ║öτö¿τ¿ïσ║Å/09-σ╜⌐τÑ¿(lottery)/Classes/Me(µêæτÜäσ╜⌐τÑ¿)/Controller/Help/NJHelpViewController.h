//
//  NJHelpViewController.h
//  09-彩票(lottery)
//
//  Created by Zeng on 15/12/8.
//  Copyright © 2015年 heima. All rights reserved.
//

#import "NJBaseViewController.h"

@interface NJHelpViewController : NJBaseViewController

@end
