//
//  NJHelpViewController.m
//  09-彩票(lottery)
//
//  Created by Zeng on 15/12/8.
//  Copyright © 2015年 heima. All rights reserved.
//

#import "NJHelpViewController.h"
#import "NJHelp.h"
#import "NJHtmlViewController.h"

@interface NJHelpViewController ()

@property (nonatomic, strong) NSArray *helps;

@end

@implementation NJHelpViewController

#pragma mark - 懒加载
- (NSArray *)helps
{
    if (_helps == nil) {
        NSString *path = [[NSBundle mainBundle] pathForResource:@"help.json" ofType:nil];
        NSData *data = [NSData dataWithContentsOfFile:path];
        NSArray *dictArray = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:NULL];
        
        NSMutableArray *models = [NSMutableArray arrayWithCapacity:dictArray.count];
        for (NSDictionary *dict in dictArray) {
            NJHelp *help = [NJHelp helpWithDict:dict];
            [models addObject:help];
        }
        _helps = models;
    }
    return _helps;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSMutableArray *items = [NSMutableArray arrayWithCapacity:self.helps.count];
    
    for (NJHelp *help in self.helps) {
        NJSettingItem *item = [[NJSettingArrowItem alloc] initWithIcon:nil title:help.title];
        [items addObject:item];
    }
    
    NJSettingGroup *group = [[NJSettingGroup alloc] init];
    group.items = items;
    [self.datas addObject:group];
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NJHtmlViewController *htmlVc = [[NJHtmlViewController alloc] init];
    
    htmlVc.helpModel = self.helps[indexPath.row];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:htmlVc];
    
    [self presentViewController:nav animated:YES completion:^{
        
    }];
}




@end
