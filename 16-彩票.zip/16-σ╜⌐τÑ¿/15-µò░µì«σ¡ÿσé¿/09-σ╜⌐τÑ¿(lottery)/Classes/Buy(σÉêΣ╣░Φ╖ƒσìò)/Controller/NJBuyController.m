//
//  NJBuyController.m
//  09-彩票(lottery)
//
//  Created by apple on 14-6-17.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "NJBuyController.h"
#import "NJTitleButton.h"

@interface NJBuyController ()
- (IBAction)titleBtnOnClick:(NJTitleButton *)sender;

// 定义变量记录当前按钮的状态
@property (nonatomic, assign, getter = isOpen) BOOL open;

@property (nonatomic, weak) UIView *contentView;
@end

@implementation NJBuyController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // 添加将来需要显示的View
    UIView *contentView = [[UIView alloc] init];
    contentView.backgroundColor = [UIColor purpleColor];
    contentView.frame = CGRectMake(0, 64, 320, 200);
    [self.view addSubview:contentView];
    self.contentView = contentView;
    // 隐藏该View
    contentView.hidden = YES;
}

- (IBAction)titleBtnOnClick:(NJTitleButton *)titleBtn
{
    if (!self.isOpen) {// 没有打开
        [UIView animateWithDuration:1.0 animations:^{
            // 1.旋转按钮上的尖尖
            titleBtn.imageView.transform = CGAffineTransformMakeRotation(M_PI);
        }];
        // 改变当前按钮的状态
        self.open = YES;
        
        // 显示内容view
        self.contentView.hidden = NO;
    }else // 已经打开
    {
        [UIView animateWithDuration:1.0 animations:^{
            // 1.旋转按钮上的尖尖
            titleBtn.imageView.transform = CGAffineTransformIdentity;
        }];
        // 改变当前按钮的状态
        self.open = NO;
        
        // 隐藏内容View
        self.contentView.hidden = YES;
    }
    
}
@end
