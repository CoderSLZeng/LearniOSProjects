//
//  NJTabBarButton.m
//  09-彩票(lottery)
//
//  Created by apple on 14-6-16.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "NJTabBarButton.h"

@implementation NJTabBarButton

// 重写该方法,禁止直行系统自带复杂操作
- (void)setHighlighted:(BOOL)highlighted
{
}

@end
