//
//  NJTabBarController.m
//  09-彩票(lottery)
//
//  Created by apple on 14-6-16.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "NJTabBarController.h"
#import "NJTabBar.h"
#import "NJTabBarButton.h"

@interface NJTabBarController ()<NJTabBarDelegate>

@end

@implementation NJTabBarController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // 扩展控制器view的上面和下面
//    self.edgesForExtendedLayout = UIRectEdgeTop | UIRectEdgeBottom;
    
    // 1.创建自定义的TabBar
    NJTabBar *myTabBar = [[NJTabBar alloc] init];
//    myTabBar.frame = self.tabBar.frame; // 特别注意:此处frame的Y值有问题
    myTabBar.frame = self.tabBar.bounds;
    myTabBar.delegate = self;
//    [self.view addSubview:myTabBar];
    [self.tabBar addSubview:myTabBar];
    
    // 1.1根据系统子控制器的个数来创建自定义TabBar上按钮的个数
    for (int i = 0; i < self.viewControllers.count; i++) {
        // 通知自定义TabBar创建按钮
         NSString *norImageName = [NSString stringWithFormat:@"TabBar%d", i + 1];
        NSString *disableImageName = [NSString stringWithFormat:@"TabBar%dSel", i + 1];
        // 只要调用自定义TabBar的该方法就会创建一个按钮
        [myTabBar addTabBarButtonWithNormalImageName:norImageName andDisableImageName:disableImageName];
    }

    // 2.删除系统自带的tabBar
//    [self.tabBar removeFromSuperview];

}

#pragma mark - NJTabBarDelegate
- (void)tabBarDidSelectBtnFrom:(NSInteger)from to:(NSInteger)to
{
    // 切换子控制器
    self.selectedIndex = to;
}

@end
