//
//  NJProductCell.m
//  09-彩票(lottery)
//
//  Created by apple on 14-6-17.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "NJSettingCell.h"
#import "NJSettingItem.h"
#import "NJSettingArrowItem.h"
#import "NJSettingSwitchItem.h"
#import "NJSettingLabelItem.h"

@interface NJSettingCell ()
@property (nonatomic, strong) UIImageView *arrowIv;
@property (nonatomic, strong) UISwitch *switchBtn;
@property (nonatomic, strong) UILabel *labelView;

@end

@implementation NJSettingCell

- (UIImageView *)arrowIv
{
    if (_arrowIv == nil) {
       _arrowIv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"CellArrow"]];
    }
    return _arrowIv;
}

- (UISwitch *)switchBtn
{
    if (_switchBtn == nil) {
        _switchBtn = [[UISwitch alloc] init];
        // 添加switchBtn监听方法
        [_switchBtn addTarget:self action:@selector(switchBtnChange) forControlEvents:UIControlEventValueChanged];
    }
    return _switchBtn;
}

#pragma mark - switchBtn的监听方法
- (void)switchBtnChange
{
    // 存储数据
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    [defaults setBool:self.switchBtn.isOn forKey:self.item.tilte];
    
    [defaults synchronize];
}

- (UILabel *)labelView
{
    if (_labelView == nil) {
        _labelView = [[UILabel alloc] init];
        _labelView.frame = CGRectMake(250, 0, 100, 44);
        _labelView.backgroundColor = [UIColor redColor];
    }
    return _labelView;
}

+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    static NSString *identifier = @"cell";
    NJSettingCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[NJSettingCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

- (void)setItem:(NJSettingItem *)item
{
    _item = item;
    // 设置数据
    self.textLabel.text = _item.tilte;
    self.imageView.image = [UIImage imageNamed:_item.icon];
    
    // 设置辅助视图
    if ([_item isKindOfClass:[NJSettingArrowItem class]]) {
        self.accessoryView = self.arrowIv;
    }else if ([_item isKindOfClass:[NJSettingSwitchItem class]])
    {
        self.accessoryView = self.switchBtn;
        // 恢复存储的状态
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        self.switchBtn.on = [defaults boolForKey:self.item.tilte];
        
        // 设置没有选中样式
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }else if ([_item isKindOfClass:[NJSettingLabelItem class]]) {
        self.accessoryView = self.labelView;
    }else
    {
        self.accessoryView = nil;
    }
    
}
@end
