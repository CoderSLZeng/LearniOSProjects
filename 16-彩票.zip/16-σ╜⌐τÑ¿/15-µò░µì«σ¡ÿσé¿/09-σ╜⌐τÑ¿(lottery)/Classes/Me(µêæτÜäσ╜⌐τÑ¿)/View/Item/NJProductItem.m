//
//  NJProductItem.m
//  09-彩票(lottery)
//
//  Created by apple on 14-6-19.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "NJProductItem.h"
#import "NJProduct.h"


@interface NJProductItem()
/**
 *  图标
 */
@property (weak, nonatomic) IBOutlet UIImageView *iconView;
/**
 *  名称
 */
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@end
@implementation NJProductItem




/*
- (id)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super initWithCoder:aDecoder]) {

        // 设置图片的主图层圆角
        self.iconView.layer.cornerRadius = 8;
        // 设置超出主图层的部分剪切
//        self.iconView.clipsToBounds = YES;
        self.iconView.layer.masksToBounds = YES;
        NSLog(@"initWithCoder");
    }
    return self;
}
 */


- (void)awakeFromNib
{
    // 设置图片的主图层圆角
    self.iconView.layer.cornerRadius = 8;
    // 设置超出主图层的部分剪切
    self.iconView.clipsToBounds = YES;

}
- (void)setProduct:(NJProduct *)product
{
    _product = product;
    
    // 设置图标
    self.iconView.image = [UIImage imageNamed:self.product.icon];
    // 设置名称
    self.nameLabel.text = self.product.title;
}
@end
