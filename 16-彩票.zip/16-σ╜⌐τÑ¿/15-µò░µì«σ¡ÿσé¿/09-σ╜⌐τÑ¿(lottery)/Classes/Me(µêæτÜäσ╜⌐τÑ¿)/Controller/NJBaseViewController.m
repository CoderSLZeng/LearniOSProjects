//
//  NJBaseViewController.m
//  09-彩票(lottery)
//
//  Created by Zeng on 15/12/8.
//  Copyright © 2015年 heima. All rights reserved.
//

#import "NJBaseViewController.h"

@implementation NJBaseViewController

#pragma mark - 懒加载
- (NSMutableArray *)datas
{
    if (_datas == nil) {
        _datas = [NSMutableArray array];
    }
    return _datas;
}

#pragma mark - 初始化方法
- (id)init
{
    return [super initWithStyle:UITableViewStyleGrouped];
}
- (id)initWithStyle:(UITableViewStyle)style
{
    return [super initWithStyle:UITableViewStyleGrouped];
}

#pragma mark - UITableViewDatasource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.datas.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // 先取出对应组的小数组
    NJSettingGroup *g = self.datas[section];
    // 返回小数组的长度
    return g.items.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 1.创建cell
    NJSettingCell *cell = [NJSettingCell cellWithTableView:tableView];
    
    // 先取出对应组的组模型
    NJSettingGroup *g = self.datas[indexPath.section];
    //  从组模型中取出对应行的模型
    NJSettingItem *item = g.items[indexPath.row];
    cell.item = item;
    
    // 3.返回cell
    return cell;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 立即取消选中
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    // 先取出对应组的组模型
    NJSettingGroup *g = self.datas[indexPath.section];
    //  从组模型中取出对应行的模型
    NJSettingItem *item = g.items[indexPath.row];
    // 判断block中是否保存了代码
    if (item.option != nil) {
        // 如果保存,就执行block中保存的代码
        item.option();
    }else if ([item isKindOfClass:[NJSettingArrowItem class]]) {
        // 创建目标控制并且添加到栈中
        NJSettingArrowItem *arrowItem = (NJSettingArrowItem *)item;
        
        UIViewController *vc = [[arrowItem.destVC alloc] init];
        
        vc.title = arrowItem.tilte;
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    // 先取出对应组的组模型
    NJSettingGroup *g = self.datas[section];
    return g.headerTitle;
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section
{
    // 先取出对应组的组模型
    NJSettingGroup *g = self.datas[section];
    return g.footerTitle;
}

@end
