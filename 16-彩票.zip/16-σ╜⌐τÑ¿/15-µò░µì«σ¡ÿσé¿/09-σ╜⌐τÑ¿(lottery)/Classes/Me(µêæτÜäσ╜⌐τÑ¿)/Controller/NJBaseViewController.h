//
//  NJBaseViewController.h
//  09-彩票(lottery)
//
//  Created by Zeng on 15/12/8.
//  Copyright © 2015年 heima. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NJSettingGroup.h"
#import "NJSettingCell.h"
#import "NJSettingArrowItem.h"
#import "NJSettingSwitchItem.h"
#import "NJSettingLabelItem.h"
#import "MBProgressHUD+NJ.h"
#import "NJTestViewController.h"

@interface NJBaseViewController : UITableViewController

@property (nonatomic, strong) NSMutableArray *datas;

@end
