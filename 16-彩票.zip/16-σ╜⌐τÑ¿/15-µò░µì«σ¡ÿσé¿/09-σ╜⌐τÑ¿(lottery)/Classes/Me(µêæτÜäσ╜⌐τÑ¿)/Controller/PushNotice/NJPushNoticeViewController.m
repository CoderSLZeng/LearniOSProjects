//
//  NJSettingController.m
//  09-彩票(lottery)
//
//  Created by apple on 14-6-17.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "NJPushNoticeViewController.h"
#import "NJAwardViewController.h"
#import "NJNJAwardAnimationViewController.h"
#import "NJScoreTimeViewController.h"

@implementation NJPushNoticeViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self add0SectionItems];
}

#pragma mark 添加第0组的模型数据
- (void)add0SectionItems
{
    NJSettingItem *item00 = [[NJSettingArrowItem alloc] initWithIcon:nil title:@"开奖号码推送" destClass:[NJAwardViewController class]];
    NJSettingItem *item01 = [[NJSettingArrowItem alloc] initWithIcon:nil title:@"中奖动画" destClass:[NJNJAwardAnimationViewController class]];
    NJSettingItem *item02 = [[NJSettingArrowItem alloc] initWithIcon:nil title:@"比分直播" destClass:[NJScoreTimeViewController class]];
    
    NJSettingItem *item03 = [[NJSettingArrowItem alloc] initWithIcon:nil title:@"购彩定时提醒" destClass:[NJTestViewController class]];
    
    NJSettingGroup *group = [[NJSettingGroup alloc] init];
    
    group.items = @[item00, item01, item02, item03];
    
    [self.datas addObject:group];
}

@end
