//
//  NJAwardViewController.m
//  09-彩票(lottery)
//
//  Created by Zeng on 15/12/8.
//  Copyright © 2015年 heima. All rights reserved.
//

#import "NJAwardViewController.h"

@interface NJAwardViewController ()

@end

@implementation NJAwardViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self add0SectionItems];
}

#pragma mark 添加第0组的模型数据
- (void)add0SectionItems
{
    NJSettingItem *item00 = [[NJSettingSwitchItem alloc] initWithIcon:nil title:@"双色球"];
    NJSettingItem *item01 = [[NJSettingSwitchItem alloc] initWithIcon:nil title:@"大乐透"];
    
    NJSettingGroup *group = [[NJSettingGroup alloc] init];
    
    group.headerTitle = @"大家萨分瓦房费建安大数据来看放大镜好看看记录";
    
    group.items = @[item00, item01];
    
    [self.datas addObject:group];
}
@end
