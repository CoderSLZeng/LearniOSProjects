//
//  NJNJAwardAnimationViewController.m
//  09-彩票(lottery)
//
//  Created by Zeng on 15/12/8.
//  Copyright © 2015年 heima. All rights reserved.
//

#import "NJNJAwardAnimationViewController.h"

@interface NJNJAwardAnimationViewController ()

@end

@implementation NJNJAwardAnimationViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self add0SectionItems];
}

#pragma mark 添加第0组的模型数据
- (void)add0SectionItems
{
    NJSettingItem *item00 = [[NJSettingSwitchItem alloc] initWithIcon:nil title:@"中奖动画"];
    
    NJSettingGroup *group = [[NJSettingGroup alloc] init];
    
    group.footerTitle = @"328147892137491734";
    
    group.items = @[item00];
    
    [self.datas addObject:group];
}


@end
