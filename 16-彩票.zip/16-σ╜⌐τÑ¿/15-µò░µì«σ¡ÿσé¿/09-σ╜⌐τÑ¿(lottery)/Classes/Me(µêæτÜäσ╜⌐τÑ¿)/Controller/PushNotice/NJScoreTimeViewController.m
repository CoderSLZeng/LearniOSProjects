//
//  NJScoreTimeViewController.m
//  09-彩票(lottery)
//
//  Created by Zeng on 15/12/8.
//  Copyright © 2015年 heima. All rights reserved.
//

#import "NJScoreTimeViewController.h"

@interface NJScoreTimeViewController ()

@end

@implementation NJScoreTimeViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self add0SectionItems];
}

#pragma mark 添加第0组的模型数据
- (void)add0SectionItems
{
    NJSettingItem *item00 = [[NJSettingSwitchItem alloc] initWithIcon:nil title:@"提醒我关注的比赛"];
    NJSettingGroup *group0 = [[NJSettingGroup alloc] init];
    group0.footerTitle = @"328147892137491734";
    group0.items = @[item00];
    
    NJSettingItem *item10 = [[NJSettingLabelItem alloc] initWithIcon:nil title:@"起始时间"];
    NJSettingGroup *group1 = [[NJSettingGroup alloc] init];
    group1.items = @[item10];
    
    NJSettingItem *item20 = [[NJSettingLabelItem alloc] initWithIcon:nil title:@"结束时间"];
    NJSettingGroup *group2 = [[NJSettingGroup alloc] init];
    group2.items = @[item20];
    
    [self.datas addObject:group0];
    [self.datas addObject:group1];
    [self.datas addObject:group2];
    
}


@end
