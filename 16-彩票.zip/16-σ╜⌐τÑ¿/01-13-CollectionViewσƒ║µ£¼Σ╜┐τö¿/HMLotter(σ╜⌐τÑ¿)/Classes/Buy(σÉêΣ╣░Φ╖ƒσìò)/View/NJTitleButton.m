//
//  NJTitleButton.m
//  HMLotter(彩票)
//
//  Created by Luffy on 15/9/18.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJTitleButton.h"
#import <Availability.h>

@interface NJTitleButton()

@property (nonatomic, strong) UIFont *myFont;

@end

@implementation NJTitleButton

- (id)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super initWithCoder:aDecoder]) {
        [self setup];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self setup];
    }
    return self;
}

- (void)setup
{
    // 记录按钮标题字体
    _myFont = [UIFont systemFontOfSize:15];
    // 设置标题字体
    self.titleLabel.font = _myFont;
    // 设置按钮的图片显示的内容默认为居中（为了不拉伸）
    self.imageView.contentMode = UIViewContentModeCenter;
    
}

// 用于返回按钮上标题的位置，传入按钮的rect
- (CGRect)titleRectForContentRect:(CGRect)contentRect
{
    CGFloat titleX = 0;
    CGFloat titleY = 0;
    CGFloat titleH = contentRect.size.height;
    CGFloat titleW = 0;
    
    // 获取当前按钮上的文字
    NSString *title = self.currentTitle;
    CGSize maxSize = CGSizeMake(MAXFLOAT, MAXFLOAT);
    NSMutableDictionary *dictM = [NSMutableDictionary dictionary];
    dictM[NSFontAttributeName] = self.myFont;
    
    // 计算文字的范围
    // 判断是否是XCode5，如果是就编译一下代码，如果不是就不编译
#ifdef __IPHONE_7_0
    if ([[UIDevice currentDevice].systemVersion doubleValue] >= 7.0) {
        
        CGRect titleRect = [title boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:dictM context:nil];
        titleW = titleRect.size.width;
    } else {
        // 非iOS7
        CGSize titleSize = [title sizeWithFont:self.myFont];
        titleW = titleSize.width;
    }
#else 
    
    CGSize titleSize = [title sizeWithFont:self.myFont];
    titleW = titleSize.width;
    
#endif
    

    
    return CGRectMake(titleX, titleY, titleW, titleH);
}

// 用于返回按钮上图片的位置，传入按钮的rect
- (CGRect)imageRectForContentRect:(CGRect)contentRect
{
    CGFloat imageW = 16;
    CGFloat imageH = contentRect.size.height;
    CGFloat imageX = contentRect.size.width - imageW;
    CGFloat imageY = 0;
    
    return CGRectMake(imageX, imageY, imageW, imageH);
}





@end
