//
//  NJBuyController.h
//  HMLotter(彩票)
//
//  Created by Luffy on 15/9/18.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NJBuyController : UIViewController

@end
