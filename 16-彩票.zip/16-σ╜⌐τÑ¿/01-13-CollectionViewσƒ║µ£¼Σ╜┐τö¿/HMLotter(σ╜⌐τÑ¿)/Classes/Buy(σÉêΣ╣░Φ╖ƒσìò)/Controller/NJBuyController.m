//
//  NJBuyController.m
//  HMLotter(彩票)
//
//  Created by Luffy on 15/9/18.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJBuyController.h"
#import "NJTitleButton.h"

@interface NJBuyController ()

@property (weak, nonatomic) UIView *contenView;

@property (nonatomic, assign, getter = isOpen) BOOL open;

@end

@implementation NJBuyController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 添加将来需要显示的View
    UIView *contentView = [[UIView alloc] init];
    contentView.backgroundColor = [UIColor purpleColor];
    contentView.frame = CGRectMake(0, 64, 320, 200);
    [self.view addSubview:contentView];
    self.contenView = contentView;
    
    // 隐藏该View
    contentView.hidden = YES;
    
}
- (IBAction)titleBtnOnClick:(NJTitleButton *)titleBtn {
    
    if (!self.isOpen) { // 没有打开
        [UIView animateWithDuration:1.0 animations:^{
            // 1.旋转按钮上的尖尖
            titleBtn.imageView.transform = CGAffineTransformMakeRotation(M_PI);
        }];
        // 改变当前按钮的状态
        self.open = YES;
        
        // 显示内容View
        self.contenView.hidden = NO;
    } else {
        [UIView animateWithDuration:1.0 animations:^{
            titleBtn.imageView.transform = CGAffineTransformIdentity;
        }];
//        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//            titleBtn.imageView.transform = CGAffineTransformIdentity;
//        });
        
        self.open = NO;
        self.contenView.hidden = YES;
    }
    
}



@end
