//
//  NJTabBarController.m
//  HMLotter(彩票)
//
//  Created by Luffy on 15/9/17.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJTabBarController.h"
#import "NJTabBar.h"

@interface NJTabBarController () <NJTabBarDelegate>
@end

@implementation NJTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 1.创建自定义的tabBar
    NJTabBar *myTabBar = [[NJTabBar alloc] init];
//    myTabBar.frame = self.tabBar.frame;
    myTabBar.frame = self.tabBar.bounds;
    myTabBar.delegate = self;
//    [self.view addSubview:myTabBar];
    [self.tabBar addSubview:myTabBar];
    
    // 1.1根据系统子控制器的个数来创建自定义TabBar上的按钮个数
    for (int i = 0; i < self.childViewControllers.count; i++) {
        NSString *norImageName = [NSString stringWithFormat:@"TabBar%d", i + 1];
        NSString *disableImageName = [NSString stringWithFormat:@"TabBar%dSel", i + 1];
        [myTabBar addTabBarButtonWithNormalImageName:norImageName andDisableImageName:disableImageName];
    }
    
    // 2.删除系统自带的tabBar
//    [self.tabBar removeFromSuperview];
    
    }


#pragma mark - NJTabBarDelegate
- (void)tabBar:(NJTabBar *)tabBar didselectedIndex:(NSInteger)index
{
    // 切换子控制器
    self.selectedIndex = index;
}

@end
