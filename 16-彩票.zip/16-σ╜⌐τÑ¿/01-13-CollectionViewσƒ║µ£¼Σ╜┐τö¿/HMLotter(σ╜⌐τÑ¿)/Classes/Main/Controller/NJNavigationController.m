//
//  NJNavigationController.m
//  HMLotter(彩票)
//
//  Created by Luffy on 15/9/20.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJNavigationController.h"

@interface NJNavigationController ()

@end

@implementation NJNavigationController

+ (void)initialize
{
    // 1.设置导航条的主题
    UINavigationBar *navBar = [UINavigationBar appearance];
    // 1.1设置所有导航条的背景图片
    // 判断当前运行的操作系统版本
    if ([[UIDevice currentDevice].systemVersion doubleValue] >= 7.0) {
        [navBar setBackgroundImage:[UIImage imageNamed:@"NavBar64"] forBarMetrics:UIBarMetricsDefault];
    } else {
        [navBar setBackgroundImage:[UIImage imageNamed:@"NavBar"] forBarMetrics:UIBarMetricsDefault];
    }
    
    [navBar setTintColor:[UIColor whiteColor]];
    
    // 1.2设置所有导航条的标题颜色
    NSMutableDictionary *dictM = [NSMutableDictionary dictionary];
    dictM[NSFontAttributeName] = [UIFont systemFontOfSize:16];
    dictM[NSForegroundColorAttributeName] = [UIColor whiteColor];
    
    [navBar setTitleTextAttributes:dictM];
    
    UIBarButtonItem *barItem = [UIBarButtonItem appearance];
    
    if ([[UIDevice currentDevice].systemVersion doubleValue] >= 7.0) {
        [barItem setTitleTextAttributes:dictM forState:UIControlStateNormal];
    } else {
        UIImage *norImage = [UIImage imageNamed:@"NavButton"];
        [barItem setBackButtonBackgroundImage:norImage forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
        UIImage *higImage = [UIImage imageNamed:@"NavButtonPressed"];
        [barItem setBackButtonBackgroundImage:higImage forState:UIControlStateHighlighted barMetrics:UIBarMetricsDefault];
        
        UIImage *norBackImage = [UIImage imageNamed:@"NavBackButton"];
        [barItem setBackButtonBackgroundImage:norBackImage forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
        UIImage *higBackImage = [UIImage imageNamed:@"NavBackButtonPressed"];
        [barItem setBackButtonBackgroundImage:higBackImage forState:UIControlStateHighlighted barMetrics:UIBarMetricsDefault];
    }

}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
//      NSLog(@"%s", __func__);
    viewController.hidesBottomBarWhenPushed = YES;
    [super pushViewController:viewController animated:animated];
}


@end
