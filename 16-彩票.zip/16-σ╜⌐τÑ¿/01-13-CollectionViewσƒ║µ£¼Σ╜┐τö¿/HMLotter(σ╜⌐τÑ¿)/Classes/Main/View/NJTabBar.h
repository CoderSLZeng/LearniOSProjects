//
//  NJTabBar.h
//  HMLotter(彩票)
//
//  Created by Luffy on 15/9/17.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>
@class NJTabBar;

@protocol NJTabBarDelegate <NSObject>

@required

- (void)tabBar:(NJTabBar *)tabBar didselectedIndex:(NSInteger)index;

@end

@interface NJTabBar : UIView

@property (weak, nonatomic) id<NJTabBarDelegate> delegate;

/**
 *  提供一个方法给外界创建按钮
 *
 *  @param norName 默认状态的图片
 *  @param disName 高亮状态的图片
 */
- (void)addTabBarButtonWithNormalImageName:(NSString *)norName andDisableImageName:(NSString *)disName;

@end
