//
//  NJTabBar.m
//  HMLotter(彩票)
//
//  Created by Luffy on 15/9/17.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJTabBar.h"
#import "NJTabBarButton.h"

@interface NJTabBar()

@property (weak, nonatomic) UIButton *selectBtn;

@end

@implementation NJTabBar

- (void)addTabBarButtonWithNormalImageName:(NSString *)norName andDisableImageName:(NSString *)disName
{
    // 3.1创建按钮
    NJTabBarButton *btn = [[NJTabBarButton alloc] init];
    // 3.2设置按钮上显示的图片
    [btn setBackgroundImage:[UIImage imageNamed:norName] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:disName] forState:UIControlStateDisabled];
    
    // 3.4添加按钮到自定义tabBar
    [self addSubview:btn];
    
    // 3.5监听按钮点击事件
    [btn addTarget:self action:@selector(btnOnClick:) forControlEvents:UIControlEventTouchDown];

    // 3.6设置默认选中按钮
    if (1 == self.subviews.count) {
        [self btnOnClick:btn];
    }
    
    // 3.7设置按钮高亮状态不调整图片
    btn.adjustsImageWhenHighlighted = NO;

}

// 点击按钮
- (void)btnOnClick:(UIButton *)btn
{
//    NSLog(@"%s", __func__);
    
    // 0.取消上一次选中的按钮
    _selectBtn.enabled = YES;
    
    // 1.设置当前被点击按钮为选中状态
    btn.enabled = NO;
    
    // 2.记录当前选中的按钮
    _selectBtn = btn;
    
    // 3.切换子控制器
    if ([self.delegate respondsToSelector:@selector(tabBar:didselectedIndex:)]) {
        [self.delegate tabBar:self didselectedIndex:btn.tag];
    }
}


- (void)layoutSubviews
{
    [super layoutSubviews];

    // 3.3设置frame
    CGFloat btnW = self.frame.size.width / self.subviews.count;
    CGFloat btnH = self.frame.size.height;
    CGFloat btnX = 0;
    CGFloat btnY = 0;
    
    for (int i = 0; i < self.subviews.count; i++) {
        NJTabBarButton *btn = self.subviews[i];
        
        btnX = i * btnW;
        
        btn.frame = CGRectMake(btnX, btnY, btnW, btnH);
        
        // 3.8设置按钮的Tag作为将来切换子控制器的索引
        btn.tag = i;
        
    }
    
    
}

@end
