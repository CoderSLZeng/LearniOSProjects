//
//  NJTabBarButton.m
//  HMLotter(彩票)
//
//  Created by Luffy on 15/9/17.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJTabBarButton.h"

@implementation NJTabBarButton

// 重写该方法，不调用父类方法
- (void)setHighlighted:(BOOL)highlighted
{
    
}


@end
