//
//  NJSettingCell.m
//  HMLotter(彩票)
//
//  Created by Luffy on 15/9/21.
//  Copyright © 2015年 itcast. All rights reserved.
//

#import "NJSettingCell.h"
#import "NJSettingItem.h"
#import "NJSettingArrowItem.h"
#import "NJSettingSwitchItem.h"

@interface NJSettingCell()

@property (nonatomic, strong) UIImageView *arrowIv;
@property (nonatomic, strong) UISwitch *switchBtn;

@end

@implementation NJSettingCell

- (UIImageView *)arrowIv
{
    if (_arrowIv == nil) {
        _arrowIv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"CellArrow"]];
    }
    return _arrowIv;
}

- (UISwitch *)switchBtn
{
    if (_switchBtn == nil) {
        _switchBtn = [[UISwitch alloc] init];
    }
    return _switchBtn;
}

- (void)setItem:(NJSettingItem *)item
{
    _item = item;
    
    self.textLabel.text = _item.title;
    self.imageView.image = [UIImage imageNamed:_item.icon];
    
    if ([_item isKindOfClass:[NJSettingArrowItem class]]) {
        self.accessoryView = self.arrowIv;
    } else if ([_item isKindOfClass:[NJSettingSwitchItem class]]) {
        self.accessoryView = self.switchBtn;
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    } else {
        self.accessoryView = nil;
    }
}

+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    static NSString *identifier = @"cell";
    NJSettingCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (cell == nil) {
        cell = [[NJSettingCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}



@end
