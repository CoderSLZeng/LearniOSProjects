//
//  NJSettingCell.h
//  HMLotter(彩票)
//
//  Created by Luffy on 15/9/21.
//  Copyright © 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>
@class NJSettingItem;

@interface NJSettingCell : UITableViewCell

@property (nonatomic, strong) NJSettingItem *item;

+ (instancetype)cellWithTableView:(UITableView *)tableView;

@end
