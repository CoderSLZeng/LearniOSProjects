//
//  NJSettingArrowItem.h
//  HMLotter(彩票)
//
//  Created by Luffy on 15/9/21.
//  Copyright © 2015年 itcast. All rights reserved.
//

#import "NJSettingItem.h"

@interface NJSettingArrowItem : NJSettingItem

@property (nonatomic, assign) Class destVc;

- (instancetype)initWithIcon:(NSString *)icon title:(NSString *)title destClass:(Class)destVc;

@end
