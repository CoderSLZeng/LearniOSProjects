//
//  NJSettingItem.m
//  HMLotter(彩票)
//
//  Created by Luffy on 15/9/21.
//  Copyright © 2015年 itcast. All rights reserved.
//

#import "NJSettingItem.h"

@implementation NJSettingItem

- (instancetype)initWithIcon:(NSString *)icon title:(NSString *)title
{
    if (self = [super init]) {
        _icon = icon;
        _title = title;
    }
    return self;
}

@end
