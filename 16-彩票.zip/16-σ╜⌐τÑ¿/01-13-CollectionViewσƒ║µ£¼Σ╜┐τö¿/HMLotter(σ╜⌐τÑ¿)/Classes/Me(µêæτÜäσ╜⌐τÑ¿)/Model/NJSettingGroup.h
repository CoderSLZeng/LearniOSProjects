//
//  NJSettingGroup.h
//  HMLotter(彩票)
//
//  Created by Luffy on 15/9/21.
//  Copyright © 2015年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NJSettingGroup : NSObject

@property (nonatomic, copy) NSString *headerTitle;

@property (nonatomic, copy) NSString *footerTitle;

@property (nonatomic, strong) NSArray *items;



@end
