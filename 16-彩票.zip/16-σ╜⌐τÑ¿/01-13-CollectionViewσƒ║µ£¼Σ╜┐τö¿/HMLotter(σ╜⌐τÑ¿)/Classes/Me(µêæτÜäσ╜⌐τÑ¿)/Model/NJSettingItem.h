//
//  NJSettingItem.h
//  HMLotter(彩票)
//
//  Created by Luffy on 15/9/21.
//  Copyright © 2015年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^optionBlcok)();

@interface NJSettingItem : NSObject

@property (nonatomic, copy) NSString *icon; // 图标
@property (nonatomic, copy) NSString *title; // 标题
//@property (nonatomic, assign) Class destVc;

@property (nonatomic, copy) optionBlcok option;


- (instancetype)initWithIcon:(NSString *)icon title:(NSString *)title;

@end
