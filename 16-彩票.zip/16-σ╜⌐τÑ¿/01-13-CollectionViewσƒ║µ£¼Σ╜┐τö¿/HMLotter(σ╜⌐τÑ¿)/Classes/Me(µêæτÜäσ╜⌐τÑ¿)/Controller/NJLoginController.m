//
//  NJLoginController.m
//  HMLotter(彩票)
//
//  Created by Luffy on 15/9/21.
//  Copyright © 2015年 itcast. All rights reserved.
//

#import "NJLoginController.h"
#import "NJSettingController.h"

@interface NJLoginController ()

@property (weak, nonatomic) IBOutlet UIButton *loginBtn;
@end

@implementation NJLoginController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIImage *norImage = [UIImage imageNamed:@"RedButton"];
    CGFloat norImageW = norImage.size.width * 0.5;
    CGFloat norImageH = norImage.size.height * 0.5;
    
    UIImage *newNorImage = [norImage resizableImageWithCapInsets:UIEdgeInsetsMake(norImageH, norImageW, norImageH, norImageW) resizingMode:UIImageResizingModeStretch];
    [self.loginBtn setBackgroundImage:newNorImage forState:UIControlStateNormal];
    
    UIImage *higImage = [UIImage imageNamed:@"RedButtonPressed"];
    CGFloat higImageW = higImage.size.width * 0.5;
    CGFloat higImageH = higImage.size.height * 0.5;
    
    UIImage *newHigImage = [higImage resizableImageWithCapInsets:UIEdgeInsetsMake(higImageH, higImageW, higImageH, higImageW) resizingMode:UIImageResizingModeStretch];
    [self.loginBtn setBackgroundImage:newHigImage forState:UIControlStateHighlighted];
}


- (IBAction)settingBtnOnClick:(UIBarButtonItem *)sender {
    
    NJSettingController *vc = [[NJSettingController alloc] init];
    
    [self.navigationController pushViewController:vc animated:YES];
}

@end
