//
//  NJSettingController.m
//  HMLotter(彩票)
//
//  Created by Luffy on 15/9/21.
//  Copyright © 2015年 itcast. All rights reserved.
//

#import "NJSettingController.h"
#import "NJSettingGroup.h"
#import "NJSettingItem.h"
#import "NJTestViewController.h"
#import "NJSettingCell.h"
#import "NJSettingArrowItem.h"
#import "NJSettingSwitchItem.h"
#import "MBProgressHUD+NJ.h"
#import "NJSettingCollectionViewController.h"

@interface NJSettingController ()

@property (nonatomic, strong) NSMutableArray *datas;

@end

@implementation NJSettingController

#pragma mark - 懒加载
- (NSMutableArray *)datas
{
    if (_datas == nil) {
        
        NJSettingGroup *group0 = [[NJSettingGroup alloc] init];
        
        NJSettingItem *item00 = [[NJSettingArrowItem alloc] initWithIcon:@"MorePush" title:@"推送和提醒" destClass:[NJTestViewController class]];
        NJSettingItem *item01 = [[NJSettingSwitchItem alloc] initWithIcon:@"MorePush" title:@"摇一摇机选"];
        
        group0.items = @[item00, item01];
        
        NJSettingGroup *group1 = [[NJSettingGroup alloc] init];
        
        NJSettingItem *item10 = [[NJSettingArrowItem alloc] initWithIcon:@"MorePush" title:@"检查新版本" destClass:[NJTestViewController class]];
        
        item10.option = ^{
            [MBProgressHUD showMessage:@"正在拼命检查..."];
            
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [MBProgressHUD hideHUD];
                
                [MBProgressHUD showSuccess:@"亲~没有新版本"];
            });
        };
        
        NJSettingItem *item11 = [[NJSettingArrowItem alloc] initWithIcon:@"MorePush" title:@"帮助" destClass:[NJTestViewController class]];
        NJSettingItem *item12 = [[NJSettingArrowItem alloc] initWithIcon:@"MorePush" title:@"产品推荐" destClass:[NJSettingCollectionViewController class]];
        
        group1.headerTitle = @"第2组标题";
        group1.footerTitle = @"第2组底部标题";
        group1.items = @[item10, item11, item12];
        
        _datas = [NSMutableArray array];
        [_datas addObject:group0];
        [_datas addObject:group1];
    }
    return _datas;
}

- (instancetype)init
{
    return [super initWithStyle:UITableViewStyleGrouped];
}

- (instancetype)initWithStyle:(UITableViewStyle)style
{
    return [super initWithStyle:UITableViewStyleGrouped];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
#warning Incomplete implementation, return the number of sections
    return self.datas.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
#warning Incomplete implementation, return the number of rows
    NJSettingGroup *childGroup = self.datas[section];
    return childGroup.items.count;
}

#pragma mark - 数据源方法
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    NJSettingCell *cell = [NJSettingCell cellWithTableView:tableView];
    
    NJSettingGroup *childGroup = self.datas[indexPath.section];
    NJSettingItem *childItem = childGroup.items[indexPath.row];
    
    cell.item = childItem;
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NJSettingGroup *childGroup = self.datas[indexPath.section];
    NJSettingItem *childItem = childGroup.items[indexPath.row];
    
    if (childItem.option != nil) {
        childItem.option();
    }else if ([childItem isKindOfClass:[NJSettingArrowItem class]]) {
        NJSettingArrowItem *arrowItem = (NJSettingArrowItem *)childItem;
        
        NJTestViewController *vc = [[arrowItem.destVc alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
        
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    NJSettingGroup *childGroup = self.datas[section];
    return childGroup.headerTitle;
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section
{
    NJSettingGroup *childGroup = self.datas[section];
    return childGroup.footerTitle;
}

@end
