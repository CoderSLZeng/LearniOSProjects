//
//  NJLoginController.h
//  HMLotter(彩票)
//
//  Created by Luffy on 15/9/21.
//  Copyright © 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NJLoginController : UIViewController

@end
