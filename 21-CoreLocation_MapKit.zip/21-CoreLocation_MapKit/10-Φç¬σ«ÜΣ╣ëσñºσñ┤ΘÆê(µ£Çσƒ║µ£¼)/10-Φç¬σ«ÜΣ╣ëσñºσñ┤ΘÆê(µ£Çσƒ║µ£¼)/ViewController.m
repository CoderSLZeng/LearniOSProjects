//
//  ViewController.m
//  10-自定义大头针(最基本)
//
//  Created by Anthony on 16/3/31.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
// #import <MapKit/MapKit.h>
#import "HMAnnotation.h"


@interface ViewController () <MKMapViewDelegate>
@property (weak, nonatomic) IBOutlet MKMapView *custonMapView;
@property (nonatomic, strong) CLLocationManager *mgr;

@property (nonatomic, strong) CLGeocoder *geocoder;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.mgr requestAlwaysAuthorization];
    
    
    self.custonMapView.rotateEnabled = NO;
    
    self.custonMapView.delegate = self;
    
    self.custonMapView.userTrackingMode = MKUserTrackingModeFollow;
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
//    HMAnnotation *annotation = [[HMAnnotation alloc] init];
//    annotation.title = @"黑马";
//    annotation.subtitle = @"北京中关村";
//    CGFloat latitude = 36.821199 + arc4random_uniform(20);
//    CGFloat longitude = 116.858776 + arc4random_uniform(20);
//    
//    annotation.coordinate = CLLocationCoordinate2DMake(latitude, longitude);
//    
//    [self.custonMapView addAnnotation:annotation];
    
    // 创建大头针模型
    HMAnnotation *anno = [[HMAnnotation alloc] init];
    anno.title = @"传智";
    anno.subtitle = @"育新小区";
    CGFloat latitude = 36.821199 + arc4random_uniform(20);
    CGFloat longitude = 116.858776 + arc4random_uniform(20);
    anno.coordinate = CLLocationCoordinate2DMake(latitude , longitude);
    
    // 添加大头针
    [self.custonMapView addAnnotation:anno];
    
}

#pragma mark - MKMapViewDelegate
- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    [self.geocoder reverseGeocodeLocation:userLocation.location completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        CLPlacemark *placemark = [placemarks firstObject];
        
        userLocation.title = placemark.name;
        userLocation.subtitle = placemark.locality;
        
    }];
    
    CLLocationCoordinate2D center = CLLocationCoordinate2DMake(userLocation.coordinate.latitude, userLocation.coordinate.longitude);
    MKCoordinateSpan span = MKCoordinateSpanMake(5, 5);
    MKCoordinateRegion region = MKCoordinateRegionMake(center, span);
    [self.custonMapView setRegion:region animated:YES];
    
}

#pragma mark - 懒加载
- (CLLocationManager *)mgr
{
    if (!_mgr) _mgr = [[CLLocationManager alloc] init];
    
    return _mgr;
}

- (CLGeocoder *)geocoder
{
    if (!_geocoder) _geocoder = [[CLGeocoder alloc] init];
    
    return _geocoder;
}



@end
