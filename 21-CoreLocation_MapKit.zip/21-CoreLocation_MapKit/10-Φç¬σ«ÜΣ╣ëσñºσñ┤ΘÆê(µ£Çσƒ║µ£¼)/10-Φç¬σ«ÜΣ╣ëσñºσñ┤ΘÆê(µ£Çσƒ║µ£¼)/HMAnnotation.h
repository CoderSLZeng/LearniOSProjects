//
//  HMAnnotation.h
//  10-自定义大头针(最基本)
//
//  Created by Anthony on 16/3/31.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>

@interface HMAnnotation : NSObject<MKAnnotation>

/**
 *  大头针的位置
 */
@property (nonatomic, assign)  CLLocationCoordinate2D coordinate;

/**
*  大头针的标题
*/
@property (nonatomic, copy) NSString *title;

/**
*  大头针的子标题
*/
@property (nonatomic, copy) NSString *subtitle;
@end
