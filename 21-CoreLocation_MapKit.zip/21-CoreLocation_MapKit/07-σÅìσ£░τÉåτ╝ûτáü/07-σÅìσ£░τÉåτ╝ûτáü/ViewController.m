//
//  ViewController.m
//  07-反地理编码
//
//  Created by Anthony on 16/3/31.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>

@interface ViewController ()

/**
 *  地理编码对象
 */
@property (nonatomic, strong) CLGeocoder *geocoder;

#pragma mark - 反地理编码
- (IBAction)reverseGeocode;

@property (weak, nonatomic) IBOutlet UITextField *longtitudeField;
@property (weak, nonatomic) IBOutlet UITextField *latitudeField;
@property (weak, nonatomic) IBOutlet UILabel *reverseDetailAddressLabel;

@end

@implementation ViewController

- (void)reverseGeocode
{
    NSString *longtitude = self.longtitudeField.text;
    NSString *latitude = self.latitudeField.text;
    
    if (longtitude == nil ||
        longtitude.length == 0 ||
        latitude == nil ||
        latitude.length == 0) {
        NSLog(@"请输入经纬度");
        return;
    }
    
   CLLocation *location = [[CLLocation alloc] initWithLatitude:[latitude doubleValue] longitude:[longtitude doubleValue]];
    
    [self.geocoder reverseGeocodeLocation:location completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        for (CLPlacemark *placemark in placemarks) {
            NSLog(@"%@ %@ %f %f", placemark.name, placemark.addressDictionary, placemark.location.coordinate.longitude, placemark.location.coordinate.latitude);
            
            self.reverseDetailAddressLabel.text = placemark.locality;
        }
    }];
}

- (CLGeocoder *)geocoder
{
    if (!_geocoder) _geocoder = [[CLGeocoder alloc] init];
    
    return _geocoder;
}

@end
