//
//  ViewController.m
//  04-指南针
//
//  Created by Anthony on 16/3/30.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>

@interface ViewController () <CLLocationManagerDelegate>

@property (nonatomic, strong) CLLocationManager *mgr;

// 指南针图片
@property (nonatomic, strong) UIImageView *compasspointer;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIImageView *iv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bg_compasspointer"]];
    iv.center = CGPointMake(self.view.center.x, self.view.center.y);
    [self.view addSubview:iv];
    
    self.compasspointer = iv;
    
    self.mgr.delegate = self;
    
    [self.mgr startUpdatingLocation];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - CLLocationManagerDelegate
- (void)locationManager:(CLLocationManager *)manager didUpdateHeading:(CLHeading *)newHeading
{
    
    NSLog(@"%f", newHeading.magneticHeading);
    CGFloat angel = newHeading.magneticHeading * M_PI / 180;
    
    self.compasspointer.transform = CGAffineTransformMakeRotation(angel);
}

#pragma mark - 懒加载
- (CLLocationManager *)mgr
{
    if (!_mgr) _mgr = [[CLLocationManager alloc] init];
    
    return _mgr;
}


@end
