//
//  ViewController.m
//  09-MapKit基本使用
//
//  Created by Anthony on 16/3/31.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import <MapKit/MapKit.h>

@interface ViewController () <CLLocationManagerDelegate,MKMapViewDelegate>
/**
 *  地图
 */
@property (weak, nonatomic) IBOutlet MKMapView *customMapKit;

@property (nonatomic, strong) CLLocationManager *mgr;
/**
 *  地理编码对象
 */
@property (nonatomic, strong) CLGeocoder *geocoder;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.mgr.delegate = self;
    if ([[UIDevice currentDevice].systemVersion doubleValue] > 8.0 ) {
        [self.mgr  requestAlwaysAuthorization];
    }
    
    self.customMapKit.rotateEnabled = NO;
    
    self.customMapKit.delegate = self;
    
    self.customMapKit.userTrackingMode = MKUserTrackingModeFollow;

    
}

#pragma mark - CLLocationManagerDelegate
- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status
{
    if (status == kCLAuthorizationStatusNotDetermined) {
        NSLog(@"等待用户授权");
    } else if (status == kCLAuthorizationStatusAuthorizedAlways ||
               status ==  kCLAuthorizationStatusAuthorizedWhenInUse) {
        
        [self.mgr startUpdatingHeading];
        NSLog(@"授权成功");
    } else {
        NSLog(@"授权失败");
    }
}


#pragma mark - MKMapViewDelegate
- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    [self.geocoder reverseGeocodeLocation:userLocation.location completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        CLPlacemark *placemark = [placemarks firstObject];
        NSLog(@"获取地址位置成功 name = %@, locality = %@", placemark.name, placemark.locality);
        userLocation.title = placemark.name;
        userLocation.subtitle = placemark.locality;
    }];
    
    CLLocationCoordinate2D center = userLocation.location.coordinate;
    MKCoordinateSpan span = MKCoordinateSpanMake(113.676795,22.941328);
    MKCoordinateRegion region = MKCoordinateRegionMake(center, span);
    
    [self.customMapKit setRegion:region animated:YES];
}

- (void)mapView:(MKMapView *)mapView regionWillChangeAnimated:(BOOL)animated
{
    NSLog(@"地图的区域即将改变时调用");
}

- (void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated
{
    NSLog(@"调地图的区域改变完成时调用");
    
    NSLog(@"%f %f", self.customMapKit.region.span.latitudeDelta, self.customMapKit.region.span.longitudeDelta);
}

#pragma mark - 懒加载
- (CLLocationManager *)mgr
{
    if (!_mgr) _mgr = [[CLLocationManager alloc] init];
    
    return _mgr;
}


- (CLGeocoder *)geocoder
{
    if (!_geocoder) _geocoder = [[CLGeocoder alloc] init];
    
    return _geocoder;
}




@end
