//
//  ViewController.m
//  03-汽车导航
//
//  Created by Anthony on 16/3/30.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>
@interface ViewController () <CLLocationManagerDelegate>
@property (nonatomic, strong) CLLocationManager *mgr;

/**
 *  上一次的位置
 */
@property (nonatomic, strong) CLLocation *previousLocation;

/**
 *  总路程
 */
@property (nonatomic, assign) CLLocationDistance sumDistance;

/**
 *  总时间
 */
@property (nonatomic, assign) NSTimeInterval sumTime;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.mgr.delegate = self;
    
    if ([[UIDevice currentDevice].systemVersion doubleValue] > 8.0) {
        [self.mgr requestAlwaysAuthorization];
    } else {
        [self.mgr startUpdatingLocation];
    }
}

#pragma mark - CLLocationManagerDelegate
- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status
{
    if (status == kCLAuthorizationStatusNotDetermined) {
        NSLog(@"等待用户授权");
    } else if (status == kCLAuthorizationStatusAuthorizedAlways ||
               status == kCLAuthorizationStatusNotDetermined) {
        NSLog(@"授权成功");
        [self.mgr startUpdatingLocation];
        
    } else {
        NSLog(@"授权失败");
    }
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations
{
    
    /*
     获取走了多远（这一次的位置 减去上一次的位置）
     获取走这段路花了多少时间 （这一次的时间 减去上一次的时间）
     获取速度 （走了多远 ／ 花了多少时间）
     获取总共走的路程 （把每次获取到走了多远累加起来）
     获取平均速度 （用总路程 ／ 总时间）
     */

    CLLocation *newLocation = [locations lastObject];
    if (self.previousLocation != nil) {
        // 计算两次的距离（单位时米）
        CLLocationDistance distance = [newLocation distanceFromLocation:self.previousLocation];
        
        // 计算两次之间的时间（单位每秒）
        NSTimeInterval dTime = [newLocation.timestamp timeIntervalSinceDate:self.previousLocation.timestamp];
        
        // 计算速度
        CGFloat speed = distance / dTime;
        
        // 累加时间
        self.sumTime += dTime;
        
        // 累加距离
        self.sumDistance += distance;
        
        // 计算平均速度
        CGFloat avgSpeed = self.sumDistance / self.sumTime;
        
        NSLog(@"距离 = %f, 时间 = %f, 速度 = %f, 平均速度 = %f, 总时间 = %f, 总路程 = %f", distance, dTime, speed, avgSpeed, self.sumTime, self.sumDistance);
        
    }
    
    self.previousLocation = newLocation;
    
}


#pragma mark - 懒加载
- (CLLocationManager *)mgr
{
    if (!_mgr) _mgr = [[CLLocationManager alloc] init];
    
    return _mgr;
}

@end
