//
//  ViewController.m
//  05-区域检查
//
//  Created by Anthony on 16/3/30.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>

@interface ViewController ()<CLLocationManagerDelegate>
/**
 *  定位管理者
 */
@property (nonatomic ,strong) CLLocationManager *mgr;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.mgr.delegate = self;
    
    // 注意:如果是iOS8, 想进行区域检测, 必须自己主动请求获取用户隐私的权限
//    if  ([[UIDevice currentDevice].systemVersion doubleValue] >= 8.0 )
//    {
        [self.mgr requestAlwaysAuthorization];
        
//    }
    
    CLLocationCoordinate2D center = CLLocationCoordinate2DMake(40.058501, 116.304171);
    
    CLCircularRegion *circular = [[CLCircularRegion alloc] initWithCenter:center radius:500 identifier:@"软件园"];
    
    [self.mgr startMonitoringForRegion:circular];
    

}

#pragma mark - CLLocationManagerDelegate
- (void)locationManager:(CLLocationManager *)manager didEnterRegion:(CLRegion *)region
{
     NSLog(@"进入监听区域时调用");
}


- (void)locationManager:(CLLocationManager *)manager didExitRegion:(CLRegion *)region
{
     NSLog(@"离开监听区域时调用");
}
#pragma mark - 懒加载
- (CLLocationManager *)mgr
{
    if (!_mgr) {
        _mgr = [[CLLocationManager alloc] init];
    }
    return _mgr;
}

@end
