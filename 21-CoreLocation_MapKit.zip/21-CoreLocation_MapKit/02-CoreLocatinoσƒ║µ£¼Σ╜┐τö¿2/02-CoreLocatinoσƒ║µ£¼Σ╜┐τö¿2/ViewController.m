//
//  ViewController.m
//  02-CoreLocatino基本使用2
//
//  Created by Anthony on 16/3/30.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>

@interface ViewController () <CLLocationManagerDelegate>

@property (nonatomic, strong) CLLocationManager *mgr;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.mgr.delegate = self;
    
    [self.mgr requestAlwaysAuthorization];
    
    
}

#pragma mark - CLLocationManagerDelegate
- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status
{
    if (status == kCLAuthorizationStatusNotDetermined) {
        NSLog(@"等待用户授权");
    } else if (status == kCLAuthorizationStatusAuthorizedAlways ||
               status == kCLAuthorizationStatusAuthorizedWhenInUse) {
        NSLog(@"授权成功");
        [self.mgr startUpdatingLocation];
    } else {
        NSLog(@"授权失败");
    }
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations
{
   CLLocation *location = [locations lastObject];
    NSLog(@"经度 ＝ %f, 纬度 ＝ %f, 速度 = %f", location.coordinate.latitude, location.coordinate.longitude, location.speed);
}

#pragma mark - 懒加载
- (CLLocationManager *)mgr
{
    if (!_mgr) _mgr = [[CLLocationManager alloc] init];
    
    return _mgr;
}


@end
