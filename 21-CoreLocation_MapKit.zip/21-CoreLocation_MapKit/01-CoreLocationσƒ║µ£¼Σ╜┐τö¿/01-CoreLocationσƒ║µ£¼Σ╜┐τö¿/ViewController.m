//
//  ViewController.m
//  01-CoreLocation基本使用
//
//  Created by Anthony on 16/3/30.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>


@interface ViewController () <CLLocationManagerDelegate>
/**
 *  create CLLocationManager
 */
@property (nonatomic, strong) CLLocationManager *mgr;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 成为CoreLocation管理者的代理监听获取到的位置
    self.mgr.delegate = self;
    
//     判断是否是iOS8
    if ([[UIDevice currentDevice].systemVersion doubleValue] > 8.0) {
        [self.mgr requestAlwaysAuthorization];
    }
    
    // 开始获取位置（监听开始）
    [self.mgr startUpdatingLocation];
    
    self.mgr.desiredAccuracy = kCLLocationAccuracyNearestTenMeters;
    
}

#pragma mark - CLLocationManagerDelegate
/**
 *  获取到位置信息之后就会调用（调用频率非常高）
 *
 *  @param manager   触发事件的对象
 *  @param locations 获取到的位置
 */
- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations
{
   NSLog(@"%s", __func__);
    
    // 停止获取位置
    [self.mgr stopUpdatingLocation];
}

/**
 *  授权状态发生改变时调用
 *
 *  @param manager 触发事件的对象
 *  @param status  当前授权的状态
 */
- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status
{
    if (status == kCLAuthorizationStatusNotDetermined) {
        NSLog(@"等待用户授权");
    } else if (status == kCLAuthorizationStatusAuthorizedAlways ||
               status == kCLAuthorizationStatusAuthorizedWhenInUse ) {
        NSLog(@"授权成功");
    } else {
        NSLog(@"授权失败");
    }
}

#pragma mark - 懒加载
- (CLLocationManager *)mgr
{
    if (!_mgr) {
        _mgr =[[CLLocationManager alloc] init];
    }
    
    return _mgr;
}

@end
