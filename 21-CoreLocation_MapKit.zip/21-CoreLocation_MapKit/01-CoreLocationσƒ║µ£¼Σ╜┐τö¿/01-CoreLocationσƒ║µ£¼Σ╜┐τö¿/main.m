//
//  main.m
//  01-CoreLocation基本使用
//
//  Created by Anthony on 16/3/30.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
