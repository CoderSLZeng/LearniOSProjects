//
//  ViewController.m
//  06-地理编码
//
//  Created by Anthony on 16/3/31.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>

@interface ViewController ()
/**
 *  监听地理编码点击事件
 */
- (IBAction)geocodeBtnClick;
/**
 *  需要编码的地址容器
 */
@property (weak, nonatomic) IBOutlet UITextField *addressField;
/**
 *  经度容器
 */
@property (weak, nonatomic) IBOutlet UILabel *longitudeLabel;
/**
 *  纬度容器
 */
@property (weak, nonatomic) IBOutlet UILabel *latitudeLabel;
/**
 *  详情容器
 */
@property (weak, nonatomic) IBOutlet UILabel *detailAddressLabel;
/**
 *  地理编码对象
 */
@property (nonatomic, strong) CLGeocoder *geocoder;



@end

@implementation ViewController

- (void)geocodeBtnClick
{
    
    NSString *addressStr = self.addressField.text;
    if (addressStr == nil || addressStr.length == 0) {
        NSLog(@"请输入地址");
        return;
    }
    
    [self.geocoder geocodeAddressString:addressStr completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        CLPlacemark *placemark = [placemarks firstObject];
        NSLog(@"%@, %@, %f, %f", placemark.name, placemark.addressDictionary, placemark.location.coordinate.latitude, placemark.location.coordinate.longitude);
        self.latitudeLabel.text = [NSString stringWithFormat:@"%f", placemark.location.coordinate.latitude];
        self.longitudeLabel.text = [NSString stringWithFormat:@"%f", placemark.location.coordinate.longitude];
        NSArray *address = placemark.addressDictionary[@"FormattedAddressLines"];
        NSMutableString *strM = [NSMutableString string];
        for (NSString *str in address) {
            [strM appendString:str];
        }
        self.detailAddressLabel.text = strM;
    }];
}

- (CLGeocoder *)geocoder
{
    if (!_geocoder) _geocoder = [[CLGeocoder alloc] init];
    
    return _geocoder;
}


@end
