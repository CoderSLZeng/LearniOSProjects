//
//  _8_CoreLocaiton____Tests.m
//  08-CoreLocaiton三方框架Tests
//
//  Created by Anthony on 16/3/31.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface _8_CoreLocaiton____Tests : XCTestCase

@end

@implementation _8_CoreLocaiton____Tests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
