//
//  ViewController.m
//  08-CoreLocaiton三方框架
//
//  Created by Anthony on 16/3/31.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import "INTULocationManager.h"
#import <CoreLocation/CoreLocation.h>

@interface ViewController ()
@property (nonatomic, strong) CLLocationManager *mgr;
@end

@implementation ViewController

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    INTULocationManager *mgr = [INTULocationManager sharedInstance];
    
    [mgr requestLocationWithDesiredAccuracy:kINTUUpdateTimeStaleThresholdRoom timeout:5 delayUntilAuthorized:YES block:^(CLLocation *currentLocation, INTULocationAccuracy achievedAccuracy, INTULocationStatus status) {
        if (status == INTULocationStatusSuccess) {
            NSLog(@"获取位置成功 %f %f", currentLocation.coordinate.latitude, currentLocation.coordinate.longitude);
        } else if (status == INTULocationStatusError) {
            NSLog(@"获取失败");
        }
    }];
}

@end
