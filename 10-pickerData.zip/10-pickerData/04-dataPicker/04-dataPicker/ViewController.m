//
//  ViewController.m
//  04-dataPicker
//
//  Created by Luffy on 15/8/22.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    

    
    self.view.backgroundColor = [UIColor grayColor];
    // 0.添加输入框
    UITextField *inputTextField = [[UITextField alloc] initWithFrame:CGRectMake(100, 150, 120, 21)];
    inputTextField.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:inputTextField];
    
    // 1.创建时间选择器
    UIDatePicker *datePicker = [[UIDatePicker alloc] init];
    // 1.1设置只显示日期
    datePicker.datePickerMode = UIDatePickerModeDate;
    // 1.2设置日期为中文
    datePicker.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"];
    
    inputTextField.inputView = datePicker;
    
    // 2.创建工具条
    UIToolbar *toolbar = [[UIToolbar alloc] init];
    toolbar.barTintColor = [UIColor purpleColor];
    toolbar.frame = CGRectMake(0, 0, 320, 44);
    
    // 2.1给工具条添加按钮
    UIBarButtonItem *item0 = [[UIBarButtonItem alloc] initWithTitle:@"上一个" style:UIBarButtonItemStylePlain target:self action:@selector(previousBtnClick)];
    
    UIBarButtonItem *item1 = [[UIBarButtonItem alloc] initWithTitle:@"下一个" style:UIBarButtonItemStylePlain target:self action:@selector(previousBtnClick)];
    
    UIBarButtonItem *item3 = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    
    UIBarButtonItem *item2 = [[UIBarButtonItem alloc] initWithTitle:@"完成" style:UIBarButtonItemStylePlain target:self action:@selector(previousBtnClick)];
    
    toolbar.items = @[item0, item1, item3, item2];
    
    // 2.2设置文本输入框键盘的辅助视图
    inputTextField.inputAccessoryView = toolbar;
    
    
}


- (void)previousBtnClick
{
    NSLog(@"上一个");
}



@end
