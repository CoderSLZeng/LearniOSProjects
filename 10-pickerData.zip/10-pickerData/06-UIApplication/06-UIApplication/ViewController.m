//
//  ViewController.m
//  06-UIApplication
//
//  Created by Luffy on 15/8/22.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    /*
    UIApplication *app = [UIApplication sharedApplication];
    UIApplication *app1 = [UIApplication sharedApplication];
//    app.statusBarHidden = YES;
    NSLog(@"%p - %p", app, app1);
     */
    
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
    [btn setTitle:@"点我啊" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(onClick) forControlEvents:UIControlEventTouchUpInside];
    btn.backgroundColor = [UIColor redColor];
    [self.view addSubview:btn];
    self.view.backgroundColor = [UIColor grayColor];
}

- (void)onClick
{
    NSLog(@"%s", __func__);
    
    UIApplication *app = [UIApplication sharedApplication];
//    app.statusBarHidden = YES;
//    [app setStatusBarHidden:YES withAnimation:UIStatusBarAnimationFade];
//    app.applicationIconBadgeNumber = 998;
    app.networkActivityIndicatorVisible = YES;
    
//    app.statusBarStyle = UIStatusBarStyleLightContent;
//    [app setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    
//    NSURL *url = [NSURL URLWithString:@"file:///users/luffy/desktop/main.m"];
    NSURL *url = [NSURL URLWithString:@"http://www.baidu.com"];
    [app openURL:url];
}

@end
