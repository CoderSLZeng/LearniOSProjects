//
//  HMCountryModel.h
//  03-国家选择
//
//  Created by Luffy on 15/8/21.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HMCountryModel : NSObject

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *icon;

- (instancetype)initWithDict:(NSDictionary *)dict;
+ (instancetype)countryWithDict:(NSDictionary *)dict;

+ (NSArray *)countries;
@end
