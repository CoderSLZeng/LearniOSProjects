//
//  ViewController.m
//  03-国家选择
//
//  Created by Luffy on 15/8/21.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "HMCountryModel.h"
#import "HMCountryView.h"

@interface ViewController () <UIPickerViewDataSource, UIPickerViewDelegate>

@property (nonatomic, strong) NSArray *countries;
@property (nonatomic, strong) UIPickerView *pickerView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIPickerView *pickerView = [[UIPickerView alloc] init];
    pickerView.dataSource = self;
    pickerView.delegate = self;
    [self.view addSubview:pickerView];
    self.pickerView = pickerView;
    
    
}
#pragma mark - 懒加载
- (NSArray *)countries
{
    if (_countries == nil) _countries = [HMCountryModel countries];
    return _countries;
}

#pragma mark - UIPickerViewDataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return self.countries.count;
}

#pragma mark - UIPickerViewDelegate
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    HMCountryModel *country = self.countries[row];
    return country.name;
}

#if 1
// 返回第component列的第row行需要显示的视图
// 当一个view进入视野范围内的时候调用
// 当系统调用该方法的时候会自动传入可重用的view
- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view
{
//     UIView *countryView = [[UIView alloc] init];
//     countryView.backgroundColor = [UIColor blueColor];
    
/*
    // 1.创建自定义的view
    HMCountryView *countryView = [HMCountryView countryView];

    // 2.传入模型数据
    countryView.country = self.countries[row];
*/
    
    HMCountryView *countryView = (HMCountryView *)view;
    
    if (countryView == nil) {
        countryView = [HMCountryView countryView];
    }
    
    countryView.country = self.countries[row];
    
    return countryView;

    

}

#endif




- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component
{
//    return 44;
    return [HMCountryView rowHeight];
}


@end
