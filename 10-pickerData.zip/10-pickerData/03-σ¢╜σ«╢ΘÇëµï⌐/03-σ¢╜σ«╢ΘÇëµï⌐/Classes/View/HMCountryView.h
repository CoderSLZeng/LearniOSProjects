//
//  HMCountryView.h
//  03-国家选择
//
//  Created by Luffy on 15/8/21.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HMCountryModel;

@interface HMCountryView : UIView

@property (nonatomic, strong) HMCountryModel *country;

+ (instancetype)countryView;

+ (CGFloat)rowHeight;

@end
