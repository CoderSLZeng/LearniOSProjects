//
//  HMCountryView.m
//  03-国家选择
//
//  Created by Luffy on 15/8/21.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMCountryView.h"
#import "HMCountryModel.h"

@interface HMCountryView ()

@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UIImageView *iconView;


@end

@implementation HMCountryView

+ (instancetype)countryView
{
    return [[[NSBundle mainBundle] loadNibNamed:@"HMCountryView" owner:nil options:nil] firstObject];
}

- (void)setCountry:(HMCountryModel *)country
{
    _country = country;
    
    self.nameLabel.text = _country.name;
    self.iconView.image = [UIImage imageNamed:_country.icon];
    
}

+ (CGFloat)rowHeight
{
    return 44;
}

@end
