//
//  ViewController.m
//  01-点菜
//
//  Created by Luffy on 15/8/20.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <UIPickerViewDataSource, UIPickerViewDelegate>
@property (weak, nonatomic) IBOutlet UIPickerView *pickerView;
@property (weak, nonatomic) IBOutlet UILabel *fruitLabel;
@property (weak, nonatomic) IBOutlet UILabel *stapleLable;
@property (weak, nonatomic) IBOutlet UILabel *drinkLabel;

@property (nonatomic, strong) NSArray *foods;
- (IBAction)randomFoot:(UIButton *)sender;

@end

@implementation ViewController

#pragma mark - 懒加载
- (NSArray *)foods
{
    if (_foods == nil) {
        _foods = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"foods.plist" ofType:nil]];
    }
    return _foods;
}




- (void)viewDidLoad {
    [super viewDidLoad];
    // 设置默认选中个的内容
    /*
    self.fruitLabel.text = self.foods[0][0];
    self.stapleLable.text = self.foods[1][0];
    self.drinkLabel.text = self.foods[2][0];
     */
    
    /*
    [self pickerView:nil didSelectRow:0 inComponent:0];
    [self pickerView:nil didSelectRow:0 inComponent:1];
    [self pickerView:nil didSelectRow:0 inComponent:2];
     */
    
    for (int component = 0; component < self.foods.count; component++) {
        [self pickerView:nil didSelectRow:0 inComponent:component];
    }
    
    
}

#pragma mark - UIPickerViewDataSource
// 返回pickerView一共有多少页
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return self.foods.count;
//    return 3;
}

// 返回pickerView第component列有多少行
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    NSArray *subArray = self.foods[component];
    return subArray.count;
//    return 4;
}

#pragma mark - UIPickerViewDelegate
// 返回第component列的第row行显示什么内容
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    // 1.获取对应列的数组
    NSArray *subFoods = self.foods[component];
    
    // 2.获取对应行的标题
    NSString *name = subFoods[row];
    return name;
    
}

// 当选中了pickerView的某一行的时候调用
// 会降选中的列号和行号作为参数传入
// 只有通过手指选中某一行的时候才会调用
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    // 1.获取对应列对应行的数据
    NSString *name = self.foods[component][row];

    // 2.判读选中的是哪一列，根据列号设置对应的数据
    if (0 == component) {
        self.fruitLabel.text = name;
    } else if (1 == component) {
        self.stapleLable.text = name;
    } else {
        self.drinkLabel.text = name;
    }
    
}

#pragma mark - 监听按钮点击
- (IBAction)randomFoot:(UIButton *)sender {
    
    // 让pickerView主动选中某一行
    // 让pickerView选中inComponent列的Row行
//    [self.pickerView selectRow:1 inComponent:0 animated:YES];
    
    /*
    [self.pickerView selectRow: arc4random() % 12 inComponent:0 animated:YES];
    [self.pickerView selectRow: arc4random() % 15 inComponent:1 animated:YES];
    [self.pickerView selectRow: arc4random() % 10 inComponent:2 animated:YES];
     */
    
    /*
    // 根据每一列的元素个数生成随机值
    [self.pickerView selectRow: arc4random() % [self.foods[0] count] inComponent:0 animated:YES];
    [self.pickerView selectRow: arc4random() % [self.foods[1] count] inComponent:1 animated:YES];
    [self.pickerView selectRow: arc4random() % [self.foods[2] count] inComponent:2 animated:YES];
    */
    
    for (int component = 0; component < self.foods.count; component ++) {
        // 获取对应列的数据总数
        int total = [self.foods[component] count];
        // 根据每一列的总数生成随机数（当前生成的随机数）
        int randomNumber = arc4random() % total;
        
        // 获取当前选中的行（上一次随机后移动到的行
        int oldRow = [self.pickerView selectedRowInComponent:0];
        
        // 比较上一次的行号和当前生成的随机数是否相同，如果相同重新生成
        while (oldRow == randomNumber) {
            randomNumber = arc4random() % total;
        }
        
        // 让pickerView滚动到某一行
        [self.pickerView selectRow:randomNumber inComponent:component animated:YES];
        
        // 通过代码选中某一行
        [self pickerView:nil didSelectRow:randomNumber inComponent:component];
    }
    
}



@end
