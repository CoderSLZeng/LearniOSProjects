//
//  ViewController.m
//  02-城市选择
//
//  Created by Luffy on 15/8/21.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "HMProvince.h"

@interface ViewController () <UIPickerViewDataSource, UIPickerViewDelegate>

@property (nonatomic, strong) NSArray *provinces;

@property (weak, nonatomic) UIPickerView *pickerView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIPickerView *pickerView = [[UIPickerView alloc] init];
    pickerView.dataSource = self;
    pickerView.delegate = self;
    [self.view addSubview:pickerView];
    self.pickerView = pickerView;
}


#pragma mark - 懒加载
- (NSArray *)provinces
{
    if (_provinces == nil) _provinces = [HMProvince provinces];
    return _provinces;
}

#pragma mark - UIPickerViewDataSource
// 返回列数
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 2;
}

// 返回每列有多少行
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (0 == component) {
        // 省的行数
        return self.provinces.count;
        
    } else {
        
        // 城市的行数
        // 1.获取第0列选中的行
        NSInteger selectIndex = [self.pickerView selectedRowInComponent:0];
        
        // 2.根据第0列的行获取对应的省
        HMProvince *province = self.provinces[selectIndex];
        
        // 3.根据省获取对应的城市
        NSArray *cities = province.cities;
        
        // 4.返回城市的数量
        return cities.count;
    }
}

#pragma mark - UIPickerViewDelegate
// 返回每列每行的显示内容
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (0 == component) {
        HMProvince *province = self.provinces[row];
        return province.name;
    } {
        // 城市的行数
        // 1.获取第0列选中的行
        NSInteger selectIndex = [self.pickerView selectedRowInComponent:0];
        
        // 2.根据第0列的行获取对应的省
        HMProvince *province = self.provinces[selectIndex];
        
        // 3.根据省获取对应的城市
        return province.cities[row];
        
    }
    
}

// 监听
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    
    if (0 == component) {
        [pickerView reloadComponent:1];
        [pickerView selectRow:0 inComponent:1 animated:YES];
    }
}

@end
