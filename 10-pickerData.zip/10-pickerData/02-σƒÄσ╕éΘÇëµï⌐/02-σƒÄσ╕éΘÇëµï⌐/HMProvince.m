//
//  HMProvince.m
//  02-城市选择
//
//  Created by Luffy on 15/8/21.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMProvince.h"

@implementation HMProvince

- (instancetype)initWithDict:(NSDictionary *)dict
{
    self = [super init];
    if (self) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+ (instancetype)proinceWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}

+ (NSArray *)provinces
{
    NSArray *array = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"cities.plist" ofType:nil]];
    
    NSMutableArray *arrayM = [NSMutableArray array];
    
    for (NSDictionary *dict in array) {
        [arrayM addObject:[self proinceWithDict:dict]];
    }
    return arrayM;
}


@end
