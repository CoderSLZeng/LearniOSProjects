//
//  HMProvince.h
//  02-城市选择
//
//  Created by Luffy on 15/8/21.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HMProvince : NSObject

@property (nonatomic, strong) NSArray *cities;
@property (nonatomic, copy) NSString *name;

- (instancetype)initWithDict:(NSDictionary *)dict;
+ (instancetype)proinceWithDict:(NSDictionary *)dict;

+ (NSArray *)provinces;


@end
