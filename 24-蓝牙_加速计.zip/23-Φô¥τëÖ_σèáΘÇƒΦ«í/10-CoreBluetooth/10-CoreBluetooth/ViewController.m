//
//  ViewController.m
//  10-CoreBluetooth
//
//  Created by Anthony on 16/4/10.
//  Copyright © 2016年 Anthony. All rights reserved.
//

/**
 Core Bluetooth的开发步骤
 1.建立中心设备
 
 2.建立扫描外设（Discover Peripheral）
 
 3.建立连接外设(Connect Peripheral)
 
 4.建立扫描外设中的服务和特征(Discover Services And Characteristics)
 
 5.建立利用特征与外设做数据交互(Explore And Interact)
 
 6.建立断开连接(Disconnect)
 */

#import "ViewController.h"
#import <CoreBluetooth/CoreBluetooth.h>

@interface ViewController ()<CBCentralManagerDelegate, CBPeripheralDelegate>
/**
 *  外设
 */
@property (nonatomic, strong) NSMutableArray *peripherals;

/**
 *  中心管理者
 */
@property (nonatomic, strong) CBCentralManager *mgr;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 设置代理
    self.mgr.delegate = self;
    
    // 利用中心设备扫描外部设备
    // 如果指定数组代表只扫描指定的设备
    [self.mgr scanForPeripheralsWithServices:nil options:nil];
}

#pragma mark - CBCentralManagerDelegate
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary<NSString *,id> *)advertisementData RSSI:(NSNumber *)RSSI
{
    // 保存扫描到的外部设备
    // 判断如果数组中不包含当前扫描到的外母设备才保存
    if (![self.peripherals containsObject:peripheral]) {
        peripheral.delegate = self;
        [self.peripherals addObject:peripheral];
    }
    
}

#pragma mark - CBPeripheralDelegate
/**
 *  只要扫描到服务就会调用
 *
 *  @param peripheral 服务所在外设
 *  @param error      错误信息
 */
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error
{
    
    // 获取外设中所有扫描到的服务
    NSArray *services = peripheral.services;
    for (CBService *service in services) {
        // 拿到需要的服务
        if ([service.UUID.UUIDString isEqualToString:@"123"]) {
            // 从需要的服务中查找需要的特征
            // 从peripheral中的service中扫描特征
            [peripheral discoverCharacteristics:nil forService:service];
        }
    }
    
}

/**
 *  只要扫描到特征就会调用
 *
 *  @param peripheral 特征所属的外设
 *  @param service    特征所属的服务
 *  @param error      错误信息
 */
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error
{
    // 拿到服务中所有的特征
    NSArray *characteristics = service.characteristics;
    
    // 遍历特征，拿到需要的特征处理
    for (CBCharacteristic * characteristic in characteristics) {
        if ([characteristic.UUID.UUIDString isEqualToString:@"888"]) {
            NSLog(@"设置闹钟");
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 懒加载
- (NSMutableArray *)peripherals
{
    if (!_peripherals) _peripherals = [NSMutableArray array];
    
    return _peripherals;
}

- (CBCentralManager *)mgr
{
    if (!_mgr) _mgr = [[CBCentralManager alloc] init];
    
    return _mgr;
}


- (void)start
{
    for (CBPeripheral *peripheral in self.peripherals) {
        // 连接外设
        [self.mgr connectPeripheral:peripheral options:nil];
    }

}

/**
 *  连接外设成功调用
 *
 *  @param central    中心管理者对象
 *  @param peripheral 连接成功的外设对象
 */
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    [peripheral discoverServices:nil];
}

/**
 *  连接外设失败调用
 *
 *  @param central    中心管理者对象
 *  @param peripheral 连接失败的外设对象
 *  @param error      错误信息
 */
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    
}


@end
