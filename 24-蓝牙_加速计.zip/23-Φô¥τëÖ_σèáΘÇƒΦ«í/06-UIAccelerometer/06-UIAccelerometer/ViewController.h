//
//  ViewController.h
//  06-UIAccelerometer
//
//  Created by Anthony on 16/4/10.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

