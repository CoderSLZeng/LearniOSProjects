//
//  ViewController.m
//  06-UIAccelerometer
//
//  Created by Anthony on 16/4/10.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import "UIView+Extension.h"

@interface ViewController ()<UIAccelerometerDelegate>

/**
 *  小球
 */
@property (weak, nonatomic) IBOutlet UIImageView *imageBall;

/**
 *  保存速度
 */
@property (nonatomic, assign) CGPoint velocity;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    // 1.利用单例获取采集对象
    UIAccelerometer *acc = [UIAccelerometer sharedAccelerometer];
    
    // 2.设置代理
    acc.delegate = self;
    
    // 3.设置采样时间
    acc.updateInterval = 1 / 30;
    
}

#pragma mark - UIAccelerometerDelegate
- (void)accelerometer:(UIAccelerometer *)accelerometer didAccelerate:(UIAcceleration *)acceleration
{
    NSLog(@"x = %f, y = %f, z = %f", acceleration.x, acceleration.y, acceleration.z);
    
    // 不能直接修改对象的结构体属性的成员
//    self.velocity.x += acceleration.x;
    _velocity.x += acceleration.x;
    // -=的原因是因为获取到得Yzhou的加速器和UIKit的坐标系的Y值是相反的，而我们将来想让小球往加速度的反方向运动，所以 -=
    _velocity.y -= acceleration.y;
    
    
    self.imageBall.x += _velocity.x;
    self.imageBall.y += _velocity.y;
    
    // 边界检测
    if (self.imageBall.x <= 0) {
        self.imageBall.x = 0; // 矫正小球当前的位置
        _velocity.x *= -0.5;  // 超出了屏幕的左边
    }
    
    if (self.imageBall.y <= 0) {
        self.imageBall.y = 0;
        _velocity.y *= -0.5;  // 超出屏幕的顶部
    }
    
    if (CGRectGetMaxX(self.imageBall.frame) >= self.view.width) {
        self.imageBall.x = self.view.width - self.imageBall.width;
        _velocity.x *= -0.5; // 超出屏幕右边
    }
    
    if (CGRectGetMaxY(self.imageBall.frame) >= self.view.height) {
        self.imageBall.y = self.view.height - self.imageBall.height;
        _velocity.y *= -0.5;
    }
    
}
@end
