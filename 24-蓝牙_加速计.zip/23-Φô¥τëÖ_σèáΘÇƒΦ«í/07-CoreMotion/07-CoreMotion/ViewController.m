//
//  ViewController.m
//  07-CoreMotion
//
//  Created by Anthony on 16/4/10.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import <CoreMotion/CoreMotion.h>

@interface ViewController ()
/**
 *  coreMotion管理者
 */
@property (nonatomic, strong) CMMotionManager *mgr;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    // 1.创建运动管理者
    self.mgr = [[CMMotionManager alloc] init];
    
    // 2.判断加速器是否可用
    if (self.mgr.isAccessibilityElement) { // 可用
        // 3.开始采样
        [self.mgr startMagnetometerUpdates]; // pull
    } else {
        NSLog(@"加速器不可用");
    }
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    CMAcceleration acc = self.mgr.accelerometerData.acceleration;
    NSLog(@"x = %f, y = %f, z = %f", acc.x, acc.y, acc.z);
}

- (void)push
{
    // 1.创建运动管理者
    self.mgr = [[CMMotionManager alloc] init];
    // 2.判断加速器是否可用
    if (self.mgr.isAccessibilityElement) {
        // 3.设置采样时间
        self.mgr.accelerometerUpdateInterval = 1 / 30.0;
        // 开始采样
        [self.mgr startAccelerometerUpdatesToQueue:[NSOperationQueue mainQueue] withHandler:^(CMAccelerometerData * _Nullable accelerometerData, NSError * _Nullable error) {
            if (error) return;
            
            CMAcceleration acc = accelerometerData.acceleration;
            NSLog(@"x = %f, y = %f, z = %f", acc.x, acc.y, acc.z);
        }];
    }
}

@end
