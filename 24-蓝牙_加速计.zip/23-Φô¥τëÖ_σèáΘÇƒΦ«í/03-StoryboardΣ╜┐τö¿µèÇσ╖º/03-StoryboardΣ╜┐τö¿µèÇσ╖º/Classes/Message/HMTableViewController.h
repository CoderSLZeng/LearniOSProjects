//
//  HMTableViewController.h
//  03-Storyboard使用技巧
//
//  Created by Anthony on 16/4/10.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HMTableViewController : UITableViewController

@end
