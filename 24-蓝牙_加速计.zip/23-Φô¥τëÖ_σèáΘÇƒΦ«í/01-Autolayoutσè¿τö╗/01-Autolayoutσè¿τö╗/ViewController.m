//
//  ViewController.m
//  01-Autolayout动画
//
//  Created by Anthony on 16/4/10.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
/**
 *  距离父控件左边的约束
 */
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *lefCos;

/**
 *  距离父控件顶部的约束
 */
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topCos;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    // 1.修改约束的值
    self.lefCos.constant += 100;
    self.topCos.constant +=100;
    
    // 2.执行动画
    [UIView animateWithDuration:2 animations:^{
        // 让view上的约束执行动画
        [self.view layoutIfNeeded];
    }];
}
@end
