//
//  HMHero.m
//  03-单组表格
//
//  Created by Luffy on 15/8/1.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMHero.h"

@implementation HMHero

- (instancetype)initWithDict:(NSDictionary *)dict
{
    self = [super init];
    if (self) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+ (instancetype)heroWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}

+ (NSArray *)heros
{
    NSArray *array = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"heros.plist" ofType:nil]];
    
    NSMutableArray *arrayM = [NSMutableArray array];
    
    for (NSDictionary *dict in array) {
        [arrayM addObject:[self heroWithDict:dict]];
    }
    return arrayM;
}

- (NSString *)description
{
    return [NSString stringWithFormat:@"<%@, %p>\n{name: %@, icon: %@, intro: %@}", self.class, self, self.name, self.icon, self.intro];
}

@end
