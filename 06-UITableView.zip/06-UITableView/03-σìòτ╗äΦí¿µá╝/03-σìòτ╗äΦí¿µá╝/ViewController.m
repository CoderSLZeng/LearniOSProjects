//
//  ViewController.m
//  03-单组表格
//
//  Created by Luffy on 15/8/1.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "HMHero.h"
@interface ViewController () <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *heros;
@end

@implementation ViewController

- (NSArray *)heros
{
    if (_heros == nil) _heros = [HMHero heros];
    return _heros;
}
- (UITableView *)tableView
{
    if (_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        
        [self.view addSubview:_tableView];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.rowHeight = 120;
        
    }
    return _tableView;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
//    NSLog(@"%@", self.heros);
    [self tableView];
    
    self.tableView.separatorColor = [UIColor colorWithWhite:0.0 alpha:0.2];
    
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
    header.backgroundColor = [UIColor colorWithRed:255.0 / 255.0 green:0 blue:0 alpha:255.0 / 0];
    self.tableView.tableHeaderView = header;
    
    UIView *foot = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
    foot.backgroundColor = [UIColor greenColor];
    self.tableView.tableFooterView = foot;
}


/**
 *  DataSource必须实现的方法
 */
/** 单组表格的总行数 */
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
//    return self.heros.count;
    return 20;
}

/** 单个表格行明细 */
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"表格行明细, %d", indexPath.row);

    static NSString *ID = @"Cell";

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    
    if (cell == nil) {
        NSLog(@"实例化单元格");
    
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
    
        // 右箭头
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        
//        cell.backgroundColor = [UIColor redColor];
        
//        UIImage *bgImage = [UIImage imageNamed:@"img_01"];
//        cell.backgroundView = [[UIImageView alloc] initWithImage:bgImage];
        
//        UIView *bgView = [[UIView alloc] init];
//        bgView.backgroundColor = [UIColor yellowColor];
//        cell.backgroundView = bgView;
//        
//        UIImage *selecetBGImage = [UIImage imageNamed:@"img_02"];
//        cell.selectedBackgroundView = [[UIImageView alloc] initWithImage:selecetBGImage];
        
        
    }
    
    HMHero *hero = self.heros[indexPath.row];
    
    cell.textLabel.text = hero.name;
    cell.imageView.image = [UIImage imageNamed:hero.icon];
    cell.detailTextLabel.text = hero.intro;
    
//    UISwitch *switcher = [[UISwitch alloc] init];
//    
//    [switcher addTarget:self action:@selector(changeSwitcher:) forControlEvents:UIControlEventValueChanged];
//    
//    cell.accessoryView = switcher;
    
    return cell;
}

/** UISwitch按钮的监听方法 */
- (void)changeSwitcher:(UISwitch *)sender
{
      NSLog(@"%s - %@", __func__, sender);
}

#pragma mark - 代理方法

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
      NSLog(@"%s - %@", __func__, indexPath);
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"%s - %@", __func__, indexPath);
}

/**
 *  行高的代理方法
 *
 *  @param CGFloat <#CGFloat description#>
 *
 *  @return <#return value description#>
 */
/** 表格行的视图高度值 */
//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    return (indexPath.row % 2) ? 60 : 44;
//}



@end
