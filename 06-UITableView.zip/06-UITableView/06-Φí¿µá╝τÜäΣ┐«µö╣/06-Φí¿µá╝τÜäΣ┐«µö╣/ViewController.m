//
//  ViewController.m
//  06-表格的修改
//
//  Created by Luffy on 15/8/2.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) NSMutableArray *listDate;
@property (nonatomic, strong) UITableView *tableView;

@end

@implementation ViewController

- (NSMutableArray *)listDate
{
    if (_listDate == nil) {
        _listDate = [NSMutableArray arrayWithObjects:@"zhangsan", @"lisi", @"wangwu", @"maliu", @"zhangsan", @"lisi", @"wangwu", @"maliu",@"zhangsan", @"lisi", @"wangwu", @"maliu",@"zhangsan", @"lisi", @"wangwu", @"maliumaliumaliumaliumaliumaliumaliumaliumaliumaliumaliu", nil];
    }
    return _listDate;
}

- (UITableView *)tableView
{
    if (_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        
        _tableView.dataSource = self;
        _tableView.delegate = self;
        
        [self.view addSubview:_tableView];
    }
    return _tableView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self tableView];
    
    self.tableView.editing = YES;
}

#pragma mark - 数据源
// 每组行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.listDate.count;
}

// 单元格
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *ID; // 可重用的标示符
    
    UITableViewCell *cell = [tableView dequeueReusableHeaderFooterViewWithIdentifier:ID];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
    }
    
    cell.textLabel.text = self.listDate[indexPath.row];
    
    return cell;
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        NSLog(@"要删除");
        
        [self.listDate removeObjectAtIndex:indexPath.row + 1];
        NSLog(@"%@", self.listDate);
        
//        [self.tableView reloadData];
        [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationMiddle];
    }  else if (editingStyle == UITableViewCellEditingStyleInsert)
    {
        [self.listDate insertObject:@"王小二" atIndex:indexPath.row + 1];
        
        NSIndexPath *path = [NSIndexPath indexPathForRow:indexPath.row inSection:indexPath.section];
        [self.tableView insertRowsAtIndexPaths:@[path] withRowAnimation:UITableViewRowAnimationMiddle];
    }
}

//- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    return YES;
//}

- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath
{
    id source = self.listDate[sourceIndexPath.row];
    [self.listDate removeObjectAtIndex:sourceIndexPath.row];
    [self.listDate insertObject:source atIndex:destinationIndexPath.row];
}

#pragma mark - 代理方法
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleInsert;
}












@end
