//
//  HMCars.h
//  05-汽车品牌
//
//  Created by Luffy on 15/8/2.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HMCarGroup.h"

@interface HMCars : NSObject

@property (nonatomic, copy) NSString *icon;
@property (nonatomic, copy) NSString *name;

- (instancetype)initWithDict:(NSDictionary *)dict;
+ (instancetype)carsWithDict:(NSDictionary *)dict;

+ (NSArray *)carsWithArray:(NSArray *)array;

@end
