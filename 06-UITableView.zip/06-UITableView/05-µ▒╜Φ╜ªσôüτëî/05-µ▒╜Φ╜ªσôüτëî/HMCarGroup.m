//
//  HMCarGroup.m
//  05-汽车品牌
//
//  Created by Luffy on 15/8/2.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMCarGroup.h"
#import "HMCars.h"

@implementation HMCarGroup

- (instancetype)initWithDict:(NSDictionary *)dict
{
    self = [super init];
    if (self) {
//        [self setValuesForKeysWithDictionary:dict];
        [self setValue:dict[@"title"] forKey:@"title"];
//        [self setValue:dict[@"cars"] forKey:@"cars"];
        self.cars = [HMCars carsWithArray:dict[@"cars"]];
    }
    return self;
}

+ (instancetype)carGroupWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}

+ (NSArray *)carGroups
{
    NSArray *array = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"cars_total.plist" ofType:nil]];
    NSMutableArray *arrayM = [NSMutableArray array];
    
    for (NSDictionary *dict in array) {
        [arrayM addObject:[self carGroupWithDict:dict]];
    }
    return arrayM;
}

- (NSString *)description
{
    return [NSString stringWithFormat:@"<%@, %p> {title: %@, cars: %@}", self.class, self, self.title, self.cars];
}



@end
