//
//  HMCars.m
//  05-汽车品牌
//
//  Created by Luffy on 15/8/2.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMCars.h"
#import "HMCarGroup.h"

@implementation HMCars

- (instancetype)initWithDict:(NSDictionary *)dict
{
    self = [super init];
    
    if (self) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+ (instancetype)carsWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}

+ (NSArray *)carsWithArray:(NSArray *)array
{
    NSMutableArray *arrayM = [NSMutableArray array];
    
    [array enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        [arrayM addObject:[self carsWithDict:obj]];
    }];
    return arrayM;
}

- (NSString *)description
{
    return [NSString stringWithFormat:@"<%@, %p> {icon: %@, name: %@}", self.class, self, self.icon, self.name];
}

@end
