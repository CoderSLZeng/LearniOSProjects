//
//  HMViewController.m
//  01-应用程序管理
//
//  Created by apple on 14-8-14.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import "HMViewController.h"
#import "HMAppInfo.h"
#import "HMAppView.h"

#define kAppViewW 80
#define kAppViewH 90
#define kColCount 3
#define kStartY   20

@interface HMViewController () <HMAppViewDelegate>
/** 应用程序列表 */
@property (nonatomic, strong) NSArray *appList;
@property (nonatomic, strong) UILabel *tipLabel;
@end

@implementation HMViewController

- (UILabel *)tipLabel
{
    if (_tipLabel == nil) {
        // 添加一个UILabel到界面上
        _tipLabel = [[UILabel alloc] initWithFrame:CGRectMake(80, 400, 160, 40)];
        // 数值是0表示黑色，1表示纯白
        // alpha表示透明度
        _tipLabel.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.2];
        
//        label.text = appView.appInfo.name;
        _tipLabel.textAlignment = NSTextAlignmentCenter;
        
        // self.superview就是视图控制器中的self.view
        [self.view addSubview:_tipLabel];
        // 动画效果
        // 收尾式动画，修改对象的属性，frame,bounds,alpha
        // 初始透明度，完全透明
        _tipLabel.alpha = 0.0;

    }
    return _tipLabel;
}

- (NSArray *)appList
{
    if (_appList == nil) {
        _appList = [HMAppInfo appList];
    }
    return _appList;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // 搭建界面，九宫格
    // 320 - 3 * 80 = 80 / 4 = 20
    CGFloat marginX = (self.view.bounds.size.width - kColCount * kAppViewW) / (kColCount + 1);
    CGFloat marginY = 10;

    for (int i = 0; i < self.appList.count; i++) {
        // 行
        // 0, 1, 2 => 0
        // 3, 4, 5 => 1
        int row = i / kColCount;
        
        // 列
        // 0, 3, 6 => 0
        // 1, 4, 7 => 1
        // 2, 5, 8 => 2
        int col = i % kColCount;
        
        CGFloat x = marginX + col * (marginX + kAppViewW);
        CGFloat y = kStartY + marginY + row * (marginY + kAppViewH);
        
//        // 从XIB来加载自定义视图
//        HMAppView *appView = [[[NSBundle mainBundle] loadNibNamed:@"HMAppView" owner:nil options:nil] lastObject];
//        HMAppView *appView = [HMAppView appView];
        HMAppView *appView = [HMAppView appViewWithAppInfo:self.appList[i]];
        
        appView.delegate = self;
        
        // 设置视图位置
        appView.frame = CGRectMake(x, y, kAppViewW, kAppViewH);
        
        [self.view addSubview:appView];
        
        
        
//        // 实现视图内部细节
//        appView.appInfo = self.appList[i];
    }
}

#pragma mark - 代理的实现方法
- (void)appViewDidClickDownloadButton:(HMAppView *)appView
{
    self.tipLabel.text = appView.appInfo.name;
    
    // 动画结束之后删除
    // ^ 表示是block，块代码，是一个预先准备好的代码块，可以当做参数传递，在需要的时候执行！
    // 块代码在OC中，使用的非常普遍！
    [UIView animateWithDuration:1.0f animations:^{
        NSLog(@"动画开始");
        // 要修改的动画属性
        self.tipLabel.alpha = 1.0;
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:1.0 animations:^{
            self.tipLabel.alpha = 0.0;
        }];
    }];

}

@end
