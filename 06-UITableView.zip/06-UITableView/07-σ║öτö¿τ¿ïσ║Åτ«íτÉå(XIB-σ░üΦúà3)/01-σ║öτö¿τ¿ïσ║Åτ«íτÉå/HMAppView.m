//
//  HMAppView.m
//  01-应用程序管理
//
//  Created by apple on 14-8-14.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import "HMAppView.h"
#import "HMAppInfo.h"

@interface HMAppView()
@property (weak, nonatomic) IBOutlet UIImageView *iconView;
@property (weak, nonatomic) IBOutlet UILabel *label;
@end

@implementation HMAppView
/**
 利用setter方法设置视图的界面显示
 */
- (void)setAppInfo:(HMAppInfo *)appInfo
{
    _appInfo = appInfo;
    
    self.label.text = appInfo.name;
    self.iconView.image = appInfo.image;
}

+ (instancetype)appView
{
    return [[[NSBundle mainBundle] loadNibNamed:@"HMAppView" owner:nil options:nil] lastObject];
}

+ (instancetype)appViewWithAppInfo:(HMAppInfo *)appInfo
{
    // 1. 实例化一个视图
    HMAppView *view = [self appView];
    
    // 2. 设置视图的显示
    view.appInfo = appInfo;
    
    // 3. 返回视图
    return view;
}


/** 按钮监听方法 */
- (IBAction)click:(UIButton *)button
{

    
    
//    // 禁用按钮
    button.enabled = NO;
    
    [self.delegate appViewDidClickDownloadButton:self];
    
//    if ([self.delegate respondsToSelector:@selector(appViewDidClickDownloadButton:)]) {
//        [self.delegate appViewDidClickDownloadButton:self];
//    }
//
//    // 动画结束之后删除
//    // ^ 表示是block，块代码，是一个预先准备好的代码块，可以当做参数传递，在需要的时候执行！
//    // 块代码在OC中，使用的非常普遍！
//    [UIView animateWithDuration:1.0f animations:^{
//        NSLog(@"动画开始");
//        // 要修改的动画属性
//        label.alpha = 1.0;
//    } completion:^(BOOL finished) {
//        [UIView animateWithDuration:1.0 animations:^{
//            label.alpha = 0.0;
//        } completion:^(BOOL finished) {
//            // 动画完成后，所做的操作
//            NSLog(@"动画完成");
//            
//            [label removeFromSuperview];
//        }];
//    }];
}

@end
