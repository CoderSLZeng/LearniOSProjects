//
//  ViewController.m
//  01-表格控件
//
//  Created by Luffy on 15/7/31.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "HMStudent.h"

@interface ViewController () <UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic, strong) NSArray *dataList;

@end

@implementation ViewController

- (NSArray *)dataList
{
    if (_dataList == nil) {
        HMStudent *stu1 = [[HMStudent alloc] init];
        stu1.title = @"黑马1期";
        stu1.desc = @"牛叉";
        
        NSMutableArray *arrayM1 = [NSMutableArray array];
        for (int i = 0; i < 10; i++) {
            [arrayM1 addObject:[NSString stringWithFormat:@"%@ - %d", stu1.title, i]];
        }
        stu1.students = arrayM1;
        
        HMStudent *stu2 = [[HMStudent alloc] init];
        stu2.title = @"黑马2期";
        stu2.desc = @"也牛叉";
        
        NSMutableArray *arrayM2 = [NSMutableArray array];
        for (int i = 0; i < 10; i++) {
            [arrayM2 addObject:[NSString stringWithFormat:@"%@ - %04d", stu2.title, i]];
        }
        stu2.students = arrayM2;
        
        _dataList = @[stu1, stu2];
        
        
    }
    return _dataList;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.dataList.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    HMStudent *stu = self.dataList[section];
    return stu.students.count;
//    
//    if (section == 0) {
//        return 5;
//    } else {
//        return 18;
//    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
   
    HMStudent *stu = self.dataList[indexPath.section];

    cell.textLabel.text = stu.students[indexPath.row];
    
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
//    return [NSString stringWithFormat:@"黑马 %02d 期", section];
    HMStudent *stu = self.dataList[section];
    return stu.title;
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section
{
    return [self.dataList[section] desc];
}

- (void)viewDidLoad {
    [super viewDidLoad];
}



@end
