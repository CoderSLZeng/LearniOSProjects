//
//  ViewController.m
//  01-查看大图
//
//  Created by Luffy on 15/7/29.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

@property (nonatomic, strong) UIImageView *imageView;

@property (nonatomic, strong) UIImage *image;

@end

@implementation ViewController

- (void)setImage:(UIImage *)image
{
    _image = image;

    self.imageView.image = _image;
    
    [self.imageView sizeToFit];
    
    self.scrollView.contentSize = image.size;
    
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.showsVerticalScrollIndicator = NO;
    
    self.scrollView.contentInset = UIEdgeInsetsMake(10, 10, 10, 10);
    // self.scrollView.contentOffset = CGPointMake(0, 100);
    
}

- (UIImageView *)imageView
{
    if (_imageView == nil) {
        _imageView = [[UIImageView alloc] init];
        
        [self.scrollView addSubview:_imageView];
    }
    return _imageView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.image = [UIImage imageNamed:@"minion"];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeContactAdd];
    btn.center = self.view.center;
    [self.view addSubview:btn];
    
    [btn addTarget:self action:@selector(click) forControlEvents:UIControlEventTouchUpInside];
}

- (void)click
{
    CGPoint offSet = self.scrollView.contentOffset;
    offSet.x += 20;
    offSet.y += 20;
    self.scrollView.contentOffset = offSet;
}

@end
