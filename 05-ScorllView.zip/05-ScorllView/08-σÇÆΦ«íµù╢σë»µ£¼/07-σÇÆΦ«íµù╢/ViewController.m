//
//  ViewController.m
//  07-倒计时
//
//  Created by Luffy on 15/7/30.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <UIAlertViewDelegate>
@property (weak, nonatomic) IBOutlet UILabel *counterLabel;
@property (nonatomic, strong) NSTimer *timer;

@end

@implementation ViewController

- (IBAction)play {
    
    self.counterLabel.text = @"2";
//    self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateTimer:) userInfo:@"hell timer" repeats:YES];
    
//    self.timer = [NSTimer timerWithTimeInterval:1.0 target:self selector:@selector(updateTimer:) userInfo:@"hello timer" repeats:YES];
//    
//    [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSDefaultRunLoopMode];
    
    self.timer = [NSTimer timerWithTimeInterval:1.0 target:self selector:@selector(updateTimer:) userInfo:nil repeats:YES];
    
    [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
}

- (void)updateTimer:(NSTimer *)timer
{
    int counter = self.counterLabel.text.intValue;
    
    if (--counter < 0) {
        [self pause];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"开始" message:@"开始啦..." delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", @"哈哈", nil];
        [alert show];
        
    } else {
        self.counterLabel.text = [NSString stringWithFormat:@"%d", counter];
    }
}

- (IBAction)pause {
    
    [self.timer invalidate];
}

- (IBAction)stop {
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSLog(@"%ld  alert-------", (long)buttonIndex);
}
@end
