//
//  ViewController.m
//  03-查看大图-纯代码
//
//  Created by Luffy on 15/7/30.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIImageView *imageView;
@property (nonatomic, strong) UIImage *image;
@end

@implementation ViewController
- (UIScrollView *)scrollView
{
    if (_scrollView == nil) {
        _scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
        
        // 水平
        _scrollView.showsHorizontalScrollIndicator = NO;
        // 垂直
        _scrollView.showsVerticalScrollIndicator = NO;
        
        // 边距
        _scrollView.contentInset = UIEdgeInsetsMake(20, 20, 20, 20);
        
        // 偏移位置
        _scrollView.contentOffset = CGPointMake(50, 50);
        
        [self.view addSubview:_scrollView];
    }
    return _scrollView;
}

- (UIImageView *)imageView
{
    if (_imageView == nil) {
        _imageView = [[UIImageView alloc] init];
        
        [self.scrollView addSubview:_imageView];
    }
    return _imageView;
}

- (void)setImage:(UIImage *)image
{
    _image = image;
    
    self.imageView.image = image;
    
    // 图像的尺寸大小设置
    [self.imageView sizeToFit];
    
    // 设置scrollView的内容大小
    self.scrollView.contentSize = image.size;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.image = [UIImage imageNamed:@"minion"];
}


@end
