//
//  ViewController.m
//  02-用户登录
//
//  Created by Luffy on 15/7/29.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *userNameText;
@property (weak, nonatomic) IBOutlet UITextField *pwdText;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.userNameText becomeFirstResponder];
}

- (IBAction)login {
    NSLog(@"%s %@ %@", __func__, self.userNameText.text, self.pwdText.text);
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSLog(@"%@", textField);
    
    if (textField == self.userNameText) {
        [self.pwdText becomeFirstResponder];
    
    } else if (textField == self.pwdText) {
        [self login];
        [textField resignFirstResponder];
    }
    
    return YES;
}

@end
