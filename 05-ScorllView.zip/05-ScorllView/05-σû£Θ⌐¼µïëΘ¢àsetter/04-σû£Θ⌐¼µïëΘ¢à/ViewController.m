//
//  ViewController.m
//  04-喜马拉雅
//
//  Created by Luffy on 15/7/30.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (strong, nonatomic) IBOutlet UIScrollView *scrollVeiw;
@property (weak, nonatomic) IBOutlet UIButton *lastButton;


@end

@implementation ViewController

- (void)setScrollVeiw:(UIScrollView *)scrollVeiw
{
    _scrollVeiw = scrollVeiw;
    
    CGFloat h = CGRectGetMaxY(self.lastButton.frame) + 10;
    self.scrollVeiw.contentSize = CGSizeMake(0, h);
    
    self.scrollVeiw.contentInset = UIEdgeInsetsMake(64, 0, 49, 0);
    self.scrollVeiw.contentOffset = CGPointMake(0, -64);
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
}


@end
