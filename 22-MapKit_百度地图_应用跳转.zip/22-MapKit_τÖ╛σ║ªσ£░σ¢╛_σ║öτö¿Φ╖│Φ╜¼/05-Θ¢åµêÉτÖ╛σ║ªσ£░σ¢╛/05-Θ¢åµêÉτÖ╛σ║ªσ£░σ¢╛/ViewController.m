//
//  ViewController.m
//  05-集成百度地图
//
//  Created by Anthony on 16/4/5.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import "BMapKit.h"

@interface ViewController () <BMKMapViewDelegate, BMKPoiSearchDelegate>
@property (nonatomic, strong) BMKPoiSearch *searcher;
@property (nonatomic, strong) BMKMapView *mapView;
@property (nonatomic, strong) BMKPoiSearch *poisearch;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    BMKMapView *mapView = [[BMKMapView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    [self.view addSubview:mapView];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeContactAdd];
    [btn addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    btn.center = CGPointMake(200, 200);
    [self.view addSubview:btn];
    
}

- (void)btnClick
{
    
    //发起检索
    BMKCitySearchOption *citySearchOption = [[BMKCitySearchOption alloc]init];
    // 检索的页码
    citySearchOption.pageIndex = 0;
    // 检索的条数
    citySearchOption.pageCapacity = 10;
    citySearchOption.city= @"北京";
    citySearchOption.keyword = @"桑拿";

    BOOL flag = [self.poisearch poiSearchInCity:citySearchOption];
    
    if(flag)
    {
        NSLog(@"周边检索发送成功");
    }
    else
    {
        NSLog(@"周边检索发送失败");
    }

}

#pragma mark - BMKSearchDelegate
//实现PoiSearchDeleage处理回调结果
- (void)onGetPoiResult:(BMKPoiSearch*)searcher result:(BMKPoiResult*)poiResultList errorCode:(BMKSearchErrorCode)error
{
    NSArray *array = [NSArray arrayWithArray:_mapView.annotations];
    [_mapView removeAnnotations:array];
    
    if (error == BMK_SEARCH_NO_ERROR) {
        //在此处理正常结果
        for (int i = 0; i < poiResultList.poiInfoList.count; i++) {
            BMKPoiInfo *poi = [poiResultList.poiInfoList objectAtIndex:i];
            BMKPointAnnotation *item = [[BMKPointAnnotation alloc] init];
            item.coordinate = poi.pt;
            item.title = poi.name;
            [_mapView addAnnotation:item];
            if (i == 0) {
                // 将第一个点的坐标一道屏幕中间
                self.mapView.centerCoordinate = poi.pt;
            }
        }
    } else if (error == BMK_SEARCH_AMBIGUOUS_ROURE_ADDR) {
        NSLog(@"起始点有歧义");
    } else {
        // 各种情况判断
    }

}

- (void)viewWillAppear:(BOOL)animated
{
    [self.mapView viewWillAppear];
    self.mapView.delegate = self;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [self.mapView viewWillDisappear];
    self.mapView.delegate = nil;
}

#pragma mark - 懒加载
- (BMKPoiSearch *)poisearch
{
    if (!_poisearch) _poisearch = [[BMKPoiSearch alloc] init];
    _poisearch.delegate = self;
    
    return _poisearch;
}


@end
