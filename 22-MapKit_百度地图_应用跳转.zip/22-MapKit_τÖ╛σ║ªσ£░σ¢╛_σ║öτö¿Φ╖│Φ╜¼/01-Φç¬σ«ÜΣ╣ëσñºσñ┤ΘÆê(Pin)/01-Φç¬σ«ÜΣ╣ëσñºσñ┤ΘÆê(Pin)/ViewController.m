//
//  ViewController.m
//  01-自定义大头针(Pin)
//
//  Created by Anthony on 16/4/1.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import "HMAnnotation.h"
#import "HMAnnotationView.h"

@interface ViewController ()<CLLocationManagerDelegate, MKMapViewDelegate>

/**
 *  地图
 */
@property (weak, nonatomic) IBOutlet MKMapView *customMapView;

/**
 *  添加大头针
 */
- (IBAction)addAnno;

@property (nonatomic, strong) CLLocationManager *mgr;

@property (nonatomic, strong) CLGeocoder *geocoder;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.mgr.delegate = self;
    
    if ([[UIDevice currentDevice].systemVersion doubleValue] > 8.0) {
        [self.mgr requestAlwaysAuthorization];
    }
    
    self.customMapView.rotateEnabled = NO;
    self.customMapView.delegate = self;
    self.customMapView.userTrackingMode = MKUserTrackingModeFollow;
}


- (IBAction)addAnno {
    HMAnnotation *anno1 = [[HMAnnotation alloc] init];
    anno1.title = @"传智";
    anno1.subtitle = @"育新小区";
    CGFloat latitude = 36.821199 + arc4random_uniform(20);
    CGFloat longitude = 116.858776 + arc4random_uniform(20);
    anno1.coordinate = CLLocationCoordinate2DMake(latitude, longitude);
    anno1.icon = @"category_1";
    
    HMAnnotation *anno2 = [[HMAnnotation alloc] init];
    anno2.title = @"黑马";
    anno2.subtitle = @"牛逼";
    CGFloat latitude2 = 36.821199 + arc4random_uniform(20);
    CGFloat longitude2 = 116.858776 + arc4random_uniform(20);
    anno2.coordinate = CLLocationCoordinate2DMake(latitude, longitude);
    anno2.icon = @"category_2";
    
    [self.customMapView addAnnotation:anno1];
    [self.customMapView addAnnotation:anno2];
}

#pragma mark - CLLocationManagerDelegate
- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status
{
    if (status == kCLAuthorizationStatusNotDetermined) {
        NSLog(@"等待用户授权");
    } else if (status == kCLAuthorizationStatusAuthorizedAlways ||
               status == kCLAuthorizationStatusAuthorizedWhenInUse ) {
        NSLog(@"授权成功");
        [self.mgr startUpdatingLocation];
    } else {
        NSLog(@"授权失败");
    }
}

#pragma mark - MKMapViewDelegate
- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    [self.geocoder reverseGeocodeLocation:userLocation.location completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        CLPlacemark *placemark = [placemarks firstObject];
        
        userLocation.title = placemark.name;
        userLocation.subtitle = placemark.locality;
        
        [self.customMapView setCenterCoordinate:userLocation.coordinate animated:YES];
    }];
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    if ([annotation isKindOfClass:[HMAnnotation class]] == NO) {
        return nil;
    }
    
    // 1.创建大头针
    HMAnnotationView *annoView = [HMAnnotationView annotationViewWithMap:mapView];
    // 2.设置模型
    annoView.annotation = annotation;
    
    // 3.返回大头针
    return annoView;
}

#pragma mark - 懒加载
- (CLLocationManager *)mgr
{
    if (!_mgr) _mgr = [[CLLocationManager alloc] init];
    
    return _mgr;
}

- (CLGeocoder *)geocoder
{
    if (!_geocoder) _geocoder = [[CLGeocoder alloc] init];
    
    return _geocoder;
}


@end
