//
//  HMAnnotationView.m
//  01-自定义大头针(Pin)
//
//  Created by Anthony on 16/4/1.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "HMAnnotationView.h"
#import "HMAnnotation.h"

@implementation HMAnnotationView

- (void)setAnnotation:(HMAnnotation *)annotation
{
    [super setAnnotation:annotation];
    
    self.image = [UIImage imageNamed:annotation.icon];
    
}

- (instancetype)initWithAnnotation:(id<MKAnnotation>)annotation reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithAnnotation:annotation reuseIdentifier:reuseIdentifier]) {
        self.canShowCallout = YES;
        
        self.leftCalloutAccessoryView = [[UISwitch alloc] init];
        
        self.rightCalloutAccessoryView = [UIButton buttonWithType:UIButtonTypeContactAdd];
    }
    
    return self;
}

+ (instancetype)annotationViewWithMap:(MKMapView *)mapView
{
    static NSString *identifier = @"anno";
    
    HMAnnotationView *annoView = (HMAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:identifier];
    
    if (annoView == nil) {
        annoView = [[HMAnnotationView alloc] initWithAnnotation:nil reuseIdentifier:identifier];
    }
    
    return annoView;
}


@end
