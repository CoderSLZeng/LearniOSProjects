//
//  ViewController.m
//  01-新浪
//
//  Created by Anthony on 16/4/5.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import "TableViewController.h"

@interface ViewController ()
- (IBAction)openWangYi;
@end



@implementation ViewController

- (IBAction)openWangYi
{
    // 1.获取application对象
    UIApplication *app = [UIApplication sharedApplication];
    
    // 2.创建需要打开的应用程序的URL
    // 在应用程序跳转中，只要有协议头即可，路径可有可无
    NSURL *url = [NSURL URLWithString:@"wangyi://"];
    
    // 3.利用application打开URL
    if ([app canOpenURL:url]) {
        // 3.1判断是否可以打开
        [app openURL:url];
    } else {
        NSLog(@"根据App id打开App Stroe");
    }
    
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    NSLog(@"首页 %@", sender);
    
    UIViewController *vc = segue.destinationViewController;
    if ([vc isKindOfClass:[TableViewController class]]) {
        TableViewController *tbVc = vc;
        tbVc.callScheme = sender;
    }
}

@end
