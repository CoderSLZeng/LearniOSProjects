//
//  TableViewController.h
//  01-新浪
//
//  Created by Anthony on 16/4/5.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewController : UITableViewController

/**
 *  当前打开我们应用的Scheme
 */
@property (nonatomic, copy) NSString *callScheme;
@end
