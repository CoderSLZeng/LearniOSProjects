//
//  TableViewController.m
//  01-新浪
//
//  Created by Anthony on 16/4/5.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "TableViewController.h"

@interface TableViewController ()

@end

@implementation TableViewController



#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
#warning Incomplete implementation, return the number of rows
    return 5;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
    cell.textLabel.text = [NSString stringWithFormat:@"User-%zd", indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"授权界面 %@", self.callScheme);
    
    UIApplication *app = [UIApplication sharedApplication];
    
    NSString *str = [NSString stringWithFormat:@"%@://login?user=%zd", self.callScheme, indexPath.row];
    NSURL *url = [NSURL URLWithString:str];
    
    if ([app canOpenURL:url]) {
        [app openURL:url];
        
        [self.navigationController popToRootViewControllerAnimated:YES];
    } else
    {
        NSLog(@"根据App id打开App Store");
    }
    
}



@end
