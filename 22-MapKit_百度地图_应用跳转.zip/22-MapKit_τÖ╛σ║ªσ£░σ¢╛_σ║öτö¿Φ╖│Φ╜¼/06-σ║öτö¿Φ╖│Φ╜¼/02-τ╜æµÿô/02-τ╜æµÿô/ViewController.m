//
//  ViewController.m
//  02-网易
//
//  Created by Anthony on 16/4/5.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
- (IBAction)openSina;
- (IBAction)openDetail;

@end

@implementation ViewController

- (IBAction)openSina
{
    UIApplication *app = [UIApplication sharedApplication];
    
    NSURL *url = [NSURL URLWithString:@"sina://login?myScheme=wangyi"];
    
    if ([app canOpenURL:url]) {
        [app openURL:url];
    } else {
        NSLog(@"根据App id打开App STORE");

    }
}

- (IBAction)openDetail
{
    UIApplication *app = [UIApplication sharedApplication];
    
    NSURL *url = [NSURL URLWithString:@"sina://view?id=123456"];
    
    if ([app canOpenURL:url]) {
        [app openURL:url];
    } else {
        
        NSLog(@"根据App id打开App STORE");
    }
}

@end
