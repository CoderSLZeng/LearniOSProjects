//
//  ViewController.m
//  03-获取路线信息
//
//  Created by Anthony on 16/4/6.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import <MapKit/MapKit.h>

@interface ViewController ()
- (IBAction)startNavigation;
/**
 *  开始位置
 */
@property (weak, nonatomic) IBOutlet UITextField *startField;
/**
 *  结束位置
 */
@property (weak, nonatomic) IBOutlet UITextField *endField;

//@property (nonatomic, strong) CLLocationManager *mgr;
/**
 *  地理编码对象
 */
@property(nonatomic, strong) CLGeocoder *geocoder;
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
//    [self.mgr requestAlwaysAuthorization];
}

- (IBAction)startNavigation {
    
    NSString *startStr = self.startField.text;
    NSString *endStr = self.endField.text;
    if (startStr == nil || startStr.length == 0) {
        NSLog(@"请输入起点");
    }
    
    if (endStr == nil || endStr.length == 0) {
        NSLog(@"请输入终点");
    }
    
    [self.geocoder geocodeAddressString:startStr completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        if (placemarks.count == 0) return;
        
        CLPlacemark *startCLPlacemark = [placemarks firstObject];
        
        [self.geocoder geocodeAddressString:endStr completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
            if (placemarks.count == 0) return;
            CLPlacemark *endCLPlacemark = [placemarks firstObject];
            
            [self startDirectionsWithStartCLPlacemakr:startCLPlacemark endCLPlacemark:endCLPlacemark];
        }];
    }];
}


- (void)startDirectionsWithStartCLPlacemakr:(CLPlacemark *)startCLPlacemark endCLPlacemark:(CLPlacemark *)endCLPlacemark
{
    MKPlacemark *startMKPlacemark = [[MKPlacemark alloc] initWithPlacemark:startCLPlacemark];
    MKMapItem *startItem = [[MKMapItem alloc] initWithPlacemark:startMKPlacemark];
    
    MKPlacemark *endMKPlacemark = [[MKPlacemark alloc] initWithPlacemark:endCLPlacemark];
    MKMapItem *endItem = [[MKMapItem alloc] initWithPlacemark:endMKPlacemark];
    MKDirectionsRequest *request = [[MKDirectionsRequest alloc] init];
    request.source = startItem;
    request.destination = endItem;
    
    MKDirections *directions = [[MKDirections alloc] initWithRequest:request];
    
    [directions calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse * _Nullable response, NSError * _Nullable error) {
        NSArray *routes = response.routes;
        for (MKRoute *route in routes) {
            NSLog(@"%fKM %FHour", route.distance / 1000, route.expectedTravelTime / 3600);
            
            NSArray *steps = route.steps;
            for (MKRouteStep *step  in steps) {
                NSLog(@"%@ 距离%f", step.instructions, step.distance);
            }
        }
        
    }];
}

#pragma mark - 懒加载
/*
- (CLLocationManager *)mgr
{
    if (!_mgr) _mgr = [[CLLocationManager alloc] init];
    
    return _mgr;
}
*/

- (CLGeocoder *)geocoder
{
    if (!_geocoder) _geocoder = [[CLGeocoder alloc] init];
    
    return _geocoder;
}

@end
