//
//  AppDelegate.h
//  01-自定义大头针(Pin)
//
//  Created by Anthony on 16/4/6.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

