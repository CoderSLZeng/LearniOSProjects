//
//  ViewController.m
//  01-自定义大头针(Pin)
//
//  Created by Anthony on 16/4/6.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import "HMAnnotationView.h"
#import "HMAnnotation.h"

@interface ViewController () <CLLocationManagerDelegate, MKMapViewDelegate>
/**
 *  地图控制器
 */
@property (weak, nonatomic) IBOutlet MKMapView *customMapView;

/**
 *  添加大头针
 */
- (IBAction)addAnno;

/**
 *  定位管理者
 */
@property (nonatomic, strong) CLLocationManager *mgr;

/**
 *  地理编码对象
 */
@property (nonatomic, strong) CLGeocoder *geocoder;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    /**
     *  判断系统版本
     */
    if ([[UIDevice currentDevice].systemVersion doubleValue] >= 8.0) {
        [self.mgr requestAlwaysAuthorization];
        self.mgr.delegate = self;
    }
    
    // 设置不允许地图旋转
    self.customMapView.rotateEnabled = NO;
    
    self.customMapView.delegate = self;
    
    self.customMapView.userTrackingMode = MKUserTrackingModeFollow;
}

- (IBAction)addAnno {
    
    HMAnnotation *anno = [[HMAnnotation alloc] init];
    anno.title = @"传智";
    anno.subtitle = @"育新小区";
    CGFloat latitude = 36.821199 + arc4random_uniform(20);
    CGFloat longitude = 116.858776 + arc4random_uniform(20);
    anno.coordinate = CLLocationCoordinate2DMake(latitude, longitude);
    [self.customMapView addAnnotation:anno];
    
    HMAnnotation *anno2 = [[HMAnnotation alloc] init];
    anno2.title = @"传智2";
    anno2.subtitle = @"育新小区2";
    CGFloat latitude2 = 36.821199 + arc4random_uniform(20);
    CGFloat longitude2 = 116.858776 + arc4random_uniform(20);
    anno.coordinate = CLLocationCoordinate2DMake(latitude2, longitude2);
    [self.customMapView addAnnotation:anno2];
    
}

#pragma mark - CLLocationManagerDelegate
- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status
{
    if (status == kCLAuthorizationStatusNotDetermined) {
        NSLog(@"等待用户授权");
    } else if (status == kCLAuthorizationStatusAuthorizedAlways ||
               status == kCLAuthorizationStatusAuthorizedWhenInUse) {
        NSLog(@"授权成功");
    } else {
        NSLog(@"授权失败");
    }
    
}

#pragma mark - MKMapViewDelegate
- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    if ([annotation isKindOfClass:[HMAnnotation class]] == NO) {
        return nil;
    }

    // 1.创建大头针
    HMAnnotationView *annoView = [HMAnnotationView annotationViewWithMap:mapView];
    
    // 2.设置模型
    annoView.annotation = annotation;
    
    // 3.发挥大头针
    return annoView;
}

- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    // 利用反地理编码获取位置之后设置标题
    [self.geocoder reverseGeocodeLocation:userLocation.location completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        CLPlacemark *placemark = [placemarks firstObject];
        
        NSLog(@"获取地理位置成功 name = %@, locality %@", placemark.name, placemark.locality);
        userLocation.title = placemark.name;
        userLocation.subtitle = placemark.locality;
    }];
}

#pragma mark - 懒加载
- (CLLocationManager *)mgr
{
    if (!_mgr) _mgr = [[CLLocationManager alloc] init];
    
    return _mgr;
}

- (CLGeocoder *)geocoder
{
    if (!_geocoder) _geocoder = [[CLGeocoder alloc] init];
    
    return _geocoder;
}


@end
