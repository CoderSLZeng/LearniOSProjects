//
//  ViewController.m
//  08-友盟社会化分享
//
//  Created by Anthony on 16/4/6.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import "UMSocial.h"

@interface ViewController ()
- (IBAction)shareBtn;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (IBAction)shareBtn {
    
    [UMSocialSnsService presentSnsIconSheetView:self
                                         appKey:@"5704a916e0f55adc73000f71"
                                      shareText:@"今天天气非常好，只是没有出门"
                                     shareImage:nil
                                shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,nil]
                                       delegate:nil];
}
@end
