//
//  ViewController.m
//  04-绘制路线
//
//  Created by Anthony on 16/4/5.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import "HMAnnotation.h"

@interface ViewController ()<MKMapViewDelegate>

@property (weak, nonatomic) IBOutlet MKMapView *mapVIew;

/**
 *  地理编码对象
 */
@property(nonatomic, strong) CLGeocoder *geocoder;

- (IBAction)drawLine;
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.mapVIew.delegate = self;
}

- (IBAction)drawLine
{
    NSString *startStr = @"北京";
    NSString *endStr = @"云南";
    if (startStr == nil || startStr.length == 0 ||
        endStr == nil || endStr.length == 0) {
        NSLog(@"请输入起点和终点的位置");
        return;
    }
    
    [self.geocoder geocodeAddressString:startStr completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        if (placemarks.count == 0) {
            return;
        }
        
        CLPlacemark *startCLPlacemark = [placemarks firstObject];
        
        HMAnnotation *startAnno = [[HMAnnotation alloc] init];
        startAnno.title = startCLPlacemark.locality;
        startAnno.subTitle = startCLPlacemark.name;
        startAnno.coordinate = startCLPlacemark.location.coordinate;
        [self.mapVIew addAnnotation:startAnno];
        
        [self.geocoder geocodeAddressString:endStr completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
            if (placemarks.count == 0) {
                return;
            }
            
            CLPlacemark *endCLPacemark = [placemarks firstObject];
            HMAnnotation *endAnno = [[HMAnnotation alloc] init];
            endAnno.title = endCLPacemark.locality;
            endAnno.subTitle = endCLPacemark.name;
            endAnno.coordinate = endCLPacemark.location.coordinate;
            [self.mapVIew addAnnotation:endAnno];
            
            [self startDirectionsWithStartCLPlacemark:startCLPlacemark endCLPlacemark:endCLPacemark];
            
        }];
    }];
}

- (void)startDirectionsWithStartCLPlacemark:(CLPlacemark *)startCLPlacemark endCLPlacemark:(CLPlacemark *)endCLPlacemark
{
    MKPlacemark *startMKPlacemark = [[MKPlacemark alloc] initWithPlacemark:startCLPlacemark];
    MKMapItem *startItem = [[MKMapItem alloc] initWithPlacemark:startMKPlacemark];
    
    MKPlacemark *endMKPlacemark = [[MKPlacemark alloc] initWithPlacemark:endCLPlacemark];
    MKMapItem *endItem = [[MKMapItem alloc] initWithPlacemark:endMKPlacemark];
    
    MKDirectionsRequest *request = [[MKDirectionsRequest alloc] init];
    request.source = startItem;
    request.destination = endItem;
    
    
    MKDirections *directions = [[MKDirections alloc] initWithRequest:request];
    
    [directions calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse * _Nullable response, NSError * _Nullable error) {
        NSArray *routes = response.routes;
        for (MKRoute *route in routes) {
            NSLog(@"%fKM, %fHour", route.distance / 1000, route.expectedTravelTime / 3600);
            
            [self.mapVIew addOverlay:route.polyline];
            
            NSArray *steps = route.steps;
            
            for (MKRouteStep *step in steps) {
                NSLog(@"%@, %f", step.instructions, step.distance);
            }
        }
    }];
}

#pragma mark - MKMapViewDelegate
- (MKOverlayRenderer *)mapView:(MKMapView *)mapView rendererForOverlay:(id<MKOverlay>)overlay
{
    NSLog(@"%s", __func__);

    MKPolylineRenderer *line = [[MKPolylineRenderer alloc] initWithPolyline:overlay];
    line.lineWidth = 5;
    line.strokeColor = [UIColor redColor];
    return line;
}

#pragma mark - 懒加载
- (CLGeocoder *)geocoder
{
    if (!_geocoder) _geocoder = [[CLGeocoder alloc] init];
    
    return _geocoder;
}


@end
