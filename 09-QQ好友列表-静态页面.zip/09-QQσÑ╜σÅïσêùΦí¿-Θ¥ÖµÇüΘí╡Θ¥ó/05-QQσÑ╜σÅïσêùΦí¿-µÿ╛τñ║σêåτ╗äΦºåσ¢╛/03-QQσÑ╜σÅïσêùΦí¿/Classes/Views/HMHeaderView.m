//
//  HMHeaderView.m
//  03-QQ好友列表
//
//  Created by Luffy on 15/8/17.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMHeaderView.h"
#import "HMQQGroupModel.h"

@interface HMHeaderView ()

@property (weak, nonatomic) UIButton *btn;
@property (weak, nonatomic) UILabel *label;

@end

@implementation HMHeaderView

+ (instancetype)headerViewWithTableView:(UITableView *)tableView
{
    static NSString *identifier = @"hearderView";
    
    HMHeaderView *headerView = [tableView dequeueReusableHeaderFooterViewWithIdentifier:identifier];
    
    if (headerView == nil) {
        headerView = [[self alloc] initWithReuseIdentifier:identifier];
    }
    
    return headerView;
}

- (id)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithReuseIdentifier:reuseIdentifier];
    
    if (self) {
        
        // 1.添加子控件
        // 1.1添加按钮
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
//        btn.backgroundColor = [UIColor redColor];
        
        // 监听按钮的点击事件
        [btn addTarget:self action:@selector(btnOnClick:) forControlEvents:UIControlEventTouchUpInside];
        
        // 设置按钮的背景tup
        [btn setBackgroundImage:[UIImage imageNamed:@"buddy_header_bg"] forState:UIControlStateNormal];
        [btn setBackgroundImage:[UIImage imageNamed:@"buddy_header_bg_highlighted"] forState:UIControlStateHighlighted];
        
        // 设置按钮上的尖尖图片
        [btn setImage:[UIImage imageNamed:@"buddy_header_arrow"] forState:UIControlStateNormal];
        
        // 1.设置按钮的内容左对齐
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        
        // 2.设置按钮的内边距，让按钮的内容距离左边有一定距离
        btn.contentEdgeInsets = UIEdgeInsetsMake(0, 20, 0, 0);
        
        // 3.设置按钮的标题和图片之间的距离
        btn.titleEdgeInsets = UIEdgeInsetsMake(0, 20, 0, 0);
        
        
        // 设置按钮标题颜色
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self addSubview:btn];
        self.btn = btn;
        
        // 1.2.添加label
        UILabel *label = [[UILabel alloc] init];
//        label.backgroundColor = [UIColor greenColor];
        
        // 设置文本右对齐
        label.textAlignment = NSTextAlignmentRight;
        label.textColor = [UIColor grayColor];
        
        [self addSubview:label];
        self.label = label;
        
        
    }
    return self;
}

// 该方法在空间的frame被改变的时候就会调用
// 该方法一般用于调整子控件的位置
- (void)layoutSubviews
{

#warning 切记重写layoutSubviews方法一定要调用父类的layoutSubviews
    [super layoutSubviews];
    
    // 1.设置btn的frame
    self.btn.frame = self.bounds;
    
    // 2.设置label的frame
    CGFloat padding = 20;
    CGFloat labelY = 0;
    CGFloat labelH = self.bounds.size.height;
    CGFloat labelW = 150;
    CGFloat labelX = self.bounds.size.width - padding - labelW;
    self.label.frame = CGRectMake(labelX, labelY, labelW, labelH);
    
    
}

- (void)btnOnClick:(UIButton *)btn
{
    NSLog(@"按钮被点击了");
}


- (void)setQqGroup:(HMQQGroupModel *)qqGroup
{
    _qqGroup = qqGroup;
    
    // 1.设置按钮上的文字
    [self.btn setTitle:_qqGroup.name forState:UIControlStateNormal];
    
    // 2.设置在线人数
    self.label.text = [NSString stringWithFormat:@"%@/%d", _qqGroup.online, _qqGroup.friends.count];
}












@end
