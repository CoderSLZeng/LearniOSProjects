//
//  HMNewsCell.h
//  10-作业-新闻
//
//  Created by Luffy on 15/8/19.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HMNewsModel;

@interface HMNewsCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *authorLabel;
@property (weak, nonatomic) IBOutlet UILabel *commentsLabel;
@property (weak, nonatomic) IBOutlet UIImageView *iconView;

@property (nonatomic, strong) HMNewsModel *news;

+ (instancetype)newsCell;

+ (NSString *)identifier;

@end
