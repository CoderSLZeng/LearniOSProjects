//
//  HMNewsCell.m
//  10-作业-新闻
//
//  Created by Luffy on 15/8/19.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMNewsCell.h"
#import "HMNewsModel.h"

@implementation HMNewsCell

+ (instancetype)newsCell
{
    return [[NSBundle mainBundle] loadNibNamed:@"HMNewsCell" owner:nil options:nil][0];
}


+ (NSString *)identifier
{
    return @"myNews";
}

- (void)setNews:(HMNewsModel *)news
{
    _news = news;
    
    self.titleLabel.text = _news.title;
    self.authorLabel.text = _news.author;
    self.commentsLabel.text = [NSString stringWithFormat:@"评论：%@", _news.comments];
    self.iconView.image = [UIImage imageNamed:_news.icon];
    
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
