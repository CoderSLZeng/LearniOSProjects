//
//  ViewController.m
//  10-作业-新闻
//
//  Created by Luffy on 15/8/19.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "HMNewsModel.h"
#import "HMNewsCell.h"

@interface ViewController ()

@property (nonatomic, strong) NSArray *news;


@end

@implementation ViewController

#pragma mark - 懒加载
- (NSArray *)news
{
    if (_news == nil) _news = [HMNewsModel news];
    return _news;
}

- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 设置cell的高度
    self.tableView.rowHeight = 80;

}

#pragma mark - 数据源方法
// 单组的总数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.news.count;
}

// 单元格
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    HMNewsCell *cell = [tableView dequeueReusableCellWithIdentifier:[HMNewsCell identifier]];
    
    if (cell == nil) {
        cell = [HMNewsCell newsCell];
    }
    
    cell.news = self.news[indexPath.row];
    
    return cell;
    
}

//#pragma mark - 代理方法
//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    return 80;
//}


@end
