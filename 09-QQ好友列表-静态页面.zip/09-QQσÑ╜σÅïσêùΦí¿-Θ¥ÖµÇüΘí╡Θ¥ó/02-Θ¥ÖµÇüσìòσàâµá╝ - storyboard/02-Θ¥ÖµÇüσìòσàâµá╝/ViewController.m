//
//  ViewController.m
//  02-静态单元格
//
//  Created by Luffy on 15/8/16.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (BOOL)prefersStatusBarHidden
{
    return YES;
}


@end
