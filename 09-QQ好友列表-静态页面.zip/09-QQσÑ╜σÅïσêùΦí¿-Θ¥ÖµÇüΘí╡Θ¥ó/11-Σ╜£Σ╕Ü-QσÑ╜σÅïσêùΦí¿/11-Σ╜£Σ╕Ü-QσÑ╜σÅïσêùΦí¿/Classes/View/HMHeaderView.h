//
//  HMHeaderView.h
//  11-作业-Q好友列表
//
//  Created by Luffy on 15/8/19.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HMQQGroupModel, HMHeaderView;

@protocol HMHeaderViewDelegate <NSObject>

@required
- (void)headerViewDidClickButton:(HMHeaderView *)headerView;

@end

@interface HMHeaderView : UITableViewHeaderFooterView

+ (instancetype)headerViewWithTableView:(UITableView *)tableView;

@property (nonatomic, strong) HMQQGroupModel *qqGroup;

@property (weak, nonatomic) id<HMHeaderViewDelegate> delegate;

@end
