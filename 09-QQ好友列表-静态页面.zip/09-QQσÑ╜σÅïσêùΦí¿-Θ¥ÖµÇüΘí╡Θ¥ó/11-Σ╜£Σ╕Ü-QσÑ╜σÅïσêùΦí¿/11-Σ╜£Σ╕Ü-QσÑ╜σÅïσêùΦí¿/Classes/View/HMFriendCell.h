//
//  HMFriendCell.h
//  11-作业-Q好友列表
//
//  Created by Luffy on 15/8/19.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HMFriendModel;

@interface HMFriendCell : UITableViewCell

+ (instancetype)friendCellWithTableView:(UITableView *)tableView;

@property (nonatomic, strong) HMFriendModel *friendData;

@end
