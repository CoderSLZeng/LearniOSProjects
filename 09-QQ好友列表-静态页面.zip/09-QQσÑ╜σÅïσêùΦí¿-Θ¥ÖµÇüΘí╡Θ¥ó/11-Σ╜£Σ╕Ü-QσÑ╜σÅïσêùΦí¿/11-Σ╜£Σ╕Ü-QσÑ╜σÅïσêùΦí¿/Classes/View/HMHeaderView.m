//
//  HMHeaderView.m
//  11-作业-Q好友列表
//
//  Created by Luffy on 15/8/19.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMHeaderView.h"
#import "HMQQGroupModel.h"

@interface HMHeaderView ()

@property (weak, nonatomic) UIButton *btn;
@property (weak, nonatomic) UILabel *Label;

@end

@implementation HMHeaderView

+ (instancetype)headerViewWithTableView:(UITableView *)tableView
{
    static NSString *identifier = @"headerView";
    
    HMHeaderView *headerView = [tableView dequeueReusableHeaderFooterViewWithIdentifier:identifier];
    
    if (headerView == nil) {
        headerView = [[self alloc] initWithReuseIdentifier:identifier];
    }
    
    return headerView;
}

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
   self = [super initWithReuseIdentifier:reuseIdentifier];
    
    if (self) {
        UIButton *btn = [[UIButton alloc] init];
        [btn addTarget:self action:@selector(btnOnClick:) forControlEvents:UIControlEventTouchUpInside];
        
        [btn setBackgroundImage:[UIImage imageNamed:@"buddy_header_bg"] forState:UIControlStateNormal];
        [btn setBackgroundImage:[UIImage imageNamed:@"buddy_header_bg_highlighted"] forState:UIControlStateHighlighted];
        
        [btn setImage:[UIImage imageNamed:@"buddy_header_arrow"] forState:UIControlStateNormal];
        
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        
        btn.contentEdgeInsets = UIEdgeInsetsMake(0, 20, 0, 0);
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
        btn.titleEdgeInsets = UIEdgeInsetsMake(0, 20, 0, 0);
        
        btn.imageView.contentMode = UIViewContentModeCenter;
        btn.imageView.layer.masksToBounds = NO;
        
        [self addSubview:btn];
        self.btn = btn;
        
        UILabel *label = [[UILabel alloc] init];
        label.textAlignment = NSTextAlignmentRight;
        label.textColor = [UIColor grayColor];
        [self addSubview:label];
        self.Label = label;
        
    }
    
    return self;
}

- (void)btnOnClick:(UIButton *)btn
{
    NSLog(@"被点击了");
    
    self.qqGroup.open = !self.qqGroup.isOpen;
    
    if ([self.delegate respondsToSelector:@selector(headerViewDidClickButton:)])
    {
        [self.delegate headerViewDidClickButton:self];
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.btn.frame = self.bounds;
    
    CGFloat padding = 20;
    
    CGFloat labelY = 0;
    CGFloat labelW = 100;
    CGFloat labelH = self.bounds.size.height;
    CGFloat labelX = self.bounds.size.width - padding - labelW;
    
    self.Label.frame = CGRectMake(labelX, labelY, labelW, labelH);
    
    
    
}

- (void)setQqGroup:(HMQQGroupModel *)qqGroup
{
    _qqGroup = qqGroup;
    
    [self.btn setTitle:_qqGroup.name forState:UIControlStateNormal];
    
    self.Label.text = [NSString stringWithFormat:@"%@/%d", _qqGroup.online, _qqGroup.friends.count];

}

- (void)didMoveToSuperview
{
    if (self.qqGroup.isOpen) {
        self.btn.imageView.transform = CGAffineTransformMakeRotation(M_PI_2);
    }
}

@end
