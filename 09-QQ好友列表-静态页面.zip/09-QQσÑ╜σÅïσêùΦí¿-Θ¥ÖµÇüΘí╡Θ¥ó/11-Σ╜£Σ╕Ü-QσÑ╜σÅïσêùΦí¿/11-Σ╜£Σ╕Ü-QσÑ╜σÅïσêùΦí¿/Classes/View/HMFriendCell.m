
//
//  HMFriendCell.m
//  11-作业-Q好友列表
//
//  Created by Luffy on 15/8/19.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMFriendCell.h"
#import "HMFriendModel.h"

@implementation HMFriendCell

+ (instancetype)friendCellWithTableView:(UITableView *)tableView
{
    static NSString *identifier = @"friendCell";
    
    HMFriendCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (cell == nil) {
        cell = [[self alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

- (void)setFriendData:(HMFriendModel *)friendData
{
    _friendData = friendData;
    
    self.imageView.image = [UIImage imageNamed:_friendData.icon];
    self.textLabel.text = _friendData.name;
    self.detailTextLabel.text = _friendData.intro;
    
    if (_friendData.isVip) {
        self.textLabel.textColor = [UIColor redColor];
    } else {
        self.textLabel.textColor = [UIColor blackColor];
    }
}


- (void)awakeFromNib {
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
