//
//  HMFriendModel.m
//  11-作业-Q好友列表
//
//  Created by Luffy on 15/8/19.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMFriendModel.h"

@implementation HMFriendModel

- (instancetype)initWithDict:(NSDictionary *)dict
{
    self = [super init];
    if (self) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+ (instancetype)friendWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}



@end
