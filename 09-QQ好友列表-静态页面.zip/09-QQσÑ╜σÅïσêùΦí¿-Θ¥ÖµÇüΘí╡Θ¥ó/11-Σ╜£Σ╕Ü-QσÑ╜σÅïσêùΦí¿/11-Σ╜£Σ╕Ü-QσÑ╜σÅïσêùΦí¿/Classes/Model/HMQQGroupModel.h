//
//  HMQQGroupModel.h
//  11-作业-Q好友列表
//
//  Created by Luffy on 15/8/19.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HMQQGroupModel : NSObject

@property (nonatomic, strong) NSArray *friends;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *online;

@property (nonatomic, assign, getter=isOpen) BOOL open;

- (instancetype)initWithDict:(NSDictionary *)dict;
+ (instancetype)qqGroupWithDict:(NSDictionary *)dict;

+ (NSArray *)qqGroups;



@end
