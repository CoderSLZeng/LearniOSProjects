//
//  HMQQGroupModel.m
//  11-作业-Q好友列表
//
//  Created by Luffy on 15/8/19.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMQQGroupModel.h"
#import "HMFriendModel.h"

@implementation HMQQGroupModel

- (instancetype)initWithDict:(NSDictionary *)dict
{
    self = [super init];
    if (self) {
        [self setValuesForKeysWithDictionary:dict];
        
        NSMutableArray *arrayM = [NSMutableArray arrayWithCapacity:self.friends.count];
        
        for (NSDictionary *dict in self.friends) {
            HMFriendModel *friendData = [HMFriendModel friendWithDict:dict];
            
            [arrayM addObject:friendData];
        }
        self.friends = arrayM;
    }
    return self;
}

+ (instancetype)qqGroupWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}

+ (NSArray *)qqGroups
{
    NSArray *array = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"friends.plist" ofType:nil]];
    
    NSMutableArray *arrayM = [NSMutableArray array];
    
    for (NSDictionary *dict in array) {
        [arrayM addObject:[self qqGroupWithDict:dict]];
    }
    return arrayM;
}


@end
