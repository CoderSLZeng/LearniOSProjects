//
//  ViewController.m
//  11-作业-Q好友列表
//
//  Created by Luffy on 15/8/19.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "HMQQGroupModel.h"
#import "HMFriendCell.h"
#import "HMHeaderView.h"

@interface ViewController () <HMHeaderViewDelegate>

@property (nonatomic, strong) NSArray *qqGroups;

@end

@implementation ViewController

#pragma mark - 懒加载
- (NSArray *)qqGroups
{
    if (_qqGroups == nil) _qqGroups = [HMQQGroupModel qqGroups];
    return _qqGroups;
}

// 隐藏状体栏
- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // 设置头部视图的高度
    self.tableView.sectionHeaderHeight = 44;
}

#pragma mark - 数据源方法
// 分组的总数
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.qqGroups.count;
}

// 单组的总数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    HMQQGroupModel *qqGroup = self.qqGroups[section];
    
    if (qqGroup.isOpen) {
        return qqGroup.friends.count;
    }
    return 0;
}

// 单元格
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 1.创建一个cell
    
    HMFriendCell *cell = [HMFriendCell friendCellWithTableView:(UITableView *)tableView];
    
    // 2.传递模型
    HMQQGroupModel *qqGroup = self.qqGroups[indexPath.section];
    cell.friendData = qqGroup.friends[indexPath.row];

    // 3.返回cell
    return cell;
}

// 设置头部视图
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
//    UIView *view = [[UIView alloc] init];
//
//    view.backgroundColor = [UIColor redColor];
//
//    return view;
    
    // 1.创建一个HeaderView
    HMHeaderView *headerView = [HMHeaderView headerViewWithTableView:(UITableView *)tableView];
    
    headerView.delegate = self;
    
    // 2.传递模型
    headerView.qqGroup = self.qqGroups[section];
    
    // 3.返回HeaderView
    return headerView;
}

#pragma mark - HMHeaderViewDelegate
- (void)headerViewDidClickButton:(HMHeaderView *)headerView
{
    [self.tableView reloadData];
}


@end
