//
//  HMQQGroupModel.m
//  03-QQ好友列表
//
//  Created by Luffy on 15/8/17.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMQQGroupModel.h"
#import "HMFriendModel.h"

@implementation HMQQGroupModel

- (instancetype)initWithDict:(NSDictionary *)dict
{
    self = [super init];
    if (self) {
        [self setValuesForKeysWithDictionary:dict];
        
        NSMutableArray *arrayM = [NSMutableArray array];
        
        for (NSDictionary *dict in self.friends) {
            
            HMFriendModel *friend = [HMFriendModel friendWithDict:dict];
            
            [arrayM addObject:friend];
        }
        
        self.friends = arrayM;
        
    }
    return self;
}

+ (instancetype)qqGroupWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}

+ (NSArray *)qqGroups
{
    NSArray *array = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"friends.plist" ofType:nil]];
    
    NSMutableArray *arrayM = [NSMutableArray array];
    
    for (NSDictionary *dict in array) {
        [arrayM addObject:[self qqGroupWithDict:dict]];
    }
    return arrayM;
}


@end
