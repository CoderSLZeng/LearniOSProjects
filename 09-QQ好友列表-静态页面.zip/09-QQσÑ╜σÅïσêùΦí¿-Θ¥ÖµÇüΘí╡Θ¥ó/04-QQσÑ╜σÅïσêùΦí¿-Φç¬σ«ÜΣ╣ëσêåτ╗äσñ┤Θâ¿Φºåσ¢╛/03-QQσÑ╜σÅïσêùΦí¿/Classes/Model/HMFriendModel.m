//
//  HMFriendModel.m
//  03-QQ好友列表
//
//  Created by Luffy on 15/8/17.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMFriendModel.h"

@implementation HMFriendModel
- (instancetype)initWithDict:(NSDictionary *)dict
{
    self = [super init];
    if (self) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+ (instancetype)friendWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}



@end
