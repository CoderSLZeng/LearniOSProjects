//
//  HMFriendCell.m
//  03-QQ好友列表
//
//  Created by Luffy on 15/8/17.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMFriendCell.h"

@implementation HMFriendCell

+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    static NSString *identifier = @"friendCell";
    
    HMFriendCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (cell == nil) {
        cell = [[self alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identifier];
    }
    
    return cell;
}

- (void)setFriendData:(HMFriendModel *)friendData
{
    _friendData = friendData;
    
    // 1.设置头像
    self.imageView.image = [UIImage imageNamed:_friendData.icon];
    
    // 2.设置昵称
    self.textLabel.text = _friendData.name;
    
    // 3.设置简介
    self.detailTextLabel.text = _friendData.intro;
    
    if (_friendData.isVip) {
        [self.textLabel setTextColor:[UIColor redColor]];
    } else {
        [self.textLabel setTextColor:[UIColor blackColor]];
    }
}

@end
