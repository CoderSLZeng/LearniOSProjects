//
//  HMHeaderView.m
//  03-QQ好友列表
//
//  Created by Luffy on 15/8/17.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMHeaderView.h"
#import "HMQQGroupModel.h"

@implementation HMHeaderView

+ (instancetype)headerViewWithTableView:(UITableView *)tableView
{
    static NSString *identifier = @"hearderView";
    
    HMHeaderView *headerView = [tableView dequeueReusableHeaderFooterViewWithIdentifier:identifier];
    
    if (headerView == nil) {
        headerView = [[self alloc] initWithReuseIdentifier:identifier];
    }
    
    return headerView;
}

- (id)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithReuseIdentifier:reuseIdentifier];
    
    if (self) {
        
        // 1.添加子控件
        // 1.1添加按钮
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.backgroundColor = [UIColor redColor];
        btn.frame = self.bounds;
        
        [self addSubview:btn];
        
        // 1.2.添加label
        CGFloat padding = 10;
        UILabel *label = [[UILabel alloc] init];
        CGFloat labelY = 0;
        CGFloat labelH = self.bounds.size.height;
        CGFloat labelW = 150;
        CGFloat labelX = self.bounds.size.width - padding - labelW;
        label.frame = CGRectMake(labelX, labelY, labelW, labelH);
        
        [self addSubview:label];
        
    }
    return self;
}

@end
