//
//  HMAppCell.h
//  07-app管理
//
//  Created by Luffy on 15/8/18.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HMAppModel,HMAppCell;

@protocol HMAppCellDelegate <NSObject>

@required
- (void)appCelDidClickedDownloadBtn:(HMAppCell *)cell;

@end

@interface HMAppCell : UITableViewCell

+ (instancetype)appCellWithTableView:(UITableView *)tableView;

@property (nonatomic, strong) HMAppModel *app;

@property (nonatomic, strong) id<HMAppCellDelegate> delegate;

@end
