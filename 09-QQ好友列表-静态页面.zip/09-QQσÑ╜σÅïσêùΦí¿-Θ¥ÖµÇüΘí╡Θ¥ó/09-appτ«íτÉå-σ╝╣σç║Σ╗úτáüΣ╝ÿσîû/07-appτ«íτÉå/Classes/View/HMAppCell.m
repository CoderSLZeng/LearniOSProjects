//
//  HMAppCell.m
//  07-app管理
//
//  Created by Luffy on 15/8/18.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMAppCell.h"
#import "HMAppModel.h"

@interface HMAppCell ()

@property (weak, nonatomic) IBOutlet UIImageView *iconView;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;

@property (weak, nonatomic) IBOutlet UILabel *intorLael;
@property (weak, nonatomic) IBOutlet UIButton *downloadButton;

@end


@implementation HMAppCell

+ (instancetype)appCellWithTableView:(UITableView *)tableView
{
    static NSString *identifier = @"app";
    
    HMAppCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    return cell;
}

- (void)setApp:(HMAppModel *)app
{
    _app = app;
    
    self.iconView.image = [UIImage imageNamed:_app.icon];
    self.nameLabel.text = _app.name;
    self.intorLael.text = [NSString stringWithFormat:@"大小：%@ | 下载量：%@", _app.size, _app.download];
    
    self.downloadButton.enabled = !app.isDownloaded;
    
}
- (IBAction)downloadClick {
    
    NSLog(@"按钮被点击了");
    
    self.downloadButton.enabled = NO;
    self.app.downloaded = YES;
    
    if ([self.delegate respondsToSelector:@selector(appCelDidClickedDownloadBtn:)]) {
        [self.delegate appCelDidClickedDownloadBtn:self];
    }
}

@end
