//
//  ViewController.m
//  03-QQ好友列表
//
//  Created by Luffy on 15/8/17.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "HMQQGroupModel.h"
#import "HMFriendModel.h"
#import "HMFriendCell.h"

@interface ViewController ()
@property (nonatomic, strong) NSArray *qqGroups;
@end

@implementation ViewController

#pragma mark - 懒加载
- (NSArray *)qqGroups
{
    if (_qqGroups == nil) _qqGroups = [HMQQGroupModel qqGroups];
    return _qqGroups;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSLog(@"%@", self.qqGroups);
}


#pragma mark - 数据源方法
// 分组总数
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.qqGroups.count;
}

// 每一组的总数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // 1.取出对应的组模型
    HMQQGroupModel *qqGroup = self.qqGroups[section];
    return qqGroup.friends.count;
}

// 单元格
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 1.创建cell
    HMFriendCell *cell = [HMFriendCell cellWithTableView:(UITableView *)tableView];
    
    // 2.传递模型
    // 2.1取出对应的组模型
    HMQQGroupModel *qqCroup = self.qqGroups[indexPath.section];
    HMFriendModel *friend = qqCroup.friends[indexPath.row];
    cell.friendData = friend;
    
    // 3.返回cell
    return cell;
    
}

/*
// 返回分组标题
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    HMQQGroupModel *qqGroup = self.qqGroups[section];
    return qqGroup.name;
}
 */

#pragma mark - 代理方法
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    // 1.创建头部视图
    UIView *view = [[UIView alloc] init];
    view.backgroundColor = [UIColor redColor];
    
    // 2.返回头部视图
    return view;
    
}

@end
