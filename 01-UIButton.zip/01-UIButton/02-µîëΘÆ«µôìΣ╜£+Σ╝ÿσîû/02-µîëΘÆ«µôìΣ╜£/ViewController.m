//
//  ViewController.m
//  02-按钮操作
//
//  Created by Luffy on 15/7/16.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

typedef enum {
    kMovingDirTop = 10,
    kMovingDirBottom,
    kMovingDirLeft,
    kMovingDirRight,
} kMovingDir;

#define kMovingDelta 20.0f
@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIButton *iconButton;

@end

@implementation ViewController
/**
 代码优化
 1. 让重复的代码只出现一次
 */
- (IBAction)move:(UIButton *)button {
    CGRect frame = self.iconButton.frame;
    
    switch (button.tag) {
        case kMovingDirTop:
            frame.origin.y -= kMovingDelta;
            break;
        case kMovingDirBottom:
            frame.origin.y += kMovingDelta;
            break;
        case kMovingDirLeft:
            frame.origin.x -= kMovingDelta;
            break;
        case kMovingDirRight:
            frame.origin.x += kMovingDelta;
            break;
        
    }
    
    self.iconButton.frame = frame;
}

/** frame */
- (IBAction)top:(UIButton *)button {
    CGRect frame = self.iconButton.frame;
    frame.origin.y -= 20;
    self.iconButton.frame = frame;
    
}

- (IBAction)bottom:(UIButton *)button {
    CGRect frame = self.iconButton.frame;
    frame.origin.y += 20;
    self.iconButton.frame = frame;
    
}
- (IBAction)left:(UIButton *)button {
    CGRect frame = self.iconButton.frame;
    frame.origin.x -= 20;
    self.iconButton.frame = frame;
    
}
- (IBAction)right:(UIButton *)button {
    CGRect frame = self.iconButton.frame;
    frame.origin.x += 20;
    self.iconButton.frame = frame;
    
}


@end
