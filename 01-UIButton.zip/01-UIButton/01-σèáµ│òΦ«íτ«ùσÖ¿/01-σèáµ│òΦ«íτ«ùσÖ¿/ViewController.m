//
//  ViewController.m
//  01-加法计算器
//
//  Created by Luffy on 15/7/11.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

// 加法计算器成本变量
@property (nonatomic, weak) IBOutlet UITextField *num1;
@property (nonatomic, weak) IBOutlet UITextField *num2;

@property (nonatomic, weak) IBOutlet UILabel *result;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)compute
{
    // 检查是否调用了该方法
    // NSLog(@"================");
    
    // 1.获得文本框的内容
    NSString *a = self.num1.text;
    NSString *b = self.num2.text;
    
    // 2.计算文本框内容的值
    int result  = a.intValue + b.intValue;
    
    // 3.输出计算结果值
    self.result.text = [NSString stringWithFormat:@"%d", result];
    NSLog(@"result = %@", self.result.text);
    
    // 4.关闭键盘
    // 谁申请键盘，谁辞去键盘
    // [self.num1 resignFirstResponder];
    // [self.num2 resignFirstResponder];
    
    // 苹果公司提供的方法（掌握）
    [self.view endEditing:YES];
}



@end
