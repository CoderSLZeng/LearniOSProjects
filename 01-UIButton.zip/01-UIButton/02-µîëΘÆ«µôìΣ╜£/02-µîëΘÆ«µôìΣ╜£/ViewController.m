//
//  ViewController.m
//  02-按钮操作
//
//  Created by Luffy on 15/7/16.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIButton *iconButton;

@end

@implementation ViewController

- (IBAction)top:(UIButton *)button {
    CGRect frame = self.iconButton.frame;
    frame.origin.y -= 20;
    self.iconButton.frame = frame;
    
}

- (IBAction)bottom:(UIButton *)button {
    CGRect frame = self.iconButton.frame;
    frame.origin.y += 20;
    self.iconButton.frame = frame;
    
}
- (IBAction)left:(UIButton *)button {
    CGRect frame = self.iconButton.frame;
    frame.origin.x -= 20;
    self.iconButton.frame = frame;
    
}
- (IBAction)right:(UIButton *)button {
    CGRect frame = self.iconButton.frame;
    frame.origin.x += 20;
    self.iconButton.frame = frame;
    
}


@end
