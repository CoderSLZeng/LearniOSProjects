//
//  main.m
//  06-NSDictionary&NSMutableDictionary
//
//  Created by Luffy on 15/7/10.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
            // 遍历
        NSDictionary *dict = @{@"name" : @"jack", @"adress" : @"北京", @"qq" : @"37294179864", @"name2" : @"jake",};
        
//        NSArray *keys = [dict allKeys];
//        
//        for (int i=0; i<dict.count; i++) {
//            NSString *key = keys[i];
//            NSString *objects = dict[key];
//            
//            NSLog(@"%@ -- %@", key, objects);
//        }
        
        [dict enumerateKeysAndObjectsUsingBlock:
        ^(id key, id obj, BOOL *stop)
        {
            NSLog(@"%@ - %@", key, obj);
            
           // *stop = YES;
        }];
    }

    return 0;
}
// NSDictionary创建
void dictionary()
{
    // 三种方式
    // 1.创建键值对
    NSDictionary *ditc1 = [NSDictionary dictionaryWithObject:@"jack" forKey:@"name"];
    id obj = [ditc1 objectForKey:@"name"];
    NSLog(@"%@", obj);
    
    // 2.1 创建多对（数组）
    NSArray *objets = @[@"jake", @"北京"];
    NSArray *keys = @[@"name", @"address"];
    NSDictionary *dict2 = [NSDictionary dictionaryWithObjects:objets forKeys:keys];
    id obj2 = [dict2 objectForKey:@"name"];
    NSLog(@"%@", obj2);
    
    // 2.2 同时创建多对键值对
    NSDictionary *dict3 =[NSDictionary dictionaryWithObjectsAndKeys:@"jame", @"name",
                          @"南京", @"address", nil];
    id obj3 = [dict3 objectForKey:@"name"];
    NSLog(@"%@", obj3);
    
    // 3. 编译器特性 （掌握）
    NSDictionary *dict4 = @{@"name" : @"jim", @"address" : @"东京", @"qq" : @"27897956423"};
    // id obj4 = [dict4 objectForKey:@"name"];
    // NSLog(@"%@", obj4);
    // 编译器特性 （掌握）
    id obj5 = dict4[@"name"];
    NSLog(@"%@", obj5);

}

// NSMutableDictionary创建
void mutableDictionary()
{
    // 创建一个可变的字典
    NSMutableDictionary *dict1 =[NSMutableDictionary dictionary];
    
    // 添加键值对
    [dict1 setObject:@"jack" forKey:@"name"];
    [dict1 setObject:@"北京" forKey:@"adress"];
    [dict1 setObject:@"98797987" forKey:@"qq"];
    
    // 删除键值对
    [dict1 removeObjectForKey:@"qq"];
}