//
//  main.m
//  03-NSArray&NSMutableArray
//
//  Created by Luffy on 15/7/9.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // 创建一个可变数组
        NSMutableArray *array = [NSMutableArray arrayWithObjects:@"rose", @"jake", nil];
        
        // 添加一个元素
        [array addObject:@"jack"];
        [array addObject:[[Person alloc] init]];
        NSLog(@"%ld", array.count);
        NSLog(@"%@", array);
        
        // 删除数组中某个元素
        [array removeObject:@"jake"];
        NSLog(@"%ld", array.count);
        NSLog(@"%@", array);
        
        
        
           }
    return 0;
}

// NSArray创建
void arrayCreate()
{
    // 1.1 只有一个元素
    NSArray *array1 = [NSArray arrayWithObject:@"jack"];
    NSLog(@"array1 = %@", array1);
    
    /*
     1.2 多个元素
     nil是数组元素结束的标记
     */
    NSArray *array2 = [NSArray arrayWithObjects:@"jake", @"rose", nil];
    NSLog(@"array2 = %@", array2);
    
    // 1.3 快速创建NSArray对象（编译器特性）
    NSArray *array3 = @[@"jim", @"lily", @"lucy"];
    NSLog(@"array3 = %@", array3);
    
    // 2.NSArray的元素个数
    NSLog(@"%ld", array3.count);
    
    // 3.1NSArray中元素的访问
    NSLog(@"%@", [array3 objectAtIndex:1]);
    
    // 3.2 编译器特性
    NSLog(@"%@", array3[0]);
}

// NSArray数组遍历
void arraryTraversal()
{
    Person *p = [[Person alloc] init];
    
    NSArray *array = @[p, @"jack", @"rose"];
    
    // 思路1，最土的方法
    for (int i=0; i<array.count; i++) {
        NSLog(@"%d - %@", i, array[i]);
    }
    
    // 思路2.快速遍历（掌握）
    for (id obj in array)
    {
        NSUInteger i = [array indexOfObject:obj];
        
        NSLog(@"%ld - %@", i, obj);
    }
    
    // 思路3， block（最有效,掌握）
    [array enumerateObjectsUsingBlock:
     ^(id obj, NSUInteger idx, BOOL *stop)
     {
         NSLog(@"%ld - %@", idx, obj);
         
         // 数组元素下标
         if (idx == 1) {
             *stop = YES; // 退出循环
         }
     }];

}
