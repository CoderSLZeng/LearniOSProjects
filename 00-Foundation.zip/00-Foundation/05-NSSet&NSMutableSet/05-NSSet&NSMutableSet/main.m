//
//  main.m
//  05-NSSet&NSMutableSet
//
//  Created by Luffy on 15/7/10.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // NSMutableSet创建
        NSMutableSet *s1 = [NSMutableSet set];
        
        // 添加一个元素
        [s1 addObject:@"jack"];
        [s1 addObject:@"jake"];
        [s1 addObject:@"jame"];
        [s1 addObject:@"jim"];
         NSLog(@"%@", s1);
        
        // 删除某一个元素
        [s1 removeObject:@"jame"];
         NSLog(@"%@", s1);
    }
    return 0;
}

// NSSet创建 (无序）
void setCreat()
{
    NSSet *s1 = [NSSet setWithObjects:@"jack", @"jake", @"jim", @"jame", nil];
    
    // 随机取出一个元素
    NSString *str1 = [s1 anyObject];
    
    NSLog(@"%@ - %@", str1, s1);
}