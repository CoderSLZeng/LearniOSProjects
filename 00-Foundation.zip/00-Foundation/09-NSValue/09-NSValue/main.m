//
//  main.m
//  09-NSValue
//
//  Created by Luffy on 15/7/10.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        CGPoint p = CGPointMake(10, 10);
        
        NSValue *value = [NSValue valueWithPoint:p];
        [value pointerValue];
        
        NSArray *array = @[value];
        
        NSLog(@"%@", array);
    }
    return 0;
}
