//
//  main.m
//  09-NSData
//
//  Created by Luffy on 15/7/10.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        // 创建一个时间对象
        NSDate *date = [NSDate date];
        NSLog(@"%@", date);
        
        // 延时5秒再打印
        NSDate *date2 = [NSDate dateWithTimeInterval:5 sinceDate:date];
        
        // 从1970开始走过多少秒
        NSTimeInterval seconds = [date2 timeIntervalSince1970];
        NSLog(@"%f", seconds);
        
        // date2到现在的时间走过多少秒
        NSTimeInterval seconds2 = [date2 timeIntervalSinceNow];
        NSLog(@"%f", seconds2);
        
        // 创建新的日期格式化对象
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        
        // 日期格式
        formatter.dateFormat = @"yyy/MM/dd HH:mm:ss";
        
        NSString *str = [formatter stringFromDate:date];
        
        NSLog(@"%@", str);
        
    }
    return 0;
}
