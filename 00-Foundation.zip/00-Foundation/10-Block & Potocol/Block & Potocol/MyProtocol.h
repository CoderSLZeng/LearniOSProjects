//
//  MyProtocol.h
//  Block & Potocol
//
//  Created by Luffy on 15/7/4.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol MyProtocol <NSObject>

- (void)test;

- (int)sumWithA:(int)a andB:(int)b;

@end
