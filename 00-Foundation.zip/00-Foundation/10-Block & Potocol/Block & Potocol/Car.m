
//
//  Car.m
//  Block & Potocol
//
//  Created by Luffy on 15/7/4.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "Car.h"
#import "MyProtocol.h"
@implementation Car

- (void)test
{
    NSLog(@"Car");
}

- (int)sumWithA:(int)a andB:(int)b
{
    return a + b;
}

@end
