//
//  main.m
//  Block & Potocol
//
//  Created by Luffy on 15/7/4.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Car.h"
#import "MyProtocol.h"

void test();
void test2();
void test3();
void test4();

int main(int argc, const char * argv[]) {
    @autoreleasepool {
//        test();
//        test2();
//        test3();
        test4();
    }
    return 0;
}

// 没有返回值，没有形参的Block
void test()
{

    // 思路1： 先定义，再赋值
    void (^myBlock)();
    myBlock  = ^{
        NSLog(@"----------");
    };
    
    myBlock();
    
    // 改变前面的打印内容
    myBlock = ^(){
        NSLog(@"**********");
    };
    
    myBlock();
    
    // 思路2：定义赋值一起
    void (^myBlock2)() = ^{
      NSLog(@"++++++++++");
    };
    
    myBlock2();
    
}

// 有返回值， 有形参的Block
void test2()
{
    int (^sumBlock)(int, int) = ^(int a, int b) {
        return a + b;
    };
    
    NSLog(@"a + b = %i", sumBlock(5, 3));
    
    
}
// 别名的Block
typedef int (^MyBlock)(int, int);
void test3()
{
    MyBlock sumBlock = ^(int a, int b) {
        return a + b;
    };
    
    MyBlock minusBlock = ^(int a, int b)
    {
        return a - b;
    };
    
    MyBlock multiBlock = ^(int a, int b)
    {
        return a * b;
    };
    
   NSLog(@"%i - %i - %i", sumBlock(5, 3), minusBlock(10, 5), multiBlock(2,3));
    
}

void test4()
{
    Car *c = [[Car alloc] init];
    [c test];
    int sum = [c sumWithA:10 andB:5];
    NSLog(@"%i", sum);
    
    
    
}