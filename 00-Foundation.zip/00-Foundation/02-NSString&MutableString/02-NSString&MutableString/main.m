//
//  main.m
//  02-NSString&MutableString
//
//  Created by Luffy on 15/7/9.
//  Copyright (c) 2015年 itcast. All rights reserved.
//
/*
 NSString          不可变字符串
 NSMutableString   可变字符串
 */


#import <Foundation/Foundation.h>
void stringExpotr();
void stringCreate();
void mutableStringCreate();
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        stringExpotr();
        stringCreate();
        mutableStringCreate();
        
    }
    return 0;
}

// 字符串导出
void stringExpotr()
{
    // 将字符串写入某个文件夹（文件夹全路径+文件名（没有就会创建新的））
    // ToFile
    [@"jack\njack" writeToFile:@"/Users/Luffy/Desktop/my.txt" atomically:YES encoding:NSUTF8StringEncoding error:nil];
    
    // URL
    NSString *str = @"68239417897";
    NSURL *url = [NSURL fileURLWithPath:@"/Users/Luffy/Desktop/my2.txt"];
    [str writeToURL:url atomically:YES encoding:NSUTF8StringEncoding error:nil];
    
}

// 不可变字符串创建
void stringCreate()
{
    // 1.直接赋值
    NSString *s1 = @"jack";
    NSLog(@"s1 = %@", s1);
    
    // 2.重写字符串格式
    // 类方法（常用，推荐）
    //  NSString *s2 = [NSString stringWithFormat:@"age is %d", 10];
    // 对象方法
    NSString *s2 = [[NSString alloc] initWithFormat:@"age is %d", 10];
    NSLog(@"s2= %@", s2);
    
    // 3.OC字符串 --> C字符串
    // NSString *s3 = [NSString stringWithUTF8String:"jake"];
    NSString *s3 = [[NSString alloc] initWithUTF8String:"jake"];
    NSLog(@"s3= %@", s3);
    
    // 4.C字符串 --> OC字符串
    const char *c = [s3 UTF8String];
    NSLog(@"c = %s", c);
    
    // 读取某个文件夹中的字符串内容
    // 1.只能File一种形式
    // NSString *s4 = [NSString stringWithContentsOfFile:@"/Users/Luffy/Desktop/my.txt" encoding:NSUTF8StringEncoding error:nil];
    NSString *s4 = [[NSString alloc] initWithContentsOfFile:@"/Users/Luffy/Desktop/my.txt" encoding:NSUTF8StringEncoding error:nil];
    NSLog(@"s4 = \n%@", s4);
    
    // 2.URL任何形式
    // 2.1 Http://
    NSURL *url = [[NSURL alloc] initWithString:@"http://www.baidu.com"];
    // NSString *s5 = [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:nil];
    NSString *s5 = [[NSString alloc] initWithContentsOfURL:url encoding:NSUTF8StringEncoding error:nil];
    NSLog(@"s5 = \n%@", s5);
    
    // 2.2 file://
    NSURL *url2 = [[NSURL alloc] initWithString:@"file:///Users/Luffy/Desktop/my.txt"];
    NSString *s6 = [[NSString alloc] initWithContentsOfURL:url2 encoding:NSUTF8StringEncoding error:nil];
    NSLog(@"s6 = \n%@", s6);
    
    // 2.3 ftp://
    NSURL *url3 = [[NSURL alloc] initWithString:@"ftp://..."];
    NSString *s7 = [[NSString alloc] initWithContentsOfURL:url3 encoding:NSUTF8StringEncoding error:nil];
    NSLog(@"s7 = \n%@", s7);
    
}

// 可变字符串创建
void mutableStringCreate()
{
    // 直接使用类方法，不再使用对象方法（不推荐，垃圾代码）
    // 不可变字符串 和 可变字符串 比较
    NSString *s1 = [NSString stringWithFormat:@"age is 10"];
    NSMutableString *s2 = [NSMutableString stringWithFormat:@"age is 10"];
    NSLog(@"不可变s1 = %@, 可变s2 = %@", s1, s2);
    
    // 拼接内容到s2后面
    [s2 appendFormat:@" 11 12"];
    NSLog(@"不可变s1 = %@, 可变s2 = %@", s1, s2);
    
    // 删除s2中某个字符（串）--> is
    // 获取is的范围
    NSRange range = [s2 rangeOfString:@"is"];
    [s2 deleteCharactersInRange:range];
    NSLog(@"不可变s1 = %@, 可变s2 = %@", s1, s2);
    
    // 拷贝s2的内容+拼接新的内容，创建新的字符串s4（不可变）
    NSString *s4 = [s1 stringByAppendingString:@" 20 30"];
    NSLog(@"不可变s1 = %@, 不可变s4 = %@", s1, s4);
}