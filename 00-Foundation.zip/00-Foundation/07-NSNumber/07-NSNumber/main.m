//
//  main.m
//  07-NSNumber
//
//  Created by Luffy on 15/7/10.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        // @20 将20包装成一个NSNumber对象
        NSArray *array = @[@{@"name" : @"jack", @"age" : @20},
                           @{@"name" : @"jake", @"age" : @25},
                           @{@"name" : @"jame", @"age" : @27}
                           ];
        // 将各种基本数据类型包装成NSNmuber对象
        @10.5; // double
        @YES; // BOOL
        @'A'; // char NSNumber对象
        
        @"A"; // NSString对象
        
        int age = 100;
        @(age);
        
        NSNumber *n = [NSNumber numberWithDouble:10.5];
        NSLog(@"%lf", [n doubleValue]);
        
        
    }
    return 0;
}

void test()
{
    
    // 将非oc对象int包装成OC对象
    NSNumber *num = [NSNumber numberWithInt:10];
    
    // 创建字典
    NSDictionary *dict = @{
                           @"name" : @"jack",
                           @"age": num
                           };
    
    // 拿出age键的值
    NSNumber *num2 = dict[@"age"];
    
    // 转成int类型
    int a = [num2 intValue];
    NSLog(@"%d", a);

}