//
//  main.m
//  01-结构体
//
//  Created by Luffy on 15/7/8.
//  Copyright (c) 2015年 itcast. All rights reserved.
//
/*
 NSRange(location length)
 NSPoint\CGPoint
 NSSize\CGSize
 NSRect\CGRect (CGPint CGSize)
 */
#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // 设置范围 三种方式
        NSRange r1 = NSMakeRange(10, 10); // 掌握
        NSRange r2 = {.location = 20, .length = 20}; // 不用
        NSRange r3 = {30, 30}; // 不用
        NSLog(@"%ld - %ld", r1.location, r1.length);
        NSLog(@"%ld - %ld", r2.location, r2.length);
        NSLog(@"%ld - %ld", r3.location, r3.length);
        
        // 创建一个字符串str
        NSString *str = @"i love oc";
        // 查找某个字符串在str中的范围
        // 如果找不到，length=0，location=NSNotFound==-1
        NSRange range = [str rangeOfString:@"ve"]; // 获取ve在str中的范围
        NSLog(@"ov在字符串中的范围是：位置%ld -长度%ld", range.location, range.length);
        
        // 设置一个点的x值和y值
        CGPoint p1 = CGPointMake(40, 40);
        CGPoint p2 = {.x = 50, .y = 50};
        CGPoint p3 = {60, 60};
        NSLog(@"%.2f - %.2f", p1.x, p1.y);
        NSLog(@"%.2f - %.2f", p2.x, p2.y);
        NSLog(@"%.2f - %.2f", p3.x, p3.y);
        
        // 设置尺寸的width宽和height高
        CGSize s1 = CGSizeMake(70, 70);
        CGSize s2 = {.width = 80, .height = 80};
        CGSize s3 = {90, 90};
        NSLog(@"%.2f - %.2f", s1.width, s1.height);
        NSLog(@"%.2f - %.2f", s2.width, s2.height);
        NSLog(@"%.2f - %.2f", s3.width, s3.height);
        
        // 设置矩形的数值
        CGRect rt1 = CGRectMake(40, 40, 70, 70);
        CGRect rt2 = {CGPointMake(50, 50), CGSizeMake(80, 80)};
        CGRect rt3 = {p3, s3};
        NSLog(@"%.2f - %.2f - %.2f - %.2f", rt1.origin.x, rt1.origin.y, rt1.size.width, rt1.size.height);
        NSLog(@"%.2f - %.2f - %.2f - %.2f", rt2.origin.x, rt2.origin.y, rt2.size.width, rt2.size.height);
        NSLog(@"%.2f - %.2f - %.2f - %.2f", rt3.origin.x, rt3.origin.y, rt3.size.width, rt3.size.height);
       
        // 使用CGPointZero等的前提是添加CoreGraphics框架
        // CGSizeZero
        // CGRectZero
        
        // 表示原点
        // CGPointZero == CGPointMake(0, 0)
        CGRect rt4 = {CGPointZero, CGSizeZero};
        NSLog(@"%.2f - %.2f - %.2f - %.2f", rt4.origin.x, rt4.origin.y, rt4.size.width, rt4.size.height);
        
        NSString *str1 = NSStringFromPoint(p1);
        NSString *str2 = NSStringFromSize(s1);
        NSString *str3 = NSStringFromRect(rt1);
        NSLog(@"%@- %@ - %@", str1, str2, str3);
        
        // 使用这些CGPointEqualToPoint、CGRectContainsPoint等函数的前提是添加CoreGraphics框架
        
        // NextStep  Foundation
        
        // 比较两个点是否相同（x、y）
        BOOL b1 = CGPointEqualToPoint(CGPointMake(10, 10), CGPointMake(10, 10));
        
        BOOL b2 = CGPointEqualToPoint(p1, p2);
        BOOL b3 = CGSizeEqualToSize(s1, s2);
        BOOL b4 = CGRectEqualToRect(rt1, rt2);
        NSLog(@"%d - %d - %d - %d", b1, b2, b3, b4);
        
        // 某个点位置是否在矩形里面
        BOOL b5 = CGRectContainsPoint(rt1, CGPointMake(200, 200));
        NSLog(@"%d", b5);
        
        
        
    }
    return 0;
}
