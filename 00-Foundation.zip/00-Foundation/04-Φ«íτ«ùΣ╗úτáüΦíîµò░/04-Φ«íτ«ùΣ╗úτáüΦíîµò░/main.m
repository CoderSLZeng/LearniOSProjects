//
//  main.m
//  04-计算代码行数
//
//  Created by Luffy on 15/7/9.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

NSUInteger codeLineCount(NSString *path)
{
    // 1.获得文件管理者权限
    NSFileManager *mgr = [NSFileManager defaultManager];
    
    // 2.标记是否是文件夹
    BOOL dir = NO;
    
    // 标记这个路径是否存在
    BOOL exist = [mgr fileExistsAtPath:path isDirectory:&dir];
    
    if (!exist) {
        NSLog(@"文件路径不存在！！！");
        return 0;
    }
    
    // 如果代码能来到这，文件存在
    if (dir) {
        // 文件夹
        // 获得当前path文件夹下面所有内容（文件夹，文件）
        NSArray *array = [mgr contentsOfDirectoryAtPath:path error:nil];
        
        // 定义一个变量保存path中所有文件的总行数
        int count = 0;
        
        // 遍历数组中所有子文件（夹）名
        for (NSString *filename in array)
        {
            // 获得子文件（夹）的全路径
            NSString *fullPath = [NSString stringWithFormat:@"%@/%@", path, filename];
            
            count += codeLineCount(fullPath);
        }
        return count;
    }
    else
    { //文件
        // 判断文件的拓展名（忽略大小写）
        NSString *extension =[[path pathExtension] lowercaseString];
        if (![extension isEqualToString:@"h"]
            && ![extension isEqualToString:@"m"]
            && ![extension isEqualToString:@"c"])
        {
            // 文件不是h，也不是m，也不是c
            return 0;
            
        }
        // 加载文件的全部内容
        NSString *contents = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
        
        // 把文件内容分割成数组
        NSArray *array = [contents componentsSeparatedByString:@"\n"];
        
        // 删掉文件前面的路径
        NSRange range = [path rangeOfString:@"/Users/Luffy/Desktop/"];
        NSString *str = [path stringByReplacingCharactersInRange:range withString:@""];
        
        NSLog(@"%@ - %ld", str, array.count);
        
        // 范文文件代码的行数
        return array.count;

        
    }

}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSUInteger count = codeLineCount(@"/Users/Luffy/Desktop/");
        NSLog(@"%d", count);
    }
    return 0;
}


NSUInteger test(NSString *path)
{
    // 加载文件的全部内容
    NSString *contents = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    
    // 把文件内容分割成数组
    NSArray *array = [contents componentsSeparatedByString:@"\n"];
    
    // 范文文件代码的行数
    return array.count;
}