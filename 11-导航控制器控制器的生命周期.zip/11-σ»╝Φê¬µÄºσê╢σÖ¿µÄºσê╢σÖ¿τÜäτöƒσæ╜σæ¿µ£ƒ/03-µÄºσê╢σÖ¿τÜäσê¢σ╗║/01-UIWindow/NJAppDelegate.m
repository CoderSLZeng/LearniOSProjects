//
//  NJAppDelegate.m
//  01-UIWindow
//
//  Created by apple on 14-6-4.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "NJAppDelegate.h"
#import "NJViewController.h"

@implementation NJAppDelegate

// 程序启动完毕之后就会调用一次
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor whiteColor];
    /* 1
    NJViewController *vc = [[NJViewController alloc] init];
    vc.view.backgroundColor = [UIColor redColor];
    
     */
    
    /* 2
//    NJViewController *vc = [[NJViewController alloc] init];
    
    UIStoryboard *storyboard =  [UIStoryboard storyboardWithName:@"Test" bundle:nil];
    
    NJViewController *vc = [storyboard instantiateInitialViewController];
//    UIViewController *vc = [storyboard instantiateInitialViewController];
    
//    UIViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"two"];
    */
    
    NJViewController *vc = [[NJViewController alloc] initWithNibName:@"One" bundle:nil];

     
//    NSLog(@"vc - %@", vc);
//    NSLog(@"window - %@", self.window);
//    NSLog(@"rootViewController -- %@", self.window.rootViewController);
    
    self.window.rootViewController = vc;
    [self.window makeKeyAndVisible];
    return YES;
}

@end
