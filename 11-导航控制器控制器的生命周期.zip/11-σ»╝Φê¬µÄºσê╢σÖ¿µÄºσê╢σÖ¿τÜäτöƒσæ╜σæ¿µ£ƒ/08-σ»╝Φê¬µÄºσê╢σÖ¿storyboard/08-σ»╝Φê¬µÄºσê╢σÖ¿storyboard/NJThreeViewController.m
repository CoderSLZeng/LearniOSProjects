//
//  NJThreeViewController.m
//  08-导航控制器storyboard
//
//  Created by Luffy on 15/8/23.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJThreeViewController.h"

@interface NJThreeViewController ()

@end

@implementation NJThreeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


- (IBAction)jump2Two:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)jump2Root:(id)sender {
    
    [self.navigationController popToRootViewControllerAnimated:YES];
}

@end
