//
//  NJAppDelegate.m
//  01-UIWindow
//
//  Created by apple on 14-6-4.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "NJAppDelegate.h"
#import "NJViewController.h"

@implementation NJAppDelegate

// 程序启动完毕之后就会调用一次
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    NJViewController *vc = [storyBoard instantiateInitialViewController];
    
    self.window.rootViewController = vc;
    
    [self.window makeKeyAndVisible];
    
    NSLog(@"%@", self.window);
    NSLog(@"%@", self.window.rootViewController);
    
    return YES;
}

@end
