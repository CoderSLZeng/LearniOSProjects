//
//  HMOneViewController.m
//  01-UIWindow
//
//  Created by Luffy on 15/8/23.
//  Copyright (c) 2015年 heima. All rights reserved.
//

#import "HMOneViewController.h"
#import "HMTwoViewController.h"

@interface HMOneViewController ()
- (IBAction)jump2Two:(id)sender;

@end

@implementation HMOneViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"第一个控制器";
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCamera target:nil action:nil];
    
    UIBarButtonItem *item0 = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemTrash target:nil action:nil];
    
    UIBarButtonItem *item1 = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:nil action:nil];
    
    self.navigationItem.rightBarButtonItems = @[item0, item1];
    
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:nil action:nil];
}


- (IBAction)jump2Two:(id)sender {
 
    HMTwoViewController *two = [[HMTwoViewController alloc] init];
    [self.navigationController pushViewController:two animated:YES];
    
}
@end
