//
//  NJAppDelegate.m
//  01-UIWindow
//
//  Created by apple on 14-6-4.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "NJAppDelegate.h"
#import "HMOneViewController.h"

@implementation NJAppDelegate

// 程序启动完毕之后就会调用一次
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
//    self.window.backgroundColor = [UIColor redColor];
    
    UINavigationController *nav = [[UINavigationController alloc] init];
    self.window.rootViewController = nav;
    
    HMOneViewController *one = [[HMOneViewController alloc] init];
    [nav pushViewController:one animated:YES];
    
    [self.window makeKeyAndVisible];
    
    return YES;
}

- (void)testWithNav:(UINavigationController *)nav
{
    UIViewController *vc1 = [[UIViewController alloc] init];
    vc1.view.backgroundColor = [UIColor whiteColor];
    
    UIViewController *vc2 = [[UIViewController alloc] init];
    vc2.view.backgroundColor = [UIColor yellowColor];
    
    UIViewController *vc3 = [[UIViewController alloc] init];
    vc3.view.backgroundColor = [UIColor greenColor];
    
    [nav pushViewController:vc1 animated:YES];
    [nav pushViewController:vc2 animated:YES];
    [nav pushViewController:vc3 animated:YES];

}

@end
