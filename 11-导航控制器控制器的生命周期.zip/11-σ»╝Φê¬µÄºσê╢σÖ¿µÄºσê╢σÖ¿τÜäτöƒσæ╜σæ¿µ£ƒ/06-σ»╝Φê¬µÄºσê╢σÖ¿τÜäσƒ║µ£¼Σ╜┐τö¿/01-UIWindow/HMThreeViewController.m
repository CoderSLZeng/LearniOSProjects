//
//  HMThreeViewController.m
//  01-UIWindow
//
//  Created by Luffy on 15/8/23.
//  Copyright (c) 2015年 heima. All rights reserved.
//

#import "HMThreeViewController.h"
#import "HMOneViewController.h"

@interface HMThreeViewController ()
- (IBAction)jump2Root:(id)sender;
- (IBAction)jump2Two:(id)sender;

@end

@implementation HMThreeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.navigationItem.title = @"第三个控制器";
}


- (IBAction)jump2Root:(id)sender {
    [self.navigationController popToRootViewControllerAnimated:YES];
    }

- (IBAction)jump2Two:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
@end
