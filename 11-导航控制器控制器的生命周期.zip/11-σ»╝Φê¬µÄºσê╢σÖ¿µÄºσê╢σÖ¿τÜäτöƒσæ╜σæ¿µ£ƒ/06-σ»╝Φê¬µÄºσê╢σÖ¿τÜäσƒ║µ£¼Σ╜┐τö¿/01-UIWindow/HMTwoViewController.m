//
//  HMTwoViewController.m
//  01-UIWindow
//
//  Created by Luffy on 15/8/23.
//  Copyright (c) 2015年 heima. All rights reserved.
//

#import "HMTwoViewController.h"
#import "HMThreeViewController.h"

@interface HMTwoViewController ()
- (IBAction)jump2Three:(id)sender;

@end

@implementation HMTwoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.titleView = [[UISwitch alloc] init];
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:nil action:nil];
}


- (IBAction)jump2Three:(id)sender {
    
    HMThreeViewController *three = [[HMThreeViewController alloc] init];
    [self.navigationController pushViewController:three animated:YES];
}
@end
