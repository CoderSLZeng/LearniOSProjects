//
//  NJAppDelegate.m
//  01-UIWindow
//
//  Created by apple on 14-6-4.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "NJAppDelegate.h"
#import "NJViewController.h"

@implementation NJAppDelegate

// 程序启动完毕之后就会调用一次
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    UIWindow *w1 = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    w1.backgroundColor = [UIColor grayColor];
    [w1 makeKeyAndVisible];
    self.window = w1;
    
    UIWindow *w2 = [[UIWindow alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
    w2.backgroundColor = [UIColor purpleColor];
    [w2 makeKeyAndVisible];
    self.w2 = w2;
    
    UITextField *tx1 = [[UITextField alloc] initWithFrame:CGRectMake(20, 20, 20, 20)];
    tx1.borderStyle = UITextBorderStyleRoundedRect;
    [self.window addSubview:tx1];
    
    UITextField *tx2 = [[UITextField alloc] initWithFrame:CGRectMake(20, 20, 20, 20)];
    tx2.borderStyle = UITextBorderStyleRoundedRect;
    [self.w2 addSubview:tx2];
    
    NSLog(@"%@", [UIApplication sharedApplication].keyWindow);
    
    return YES;
}

- (void)test
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    self.window.backgroundColor = [UIColor redColor];
    
    NJViewController *vc = [[NJViewController alloc] init];
    
    self.window.rootViewController = vc;
    
    [self.window makeKeyAndVisible];
    

}

@end
