//
//  NJAppDelegate.m
//  01-UIWindow
//
//  Created by apple on 14-6-4.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "NJAppDelegate.h"
#import "NJViewController.h"

@implementation NJAppDelegate

/** 控制器View的创建
 * 1. 没有xib和storyboard
 * 2. 有同名的xib
 * 3. 有同名的xib去掉Controll
 * 4. 有指定xib
 * 5. 通过storyboard
 * 6. 重写控制器的loadView方法;
 */

// 程序启动完毕之后就会调用一次
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // 0.创建UIWindow
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor whiteColor];
    
    /*
    // 1. 没有xib和storyboard
    NJViewController *vc = [[NJViewController alloc] init];
    vc.view.backgroundColor = [UIColor redColor];
    */
    
    /*
    // 2. 有同名的xib
    NJViewController *vc = [[NJViewController alloc] init];
    */
    
    /*
    // 3. 有同名的xib去掉Controll
    NJViewController *vc = [[NJViewController alloc] init];
    */
    
    /*
    // 4.有指定xib
    NJViewController *vc = [[NJViewController alloc] initWithNibName:@"Test" bundle:nil];
    */
    
    /*
    // 5.通过storyboard
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"One" bundle:nil];
    NJViewController *vc = [storyboard instantiateInitialViewController];
    */
    
    // 6.重写控制器的loadView方法
    NJViewController *vc = [[NJViewController alloc] init];
    
    // 其实有两部操作，首先调用loadView方法，创建控制器的View，然后再设置控制器的View的颜色为紫色，也就是说后一次的颜色覆盖掉了前一次的颜色
    vc.view.backgroundColor = [UIColor greenColor];
    
    // 设置控制器为window的根控制器
    self.window.rootViewController = vc;
    // 设置主窗口并显示出来
    [self.window makeKeyAndVisible];
    
    return YES;
}

@end
