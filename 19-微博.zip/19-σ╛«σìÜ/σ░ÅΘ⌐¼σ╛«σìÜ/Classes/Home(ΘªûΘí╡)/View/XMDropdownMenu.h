//
//  XMDropdownMenu.h
//  小马微博
//
//  Created by Anthony on 16/3/7.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <UIKit/UIKit.h>
@class XMDropdownMenu;

@protocol XMDropdownMenuDelegate <NSObject>

@optional
- (void)dropdownMenDidShow:(XMDropdownMenu *)menu;
- (void)dropdownMenDidDismiss:(XMDropdownMenu *)menu;

@end

@interface XMDropdownMenu : UIView

@property (weak, nonatomic) id<XMDropdownMenuDelegate> delegate;

/**
 *  内容控制器
 */
@property (nonatomic, strong) UIViewController *contentController;

/**
 *  内容
 */
@property (nonatomic, strong) UIView *content;

+ (instancetype)menu;


/**
 *  显示视图
 *
 *  @param from 视图
 */
- (void)showFrom:(UIView *)from;

/**
 *  消除视图
 */
- (void)dismiss;



@end
