//
//  XMStatusCell.m
//  小马微博
//
//  Created by Anthony on 16/3/13.
//  Copyright © 2016年 Anthony. All rights reserved.

#import "XMStatusCell.h"
#import "XMStatusFrame.h"
#import "XMStatus.h"
#import "XMUser.h"
#import "XMPhoto.h"
#import "UIImageView+WebCache.h"
#import "XMStatusToolbar.h"
#import "XMStatusPhotosView.h"

@interface XMStatusCell ()
/* 原创微博 */
/** 原创微博整体 */
@property (weak, nonatomic) UIView *originalView;

/** 头像 */
@property (weak, nonatomic) UIImageView *iconView;

/** 昵称 */
@property (weak, nonatomic) UILabel *nameLabel;

/** 会员图标 */
@property (weak, nonatomic) UIImageView *vipView;

/** 时间 */
@property (weak, nonatomic) UILabel *timeLabel;

/** 来源 */
@property (weak, nonatomic) UILabel *sourceLabel;

/** 正文 */
@property (weak, nonatomic) UILabel *contentLabel;

/** 配图 */
@property (weak, nonatomic) XMStatusPhotosView *photosView;

/* 被转发微博 */
/** 被转发微博整体 */
@property (weak, nonatomic) UIView *retweetView;

/** 被转发微博昵称+正文 */
@property (weak, nonatomic) UILabel *retweetContentLabel;

/**被转发微博配图 */
@property (weak, nonatomic) XMStatusPhotosView *retweetPhotosView;

/** 工具条 */
@property (nonatomic, weak) XMStatusToolbar *toolbar;

@end

@implementation XMStatusCell

+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    static NSString *identifier = @"status";
    XMStatusCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[XMStatusCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identifier];
    }
    
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.backgroundColor = [UIColor clearColor];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        // 初始化原创微博
        [self setupOriginalStatus];
        
        // 初始化被转发微博
        [self setupRetweetStatus];
        
        // 初始化工具条
        [self setupToolbar];
        
        
        
    }
    return self;
}

/**
 *  初始化工具条
 */
- (void)setupToolbar {

    XMStatusToolbar *toolbar = [XMStatusToolbar toolbar];
    [self.contentView addSubview:toolbar];
    self.toolbar = toolbar;
}

/**
 *  初始化原创微博
 */
- (void)setupRetweetStatus {
    /* 被转发微博 */
    /** 被转发微博整体 */
    UIView *retweetView = [[UIView alloc] init];
    retweetView.backgroundColor = XMColor(247, 247, 247);
    [self.contentView addSubview:retweetView];
    self.retweetView = retweetView;
    
    /** 被转发微博昵称+正文 */
    UILabel *retweetContentLabel = [[UILabel alloc] init];
    retweetContentLabel.font = XMStatusCellRetweetContentFont;
    [retweetView addSubview:retweetContentLabel];
    retweetContentLabel.numberOfLines = 0;
    self.retweetContentLabel = retweetContentLabel;
    
    /**被转发微博配图 */
    XMStatusPhotosView *retweetPhotosView = [[XMStatusPhotosView alloc] init];
    [retweetView addSubview:retweetPhotosView];
    self.retweetPhotosView = retweetPhotosView;
}



/**
 *  初始化原创微博
 */
- (void)setupOriginalStatus {
    /** 原创微博整体 */
    UIView *originalView = [[UIView alloc] init];
    [self.contentView addSubview:originalView];
    self.originalView = originalView;
    
    /** 头像 */
    UIImageView *iconView = [[UIImageView alloc] init];
    [originalView addSubview:iconView];
    self.iconView = iconView;
    
    /** 昵称 */
    UILabel *nameLabel = [[UILabel alloc] init];
    nameLabel.font = XMStatusCellNameFont;
    [originalView addSubview:nameLabel];
    self.nameLabel = nameLabel;
    
    /** 会员图标 */
    UIImageView *vipView = [[UIImageView alloc] init];
    vipView.contentMode = UIViewContentModeCenter;
    [originalView addSubview:vipView];
    self.vipView = vipView;;
    
    /** 时间 */
    UILabel *timeLabel = [[UILabel alloc] init];
    timeLabel.font = XMStatusCellTimeFont;
    timeLabel.textColor = [UIColor orangeColor];
    [originalView addSubview:timeLabel];
    self.timeLabel = timeLabel;
    
    /** 来源 */
    UILabel *sourceLabel = [[UILabel alloc] init];
    sourceLabel.font = XMStatusCellSourceFont;
    [originalView addSubview:sourceLabel];
    self.sourceLabel = sourceLabel;
    
    /** 正文 */
    UILabel *contentLabel = [[UILabel alloc] init];
    contentLabel.font = XMStatusCellContentFont;
    contentLabel.numberOfLines = 0;
    [originalView addSubview:contentLabel];
    self.contentLabel = contentLabel;
    
    /** 配图 */
    XMStatusPhotosView *photosView = [[XMStatusPhotosView alloc] init];
    [originalView addSubview:photosView];
    self.photosView = photosView;;
}

- (void)setStatusFrame:(XMStatusFrame *)statusFrame
{
    _statusFrame = statusFrame;
    
    XMStatus *status = statusFrame.status;
    XMUser *user = status.user;
    
    /** 原创微博整体 */
    self.originalView.frame = statusFrame.originalViewF;
    
    /** 头像 */
    self.iconView.frame = statusFrame.iconViewF;
    [self.iconView sd_setImageWithURL:[NSURL URLWithString:user.profile_image_url] placeholderImage:[UIImage imageNamed:@"avatar_default_small"]];
    
    /** 昵称 */
    self.nameLabel.text = user.name;
    self.nameLabel.frame = statusFrame.nameLabelF;
    
    /** 会员图标 */
    if (user.isVip) {
        self.vipView.hidden = NO;
        
        self.vipView.frame = statusFrame.vipViewF;
        NSString *vipName = [NSString stringWithFormat:@"common_icon_membership_level%d", user.mbrank];
        self.vipView.image = [UIImage imageNamed:vipName];
        self.nameLabel.textColor = [UIColor orangeColor];
    } else {
        
        self.nameLabel.textColor = [UIColor blackColor];
        self.vipView.hidden = YES;
        
    }

    /** 时间 */
    NSString *time = status.created_at;
    CGFloat timeX = statusFrame.nameLabelF.origin.x;
    CGFloat timeY = CGRectGetMaxY(statusFrame.nameLabelF) + XMStatusCellBorderW;
    CGSize timeSize = [time sizeWithFont:XMStatusCellTimeFont];
    
    self.timeLabel.frame = (CGRect){{timeX, timeY}, timeSize};
    self.timeLabel.text = time;
    
    
    /** 来源 */
//    NSString *source = status.source;
    CGFloat sourceX = CGRectGetMaxX(self.timeLabel.frame) + XMStatusCellBorderW
    CGFloat sourceY = timeY;
    CGSize sourceSize = [status.source sizeWithFont:XMStatusCellSourceFont];
    self.sourceLabel.frame = (CGRect){{sourceX, sourceY}, sourceSize};
    self.sourceLabel.text = status.source;
    
    /** 正文 */
    self.contentLabel.text = status.text;
    self.contentLabel.frame = statusFrame.contentLabelF;
    
    /** 配图 */
    if (status.pic_urls.count) {
        self.photosView.frame = statusFrame.photosViewF;
        self.photosView.photos = status.pic_urls;
        self.photosView.hidden = NO;
    } else {
        self.photosView.hidden = YES;
    }

    /* 被转发微博 */
    if (status.retweeted_status) {
        XMStatus *retweeted_status = status.retweeted_status;
        XMUser *retweeted_status_user = retweeted_status.user;
        
        self.retweetView.hidden = NO;
        /** 被转发微博整体 */
        self.retweetView.frame = statusFrame.retweetViewF;
        
        /** 被转发微博昵称+正文 */
        NSString *retweetContent = [NSString stringWithFormat:@"@%@ : %@", retweeted_status_user.name, retweeted_status.text];
        self.retweetContentLabel.text = retweetContent;
        self.retweetContentLabel.frame = statusFrame.retweetContentLabelF;
        
        /**被转发微博配图 */
        if (retweeted_status.pic_urls.count) {
            self.retweetPhotosView.hidden = NO;
            self.retweetPhotosView.frame = statusFrame.retweetPhotosViewF;
            self.retweetPhotosView.photos = retweeted_status.pic_urls;
        } else {
            self.retweetPhotosView.hidden = YES;
        }
    } else {
        self.retweetView.hidden = YES;
    }

        
    /** 工具条 */
    self.toolbar.frame = statusFrame.toolbarF;
    self.toolbar.status = status;


}


@end
