//
//  XMStatusPhotosView.h
//  小马微博
//
//  Created by Anthony on 16/3/17.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XMStatusPhotosView : UIView

@property (nonatomic, strong) NSArray *photos;
+ (CGSize)sizeWithCount:(NSUInteger)count;
@end
