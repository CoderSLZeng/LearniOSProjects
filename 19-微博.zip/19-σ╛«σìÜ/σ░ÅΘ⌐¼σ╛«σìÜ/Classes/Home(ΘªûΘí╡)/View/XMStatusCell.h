//
//  XMStatusCell.h
//  小马微博
//
//  Created by Anthony on 16/3/13.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <UIKit/UIKit.h>
@class XMStatusFrame;

@interface XMStatusCell : UITableViewCell

@property (nonatomic, strong) XMStatusFrame *statusFrame;

+ (instancetype)cellWithTableView:(UITableView *)tableView;

@end
