//
//  XMLoadMoreFooter.m
//  小马微博
//
//  Created by Anthony on 16/3/12.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMLoadMoreFooter.h"

@implementation XMLoadMoreFooter

+ (instancetype)footer
{
    return [[[NSBundle mainBundle] loadNibNamed:@"XMLoadMoreFooter" owner:nil options:nil] lastObject];
}

@end
