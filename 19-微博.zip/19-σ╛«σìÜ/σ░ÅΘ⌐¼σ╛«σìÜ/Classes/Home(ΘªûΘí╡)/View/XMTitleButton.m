//
//  XMTitleButton.m
//  小马微博
//
//  Created by Anthony on 16/3/11.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMTitleButton.h"

@interface XMTitleButton ()

@property (nonatomic, strong) UIFont *titleFont;

@end

@implementation XMTitleButton

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self setupBasic];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super initWithCoder:aDecoder]) {
        [self setupBasic];
    }
    return self;
}

- (void)setupBasic
{
    [self setImage:[UIImage imageNamed:@"navigationbar_arrow_down"] forState:UIControlStateNormal];
    [self setImage:[UIImage imageNamed:@"navigationbar_arrow_up"] forState:UIControlStateSelected];
 
    [self setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    self.titleFont = [UIFont boldSystemFontOfSize:17];
    self.titleLabel.font = self.titleFont;
    
    self.imageView.contentMode = UIViewContentModeCenter;
}

- (CGRect)titleRectForContentRect:(CGRect)contentRect
{
    CGFloat titleX = 0;
    CGFloat titleY = 0;
    CGFloat titleW = 0;
    CGFloat titleH = contentRect.size.height;
    
    NSString *title = self.currentTitle;
    
    CGSize maxSize = CGSizeMake(MAXFLOAT, MAXFLOAT);
    NSMutableDictionary *dictM = [NSMutableDictionary dictionary];
    dictM[NSFontAttributeName] = self.titleFont;
    
    CGRect titleRect = [title boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:dictM context:nil];
    titleW = titleRect.size.width;
    
    return CGRectMake(titleX, titleY, titleW, titleH);
}

- (CGRect)imageRectForContentRect:(CGRect)contentRect
{
    CGFloat imageY = 0;
    CGFloat imageH = contentRect.size.height;
    CGFloat imageW = 13;
    CGFloat imageX = contentRect.size.width - imageW + 10;
    
    return CGRectMake(imageX, imageY, imageW, imageH);
}



@end
