//
//  XMDropdownMenu.m
//  小马微博
//
//  Created by Anthony on 16/3/7.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMDropdownMenu.h"
@interface XMDropdownMenu ()

/**
 * 容器
 */
@property (nonatomic, strong) UIImageView *containerView;

@end

@implementation XMDropdownMenu

- (UIImageView *)containerView
{
    if (!_containerView) {
        self.containerView = [[UIImageView alloc] init];
        
        UIImage *norImage = [UIImage imageNamed:@"popover_background"];
        CGFloat norImageH = norImage.size.height * 0.5;
        self.containerView.image = [norImage resizableImageWithCapInsets:UIEdgeInsetsMake(norImageH, 0, norImageH, 0) resizingMode:UIImageResizingModeStretch];
        self.containerView.userInteractionEnabled = YES;
        
        [self addSubview:_containerView];
        
    }
    
    return _containerView;
}

- (void)setContentController:(UIViewController *)contentController
{
    _contentController = contentController;
    
    self.content = contentController.view;
}

- (void)setContent:(UIView *)content
{
    _content = content;
    
    content.x = 10;
    content.y = 15;
    
    self.containerView.width = CGRectGetMaxX(content.frame) + 10;
    self.containerView.height = CGRectGetMaxY(content.frame) + 15;

    
    [self.containerView addSubview:content];
}

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}

+ (instancetype)menu
{
    return [[self alloc] init];
}

- (void)showFrom:(UIView *)from
{
    UIWindow *window = [[UIApplication sharedApplication].windows lastObject];
    
    [window addSubview:self];
    
    self.frame = window.bounds;
    
    CGRect newFrame = [from convertRect:from.bounds toView:window];
    self.containerView.centerX = CGRectGetMidX(newFrame);
    self.containerView.y = CGRectGetMaxY(newFrame);
    
    
    if ([self.delegate respondsToSelector:@selector(dropdownMenDidShow:)]) {
        [self.delegate dropdownMenDidShow:self
         ];
    }
}

- (void)dismiss
{
    [self removeFromSuperview];
    
    if ([self.delegate respondsToSelector:@selector(dropdownMenDidDismiss:)]) {
        [self.delegate dropdownMenDidDismiss:self
         ];
    }
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self dismiss];
}
@end
