//
//  XMStatusPhotosView.m
//  小马微博
//
//  Created by Anthony on 16/3/17.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMStatusPhotosView.h"
#import "UIImageView+WebCache.h"
#import "XMPhoto.h"
#import "XMStatusPhotoView.h"

#define XMStatusPhotoViewWH 70
#define XMStatusPhotoViewMargin 10
#define XMStatusPhotoViewMaxCol(count) ((count==4)?2:3)

@implementation XMStatusPhotosView

- (void)setPhotos:(NSArray *)photos
{
    _photos = photos;
    
    NSUInteger photosCount = photos.count;
    // 创建不够的图片视图
    while (self.subviews.count < photosCount) {
        XMStatusPhotoView *photoView = [[XMStatusPhotoView alloc] init];
        [self addSubview:photoView];
    }
    
    // 遍历所有的图片视图，设置图片
    for (int i = 0; i < self.subviews.count; i++) {
        XMStatusPhotoView *photoView = self.subviews[i];
        
        if (i < photosCount) {
            photoView.photo = photos[i];
            
            photoView.hidden = NO; // 显示
        } else {
            photoView.hidden = YES; // 隐藏
        }
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    NSUInteger photosCount = self.photos.count;
    for (int i = 0; i < photosCount; i++) {
        XMStatusPhotoView *photoView = self.subviews[i];
        
        photoView.width = XMStatusPhotoViewWH;
        photoView.height = XMStatusPhotoViewWH;
        int maxCol = XMStatusPhotoViewMaxCol(photosCount);
        int col = i % maxCol;
        photoView.x = col * (XMStatusPhotoViewWH + XMStatusPhotoViewMargin);
        
        int row = i / maxCol;
        photoView.y = row * (XMStatusPhotoViewWH + XMStatusPhotoViewMargin);
    }
}

+ (CGSize)sizeWithCount:(NSUInteger)count
{
    NSUInteger maxCol = XMStatusPhotoViewMaxCol(count);
    // 判断列数
    NSUInteger cols = count >= maxCol ? maxCol : count;
    CGFloat photosW = cols * (XMStatusPhotoViewWH + XMStatusPhotoViewMargin) - XMStatusPhotoViewMargin;
    
    // 判断行数
    /* 方式1
     int rows = 0;
     if (count % maxCol == 0) {
     rows = count / maxCol;
     } else {
     rows = count / maxCol + 1;
     }
     */
    
    /* 方式2
     int rows = count / maxCol;
     if (count % maxCol != 0) {
     rows += 1;
     }
     */
    
    // 方式3：套公式
    NSUInteger rows = (count + maxCol - 1) / maxCol;
    
    CGFloat photosH = rows * (XMStatusPhotoViewWH + XMStatusPhotoViewMargin) - XMStatusPhotoViewMargin;
    return CGSizeMake(photosW, photosH);
}


@end
