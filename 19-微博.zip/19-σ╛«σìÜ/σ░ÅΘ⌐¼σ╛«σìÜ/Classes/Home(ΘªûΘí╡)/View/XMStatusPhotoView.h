//
//  XMStatusPhoto.h
//  小马微博
//
//  Created by Anthony on 16/3/18.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XMPhoto.h"

@interface XMStatusPhotoView : UIImageView
@property (nonatomic, strong) XMPhoto *photo;
@end
