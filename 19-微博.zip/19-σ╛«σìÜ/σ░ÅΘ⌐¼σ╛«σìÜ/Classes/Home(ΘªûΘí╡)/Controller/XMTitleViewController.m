//
//  XMTitleViewController.m
//  小马微博
//
//  Created by Anthony on 16/3/7.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMTitleViewController.h"

@implementation XMTitleViewController


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identifier];
    }
    
    if (indexPath.row == 0) {
        cell.textLabel.text = @"好友";
    } else if (indexPath.row == 1) {
        cell.textLabel.text = @"密友";
    }  else if (indexPath.row == 2) {
        cell.textLabel.text = @"全部";
    }
    
    return cell;
}


@end
