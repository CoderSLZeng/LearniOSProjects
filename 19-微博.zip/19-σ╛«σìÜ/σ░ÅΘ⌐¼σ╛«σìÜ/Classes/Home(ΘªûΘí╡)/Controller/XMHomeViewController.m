//
//  XMHomeViewController.m
//  小马微博
//
//  Created by Anthony on 16/3/6.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMHomeViewController.h"
#import "XMTest1Controller.h"
#import "XMDropdownMenu.h"
#import "XMTitleViewController.h"
#import "AFNetworking.h"
#import "XMAccountTool.h"
#import "XMTitleButton.h"
#import "UIImageView+WebCache.h"
#import "XMStatus.h"
#import "XMUser.h"
#import "MJExtension.h"
#import "XMLoadMoreFooter.h"
#import "XMStatusCell.h"
#import "XMStatusFrame.h"


@interface XMHomeViewController () <XMDropdownMenuDelegate>
/**
 *  微博数组（里面放的都是XMStatusFrame模型，一个XMStatusFrame对象就代表一条微博）
 */
@property (nonatomic, strong) NSMutableArray *statusFrames;
@end

@implementation XMHomeViewController

#pragma mark - 懒加载
- (NSMutableArray *)statuseFrames
{
    if (!_statusFrames) {
        self.statusFrames = [NSMutableArray array];
    }
    return _statusFrames;
}

#pragma mark - 系统方法
- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 设置导航栏
    [self setupNav];

    // 获得用户信息
    [self setupUserInfo];
    
    // 集成下拉刷新控件
    [self setupDownRefresh];
    
    [self setupUpRefresh];
    
//    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:60 target:self selector:@selector(setupUnreadCount) userInfo:nil repeats:YES];
//    [[NSRunLoop currentRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];
}


/**
 *  获得未读输
 */
- (void)setupUnreadCount
{
    XMLog(@"%s", __func__);
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    XMAccount *account = [XMAccountTool account];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    /*	false	string	采用OAuth授权方式为必填参数，其他授权方式不需要此参数，OAuth授权后获得。*/
    params[@"access_token"] = account.access_token;
    /* true	int64	需要获取消息未读数的用户UID，必须是当前登录用户。*/
    params[@"uid"] = account.uid;
    
    [mgr GET:@"https://rm.api.weibo.com/2/remind/unread_count.json" parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSString *status = [responseObject[@"status"] description];
        
        if ([status isEqualToString:@"0"]) {
            // 如果是0,清空数字
            self.tabBarItem.badgeValue = nil;
            [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
        } else {
            self.tabBarItem.badgeValue = status;
            [UIApplication sharedApplication].applicationIconBadgeNumber = status.intValue;
        }
        
//        XMLog(@"%s--请求成功--%@", __func__, responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        XMLog(@"%s--请求失败--%@", __func__, error);
    }];
}


#pragma <#arguments#>
/**
 *  集成上拉刷新控件
 */
- (void)setupUpRefresh
{
    XMLoadMoreFooter *footer = [XMLoadMoreFooter footer];
    footer.hidden = YES;
    self.tableView.tableFooterView = footer;
}

/**
 *  集成下拉刷新控件
 */
- (void)setupDownRefresh
{
    UIRefreshControl *control = [[UIRefreshControl alloc] init];
    [control addTarget:self action:@selector(loadNewStatus:) forControlEvents:UIControlEventValueChanged];
    [self.tableView addSubview:control];
    
    [control beginRefreshing];
    
    [self loadNewStatus:control];
}

/**
 *  将XMStatus模型转为XMStatutsFrame模型
 */
- (NSArray *)statusFramesWithStatuses:(NSArray *)statuses
{
    NSMutableArray *frames = [NSMutableArray array];
    for (XMStatus *status in statuses) {
        XMStatusFrame *f = [[XMStatusFrame alloc] init];
        f.status = status;
        [frames addObject:f];
    }
    return frames;
}

/**
 *  集成刷新控件
 *  @param control 刷新控件
 */
- (void)loadNewStatus:(UIRefreshControl *)control
{
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        NSDictionary *responseObject = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"fakeStatus" ofType:@"plist"]];
//        // 将 "微博字典"数组 转为 "微博模型"数组
//        NSArray *newStatuses = [XMStatus objectArrayWithKeyValuesArray:responseObject[@"statuses"]];
//        
//        // 将 XMStatus数组 转为 XMStatusFrame数组
//        NSArray *newFrames = [self statusFramesWithStatuses:newStatuses];
//        
//        // 将最新的微博数据，添加到总数组的最前面
//        NSRange range = NSMakeRange(0, newFrames.count);
//        NSIndexSet *set = [NSIndexSet indexSetWithIndexesInRange:range];
//        [self.statusFrames insertObjects:newFrames atIndexes:set];
//        
//        // 刷新表格
//        [self.tableView reloadData];
//        
//        // 结束刷新
//        [control endRefreshing];
//        
//        // 显示最新微博的数量
//        [self showNewStatusCount:newStatuses.count];
//        
//    });
//    
//    return;

    
    // 1.请求管理者
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    // 2.拼接数据
    XMAccount *account = [XMAccountTool account];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"access_token"] = account.access_token;
    
    // 取出最前面的微博（最新的微博，ID最大的微博）
    XMStatusFrame *firstStatusF = [self.statuseFrames firstObject];
    if (firstStatusF) {
        // 若指定此参数，则返回ID比since_id大的微博（即比since_id时间晚的微博），默认为0
        params[@"since_id"] = firstStatusF.status.idstr;
    }
    
    [mgr GET:@"https://api.weibo.com/2/statuses/friends_timeline.json" parameters:params success:^(AFHTTPRequestOperation *operation, NSMutableDictionary *responseObject) {
        // 将 “微博字典”数组 转为“微博模型”数组
        NSArray *newStatuses = [XMStatus objectArrayWithKeyValuesArray:responseObject[@"statuses"]];
        
        NSArray *newFrames = [self statusFramesWithStatuses:newStatuses];

        // 将最前面的微博数据，添加到总数组的最前面
        NSRange range = NSMakeRange(0, newFrames.count);
        NSIndexSet *set = [NSIndexSet indexSetWithIndexesInRange:range];
        [self.statusFrames insertObjects:newFrames atIndexes:set];
        
        
        // 刷新表格
        [self.tableView reloadData];
        // 结束刷新
        [control endRefreshing];
        
        // 显示最新的微博数量
        [self showNewStatusCount:newStatuses.count];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        XMLog(@"%s--请求失败--%@", __func__, error);
        // 结束刷新
        [control endRefreshing];
    }];
}

/**
 *  加载更多的微博数据
 */
- (void)loadMoreStatus
{
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    XMAccount *account = [XMAccountTool account];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"access_token"] = account.access_token;
    
    
    XMStatusFrame *lastStatusF = [self.statusFrames lastObject];
    if (lastStatusF) {
        // 若指定此参数，则返回ID小于或等于max_id的微博，默认为0。
        // id这种数据一般都是比较大，一般转成整数的话，最好long long类型
        long long maxId = lastStatusF.status.idstr.longLongValue - 1;
        params[@"max_id"] = @(maxId);
    }

    [mgr GET:@"https://api.weibo.com/2/statuses/friends_timeline.json" parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSArray *newStatuses = [XMStatus objectArrayWithKeyValuesArray:responseObject[@"statuses"]];
        
        NSArray *newFrames = [self statusFramesWithStatuses:newStatuses];
        
        [self.statusFrames addObjectsFromArray:newFrames];
        
        [self.tableView reloadData];
        
        // 结束刷新（隐藏footer）
        self.tableView.tableFooterView.hidden = YES;
        
//        XMLog(@"%s--请求成功--%@", __func__, responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        XMLog(@"%s--请求失败--%@", __func__, error);
        
        self.tableView.tableFooterView.hidden = YES;
    }];
}

/**
 *  显示最新的微博数量
 *
 *  @param count 微博数量
 */
- (void)showNewStatusCount:(NSUInteger)count
{
    
    // 刷新成功（清楚图标数字）
    self.tabBarItem.badgeValue = nil;
    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
    
    // 1.创建label
    UILabel *label = [[UILabel alloc] init];
    label.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"timeline_new_status_background"]];
    label.width = [UIScreen mainScreen].bounds.size.width;
    label.height = 35;
    
    // 2.设置其他属性
    if (count == 0) {
        label.text = @"没有新的微博，稍后再试";
    } else {
        label.text = [NSString stringWithFormat:@"%zd条新微博", count];
    }
    label.textColor = [UIColor whiteColor];
    label.textAlignment = NSTextAlignmentCenter;
    label.font = [UIFont systemFontOfSize:16];
    
    // 3.添加
    label.y = 64 - label.height;
    [self.navigationController.view insertSubview:label belowSubview:self.navigationController.navigationBar];
    
    // 4.动画
    // 先利用1s的时间，让label往下移动一段距离
    CGFloat duration = 1.0; // 动画的时间
    [UIView animateWithDuration:duration animations:^{
//        label.y += label.height;
        label.transform = CGAffineTransformMakeTranslation(0, label.height);
    } completion:^(BOOL finished) {
        // 延迟1s后，再利用1s的时间，让label往上移动一段距离（回到一开始的状态）
        CGFloat delay = 1.0; // 延迟1s
        // UIViewAnimationOptionCurveLinear:匀速
        [UIView animateWithDuration:duration delay:delay options:UIViewAnimationOptionCurveLinear animations:^{
            label.y -= label.height;
            label.transform = CGAffineTransformIdentity;
        } completion:^(BOOL finished) {
            [label removeFromSuperview];
        }];
    }];
    
    // 如果某个动画执行完毕后，又要回到动画执行前的状态，建议使用transform来做动画
}


/**
 *  设置用户信息
 */
- (void)setupUserInfo
{
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    XMAccount *account = [XMAccountTool account];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"access_token"] = account.access_token;
    params[@"uid"] = account.uid;
    [mgr GET:@"https://api.weibo.com/2/users/show.json" parameters:params success:^(AFHTTPRequestOperation *operation, NSMutableDictionary *responseObject) {
        UIButton *titleBtn = (UIButton *)self.navigationItem.titleView;
        account.name = responseObject[@"name"];
        [titleBtn setTitle:account.name forState:UIControlStateNormal];
        [XMAccountTool saveAccount:account];
        
//        XMLog(@"%s---请求成功---%@", __func__, responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        XMLog(@"%s---请求失败---%@", __func__, error);
    }];
}

/**
 *  设置导航栏
 */
- (void)setupNav
{
    // 1.设置导航栏左边按钮
    self.navigationItem.leftBarButtonItem = [UIBarButtonItem itemWithTarget:self action:@selector(friendsearch) normalImage:@"navigationbar_friendsearch" highImage:@"navigationbar_friendsearch_highlighted"];
    
    // 2.设置导航栏右边按钮
    self.navigationItem.rightBarButtonItem = [UIBarButtonItem itemWithTarget:self action:@selector(popoverController) normalImage:@"navigationbar_pop" highImage:@"navigationbar_pop_highlighted"];
    
    // 3.设置导航栏中间标题按钮
    XMTitleButton *titleButton = [[XMTitleButton alloc] init];
    titleButton.height = 30;
    NSString *name = [XMAccountTool account].name;
    [titleButton setTitle:name?name:@"首页" forState:UIControlStateNormal];
    
    [titleButton addTarget:self action:@selector(titleClick:) forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.titleView = titleButton;

}

/**
 *  标题按钮
 */
- (void)titleClick:(UIButton *)titleButton
{
    
    XMDropdownMenu *menu = [XMDropdownMenu menu];
    menu.delegate = self;
    
    XMTitleViewController *titleVc = [[XMTitleViewController alloc] init];
    titleVc.view.height = 44 * 3;
    titleVc.view.width = 150;
    menu.contentController = titleVc;
    
    [menu showFrom:titleButton];

}

#pragma mark - XMDropdownMenuDelegate
- (void)dropdownMenDidShow:(XMDropdownMenu *)menu
{
    UIButton *titleButton = (UIButton *)self.navigationItem.titleView;
    titleButton.selected = YES;
}

- (void)dropdownMenDidDismiss:(XMDropdownMenu *)menu
{
    UIButton *titleButton = (UIButton *)self.navigationItem.titleView;
    titleButton.selected = NO;
}



- (void)friendsearch
{
    XMLog(@"%s", __func__);
}

- (void)pop
{
    XMLog(@"%s", __func__);
}
#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.statusFrames.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    XMStatusCell *cell = [XMStatusCell cellWithTableView:(UITableView *)tableView];
    
    
    cell.statusFrame = self.statusFrames[indexPath.row];
    
    return cell;
}


- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    // 如果tableView还没有数据，就直接返回
    if (self.statusFrames.count == 0 || self.tableView.tableFooterView.hidden == NO) return;
    
        CGFloat offsetY = scrollView.contentOffset.y;
    
    // 当最后一个cell完全显示在眼前时，contentOffset的y值
    CGFloat judgeOffsetY = scrollView.contentSize.height + scrollView.contentInset.bottom - scrollView.height - self.tableView.tableFooterView.height;
    
    if (offsetY >= judgeOffsetY) {  // 最后一个cell完全进入视野范围内
        self.tableView.tableFooterView.hidden = NO;
    
//        XMLog(@"%s--加载更多的微博数据", __func__);
        [self loadMoreStatus];
    }
    
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    XMStatusFrame *frame = self.statusFrames[indexPath.row];
    return frame.cellHeight;
}

@end
