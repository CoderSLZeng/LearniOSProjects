//
//  XMUser.m
//  小马微博
//
//  Created by Anthony on 16/3/11.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMUser.h"

@implementation XMUser

- (void)setMbtype:(int)mbtype
{
    _mbtype = mbtype;
    
    self.vip = mbtype > 2;
}

@end
