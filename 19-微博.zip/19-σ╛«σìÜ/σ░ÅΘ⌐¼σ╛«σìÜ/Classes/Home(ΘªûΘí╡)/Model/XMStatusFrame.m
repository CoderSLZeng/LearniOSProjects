//
//  XMStatusFrame.m
//  小马微博
//
//  Created by Anthony on 16/3/13.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMStatusFrame.h"
#import "XMStatus.h"
#import "XMUser.h"
#import "XMStatusPhotosView.h"

@implementation XMStatusFrame

- (void)setStatus:(XMStatus *)status
{
    _status = status;
    
    XMUser *user = status.user;
    
    // cell的宽度
    CGFloat cellW = [UIScreen mainScreen].bounds.size.width;
    
    /* 原创微博 */
 
    /** 头像 */
    CGFloat iconX = XMStatusCellBorderW;
    CGFloat iconY = XMStatusCellBorderW;
    CGFloat iconWH = 35;
    self.iconViewF = CGRectMake(iconX, iconY, iconWH, iconWH);
    
    /** 昵称 */
    CGFloat nameX = CGRectGetMaxX(self.iconViewF) + XMStatusCellBorderW;
    CGFloat nameY = iconY;
    CGSize nameSize = [user.name sizeWithFont:XMStatusCellNameFont];
    self.nameLabelF = (CGRect){{nameX, nameY}, nameSize};
    
    /** 会员图标 */
    if (user.isVip) {
        CGFloat vipX = CGRectGetMaxX(self.nameLabelF) + XMStatusCellBorderW;
        CGFloat vipY = nameY;
        CGFloat vipW = 14;
        CGFloat vipH = nameSize.height;
        self.vipViewF = CGRectMake(vipX, vipY, vipW, vipH);
    }
    
    
    /** 时间 */
    CGFloat timeX = nameX;
    CGFloat timeY = CGRectGetMaxY(self.nameLabelF) + XMStatusCellBorderW;
    CGSize timeSize = [status.created_at sizeWithFont:XMStatusCellTimeFont];
    self.timeLabelF = (CGRect){{timeX, timeY}, timeSize};
    
    /** 来源 */
    CGFloat sourceX = CGRectGetMaxX(self.timeLabelF) + XMStatusCellBorderW;
    CGFloat sourceY = timeY;
    CGSize sourceSize = [status.source sizeWithFont:XMStatusCellSourceFont];
    self.sourceLabelF = (CGRect){{sourceX, sourceY}, sourceSize};
    
    /** 正文 */
    CGFloat contentX= iconX;
    CGFloat contentY = MAX(CGRectGetMaxY(self.iconViewF), CGRectGetMaxY(self.timeLabelF)) + XMStatusCellBorderW;
    CGFloat maxW = cellW - 2 * contentX;
    CGSize contentSize = [status.text sizeWithFont:XMStatusCellContentFont maxW:maxW];
    self.contentLabelF = (CGRect){{contentX, contentY}, contentSize};

    
    /** 配图 */
    CGFloat originalH = 0;
    if (status.pic_urls.count) { // 有配图
        CGFloat photosX = iconX;
        CGFloat photosY = CGRectGetMaxY(self.contentLabelF) + XMStatusCellBorderW;
        CGSize photosSize = [XMStatusPhotosView sizeWithCount:status.pic_urls.count];
        self.photosViewF = (CGRect){{photosX, photosY}, photosSize};
        originalH = CGRectGetMaxY(self.photosViewF) + XMStatusCellBorderW;
    } else // 没有配图
    {
        originalH = CGRectGetMaxY(self.contentLabelF) + XMStatusCellBorderW;
    }

    /** 原创微博整体 */
    CGFloat originaX = 0;
    CGFloat originaY = XMStatusCellBorderW;
    CGFloat originalW = cellW;
    self.originalViewF = CGRectMake(originaX, originaY, originalW, originalH);
    
    
    CGFloat toolbarY = 0;
    /* 被转发微博 */
    if (status.retweeted_status) { // 如果有被转发
        XMStatus *retweeted_status = status.retweeted_status;
        XMUser *retweeted_status_user = retweeted_status.user;
        
        /** 被转发微博昵称+正文 */
        CGFloat retweetContentX = XMStatusCellBorderW;
        CGFloat retweetContentY = XMStatusCellBorderW;
        NSString *retweetContent = [NSString stringWithFormat:@"@%@ : %@", retweeted_status_user.name, retweeted_status.text];
        CGSize retweetContentSize = [retweetContent sizeWithFont:XMStatusCellRetweetContentFont maxW:maxW];
        self.retweetContentLabelF = (CGRect){{retweetContentX, retweetContentY}, retweetContentSize};
        
        //** 被转发微博配图 */
        CGFloat retweetH = 0;
        if (retweeted_status.pic_urls.count) {
            CGFloat retweetPhotosX = retweetContentX;
            CGFloat retweetPhotosY = CGRectGetMaxY(self.retweetContentLabelF) + XMStatusCellBorderW;
            CGSize retweetPhotosSize = [XMStatusPhotosView sizeWithCount:retweeted_status.pic_urls.count];
            self.retweetPhotosViewF = (CGRect){{retweetPhotosX, retweetPhotosY}, retweetPhotosSize};
            retweetH = CGRectGetMaxY(self.retweetPhotosViewF) + XMStatusCellBorderW;
        } else {
            retweetH = CGRectGetMaxY(self.retweetContentLabelF) + XMStatusCellBorderW;
        }
        
        CGFloat retweetX = 0;
        CGFloat retweetY = CGRectGetMaxY(self.originalViewF);
        CGFloat retweetW = cellW;
        /** 被转发微博整体 */
        self.retweetViewF = CGRectMake(retweetX, retweetY, retweetW, retweetH);
        
        toolbarY = CGRectGetMaxY(self.retweetViewF);
    } else {
        /** cell的高度 */
        toolbarY = CGRectGetMaxY(self.originalViewF);
    }
    
    /** 工具条 */
    CGFloat toolbarX = 0;
    CGFloat toolbarW = cellW;
    CGFloat toolbarH = 35;
    self.toolbarF = CGRectMake(toolbarX, toolbarY, toolbarW, toolbarH);
    
    /* cell的高度 */
    self.cellHeight = CGRectGetMaxY(self.toolbarF);
}


@end
