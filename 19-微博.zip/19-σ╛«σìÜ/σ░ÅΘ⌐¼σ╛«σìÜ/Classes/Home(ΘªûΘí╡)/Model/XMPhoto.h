//
//  XMPhoto.h
//  小马微博
//
//  Created by Anthony on 16/3/14.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XMPhoto : NSObject

/**  	string	缩略图片地址，没有时不返回此字段*/
@property (nonatomic, copy) NSString *thumbnail_pic;

@end
