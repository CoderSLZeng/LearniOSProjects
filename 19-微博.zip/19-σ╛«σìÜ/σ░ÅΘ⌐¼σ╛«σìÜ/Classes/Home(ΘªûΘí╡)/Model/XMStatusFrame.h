//
//  XMStatusFrame.h
//  小马微博
//
//  Created by Anthony on 16/3/13.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <Foundation/Foundation.h>

/** 昵称字体 */
#define XMStatusCellNameFont [UIFont systemFontOfSize:15]
/** 时间字体 */
#define XMStatusCellTimeFont [UIFont systemFontOfSize:12]
/** 来源字体 */
#define XMStatusCellSourceFont XMStatusCellTimeFont
/** 正文字体 */
#define XMStatusCellContentFont [UIFont systemFontOfSize:14]
/** 被转发微博昵称+正文字体 */
#define XMStatusCellRetweetContentFont [UIFont systemFontOfSize:13]

#define XMStatusCellMargin 15

#define XMStatusCellBorderW 10;

@class XMStatus;

@interface XMStatusFrame : NSObject

@property (nonatomic, strong) XMStatus *status;
/* 原创微博 */
/** 原创微博整体 */
@property (nonatomic, assign) CGRect originalViewF;

/** 头像 */
@property (nonatomic, assign) CGRect iconViewF;

/** 昵称 */
@property (nonatomic, assign) CGRect nameLabelF;

/** 会员图标 */
@property (nonatomic, assign) CGRect vipViewF;

/** 时间 */
@property (nonatomic, assign) CGRect timeLabelF;

/** 来源 */
@property (nonatomic, assign) CGRect sourceLabelF;

/** 正文 */
@property (nonatomic, assign) CGRect contentLabelF;

/** 配图 */
@property (nonatomic, assign) CGRect photosViewF;

/* 被转发微博 */
/** 被转发微博整体 */
@property (nonatomic, assign) CGRect retweetViewF;

/** 被转发微博昵称+正文 */
@property (nonatomic, assign) CGRect retweetContentLabelF;

/** 被转发微博配图 */
@property (nonatomic, assign) CGRect retweetPhotosViewF;

/** 底部工具条 */
@property (nonatomic, assign) CGRect toolbarF;

/** cell的高度 */
@property (nonatomic, assign) CGFloat cellHeight;

@end
