//
//  XMTabBarController.m
//  小马微博
//
//  Created by Anthony on 16/3/6.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMTabBarController.h"
#import "XMNavigationController.h"
#import "XMHomeViewController.h"
#import "XMMessageCenterViewController.h"
#import "XMDiscoverViewController.h"
#import "XMProfileViewController.h"
#import "XMTabBar.h"
#import "XMComposeViewController.h"

@interface XMTabBarController () <XMTabBarDelegate>

@end

@implementation XMTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 设置子控制器
    XMHomeViewController *home = [[XMHomeViewController alloc] init];
    [self addChildVc:home title:@"首页" image:@"tabbar_home" selectedImage:@"tabbar_home_selected"];
    
    XMMessageCenterViewController *messageCenter = [[XMMessageCenterViewController alloc] init];
    [self addChildVc:messageCenter title:@"消息" image:@"tabbar_message_center" selectedImage:@"tabbar_message_center_selected"];
    
    XMDiscoverViewController *discover = [[XMDiscoverViewController alloc] init];
    [self addChildVc:discover title:@"发现" image:@"tabbar_discover" selectedImage:@"tabbar_discover_selected"];
    
    XMProfileViewController *profile = [[XMProfileViewController alloc] init];
    [self addChildVc:profile title:@"我" image:@"tabbar_profile" selectedImage:@"tabbar_profile_selected"];
    
    XMTabBar *tabBar = [[XMTabBar alloc] init];
//    tabBar.delegate = self;
    [self setValue:tabBar forKey:@"tabBar"];
    
}

/**
 *  添加子控制器
 *
 *  @param childVc       子控制器
 *  @param title         标题
 *  @param image         图片
 *  @param selectedImage 选中的图片
 */
- (void)addChildVc:(UIViewController *)childVc title:(NSString *)title image:(NSString *)image selectedImage:(NSString *)selectedImage
{
    childVc.title = title;
    
    childVc.tabBarItem.title = title;
    
    // 设置图片
    childVc.tabBarItem.image = [UIImage imageNamed:image];
    childVc.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImage] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    // 设置文字样式
    NSMutableDictionary *textAttrs = [NSMutableDictionary dictionary];
    textAttrs[NSForegroundColorAttributeName] = XMColor(146, 146, 146);
    [childVc.tabBarItem setTitleTextAttributes:textAttrs forState:UIControlStateNormal];
    
    NSMutableDictionary *selectedTextAttrs = [NSMutableDictionary dictionary];
    selectedTextAttrs[NSForegroundColorAttributeName] = XMColor(255, 130, 0);
    [childVc.tabBarItem setTitleTextAttributes:selectedTextAttrs forState:UIControlStateSelected];

    XMNavigationController *nav = [[XMNavigationController alloc] initWithRootViewController:childVc];
    
    [self addChildViewController:nav];

}

#pragma mark - XMTabBarDelegate
- (void)tabbarDidClickPlusButton:(XMTabBar *)tabar
{
    XMComposeViewController *cmpVc = [[XMComposeViewController alloc] init];
    XMNavigationController *nav = [[XMNavigationController alloc] initWithRootViewController:cmpVc];
    [self presentViewController:nav animated:YES completion:nil];
}



@end
