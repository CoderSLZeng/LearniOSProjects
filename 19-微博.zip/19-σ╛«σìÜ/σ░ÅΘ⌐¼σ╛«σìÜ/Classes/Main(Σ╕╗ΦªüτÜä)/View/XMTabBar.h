//
//  XMTabBar.h
//  小马微博
//
//  Created by Anthony on 16/3/7.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <UIKit/UIKit.h>
@class XMTabBar;

@protocol XMTabBarDelegate <UITabBarDelegate>

@optional
- (void)tabbarDidClickPlusButton:(XMTabBar *)tabar;

@end

@interface XMTabBar : UITabBar
@property (weak, nonatomic) id<XMTabBarDelegate> delegate;
@end
