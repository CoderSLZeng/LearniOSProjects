//
//  XMComposeTextView.h
//  小马微博
//
//  Created by Anthony on 16/3/21.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XMTextView : UITextView
/**
 *  占位字符
 */
@property (nonatomic, copy) NSString *placeholder;

/**
 *  占位字符的颜色
 */
@property (nonatomic, strong) UIColor *placeholderColor;

@end
