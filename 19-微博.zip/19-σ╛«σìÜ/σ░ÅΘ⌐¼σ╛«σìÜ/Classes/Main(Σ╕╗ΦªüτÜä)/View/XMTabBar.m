//
//  XMTabBar.m
//  小马微博
//
//  Created by Anthony on 16/3/7.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMTabBar.h"

@interface XMTabBar ()
@property (nonatomic, strong) UIButton *plusButton;
@end

@implementation XMTabBar

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        
        UIButton *plusBtn = [[UIButton alloc] init];

        [plusBtn setImage:[UIImage imageNamed:@"tabbar_compose_icon_add"] forState:UIControlStateNormal];
        [plusBtn setImage:[UIImage imageNamed:@"tabbar_compose_icon_add_highlighted"] forState:UIControlStateHighlighted];

        [plusBtn setBackgroundImage:[UIImage imageNamed:@"tabbar_compose_button"] forState:UIControlStateNormal];
        [plusBtn setBackgroundImage:[UIImage imageNamed:@"tabbar_compose_button_highlighted"] forState:UIControlStateHighlighted];
        

        plusBtn.size = plusBtn.currentBackgroundImage.size;
        
        [plusBtn addTarget:self action:@selector(plushBtnClick) forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:plusBtn];
        
        self.plusButton = plusBtn;
    }
    return self;
}

- (void)plushBtnClick
{
    if ([self.delegate respondsToSelector:@selector(tabbarDidClickPlusButton:)]) {
        [self.delegate tabbarDidClickPlusButton:self];
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.plusButton.centerX = self.width * 0.5;
    self.plusButton.centerY = self.height * 0.5;
    
    CGFloat tabBarButtonW = self.width / 5;
    CGFloat tabBarButtonIndex = 0;
    
    for (UIView *child in self.subviews) {
       Class class = NSClassFromString(@"UITabBarButton");
        if ([child isKindOfClass:class]) {
            child.width = tabBarButtonW;
            
            child.x = tabBarButtonIndex * tabBarButtonW;
            
            tabBarButtonIndex++;
            if (tabBarButtonIndex == 2) {
                tabBarButtonIndex++;
            }
        }
        
    }
}

@end
