//
//  NSString+Extension.h
//  小马微博
//
//  Created by Anthony on 16/3/17.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Extension)
- (CGSize)sizeWithFont:(UIFont *)font maxW:(CGFloat)maxW;

- (CGSize)sizeWithFont:(UIFont *)font;
@end
