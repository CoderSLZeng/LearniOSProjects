//
//  UITextField+Extension.m
//  小马微博
//
//  Created by Anthony on 16/3/7.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "UITextField+Extension.h"

@implementation UITextField (Extension)

+ (instancetype)searchBar
{
    UITextField *searchBar = [[UITextField alloc] init];
    searchBar.bounds = CGRectMake(0, 0, 300, 30);
    searchBar.font = [UIFont systemFontOfSize:13.0];
    searchBar.placeholder = @"请输入搜索内容条件";
    
    UIImage *searchBarImage = [UIImage imageNamed:@"searchbar_textfield_background"];
    
    CGFloat searchBarW = searchBarImage.size.width * 0.5;
    CGFloat searchBarH = searchBarImage.size.height * 0.5;
    
    // 设置背景图片为可拉伸模式的
    searchBar.background = [searchBarImage resizableImageWithCapInsets:UIEdgeInsetsMake(searchBarH, searchBarW, searchBarH, searchBarW) resizingMode:UIImageResizingModeStretch];
    
    
    UIImageView *searchIcon = [[UIImageView alloc] init];
    searchIcon.bounds = CGRectMake(0, 0, 30, 30);
    searchIcon.image = [UIImage imageNamed:@"searchbar_textfield_search_icon"];

    // 内容模式居中
    searchIcon.contentMode = UIViewContentModeCenter;
    
    // 左边的视图
    searchBar.leftView = searchIcon;
    // 显示模式
    searchBar.leftViewMode = UITextFieldViewModeAlways;
    
    return searchBar;
}

@end
