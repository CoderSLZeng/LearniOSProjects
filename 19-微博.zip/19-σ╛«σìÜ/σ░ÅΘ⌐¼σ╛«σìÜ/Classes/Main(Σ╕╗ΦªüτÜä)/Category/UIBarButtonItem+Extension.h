//
//  UIBarButtonItem+Extension.h
//  小马微博
//
//  Created by Anthony on 16/3/6.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIBarButtonItem (Extension)
/**
 *  给外界传递一个UIBarButtonItem
 *
 *  @param target      外界传进来的对象
 *  @param action      监听的方法
 *  @param normalImage 普通图片
 *  @param highImage   高亮图片
 *
 *  @return <#return value description#>
 */
+ (UIBarButtonItem *)itemWithTarget:(id)target action:(SEL)action normalImage:(NSString *)normalImage highImage:(NSString *)highImage;


@end
