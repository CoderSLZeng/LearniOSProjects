//
//  UITextField+Extension.h
//  小马微博
//
//  Created by Anthony on 16/3/7.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (Extension)

/**
 *  添加一个搜索框
 *
 *  @return 搜索框
 */
+ (instancetype)searchBar;

@end
