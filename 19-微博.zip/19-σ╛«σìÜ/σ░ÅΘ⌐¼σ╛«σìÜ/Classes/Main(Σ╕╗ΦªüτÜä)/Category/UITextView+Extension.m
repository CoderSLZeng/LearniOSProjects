//
//  UITextView+Extension.m
//  小马微博
//
//  Created by Anthony on 16/3/26.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "UITextView+Extension.h"

@implementation UITextView (Extension)

- (void)insertAttributedText:(NSAttributedString *)text
{

    [self insertAttributedText:text settingBlock:nil];
    
}

- (void)insertAttributedText:(NSAttributedString *)text settingBlock:(void (^)(NSMutableAttributedString *))settingBlock
{
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] init];
    [attributedText appendAttributedString:self.attributedText];
    NSUInteger loc = self.selectedRange.location;
    [attributedText insertAttributedString:text atIndex:loc];
    self.selectedRange = NSMakeRange(loc + 1, 0);
    if (settingBlock) {
        settingBlock(attributedText);
    }
    self.attributedText = attributedText;
}

@end
