//
//  UIWindow+Extension.m
//  小马微博
//
//  Created by Anthony on 16/3/11.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "UIWindow+Extension.h"
#import "XMNewfeatureController.h"
#import "XMTabBarController.h"

@implementation UIWindow (Extension)
- (instancetype)switchRootViewController
{
    NSString *key = @"CFBundleVersion";
    
    NSString *lastVersion = [[NSUserDefaults standardUserDefaults] objectForKey:key];
    
    NSString *currentVersion = [NSBundle mainBundle].infoDictionary[key];
    
    if ([currentVersion isEqualToString:lastVersion]) {
        XMTabBarController *tabBarVc = [[XMTabBarController alloc] init];
        self.rootViewController = tabBarVc;
    } else {
        XMNewfeatureController *newFeature = [[XMNewfeatureController alloc] init];
        self.rootViewController = newFeature;
        
        [[NSUserDefaults standardUserDefaults] setObject:currentVersion forKey:key];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    
    return self;
    
}
@end
