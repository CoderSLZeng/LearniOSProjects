//
//  UIWindow+Extension.h
//  小马微博
//
//  Created by Anthony on 16/3/11.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIWindow (Extension)

- (instancetype)switchRootViewController;

@end
