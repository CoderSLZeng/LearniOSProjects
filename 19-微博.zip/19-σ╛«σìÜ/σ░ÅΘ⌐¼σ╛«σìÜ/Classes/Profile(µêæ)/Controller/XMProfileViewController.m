//
//  XMProfileViewController.m
//  小马微博
//
//  Created by Anthony on 16/3/6.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMProfileViewController.h"
#import "XMTest1Controller.h"

@interface XMProfileViewController ()

@end

@implementation XMProfileViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"设置" style:UIBarButtonItemStyleDone target:self action:@selector(setting)];
    
    
}


- (void)setting
{
    XMTest1Controller *test1 = [[XMTest1Controller alloc] init];
    test1.title = @"test1";
    
    [self.navigationController pushViewController:test1 animated:YES];
}

@end
