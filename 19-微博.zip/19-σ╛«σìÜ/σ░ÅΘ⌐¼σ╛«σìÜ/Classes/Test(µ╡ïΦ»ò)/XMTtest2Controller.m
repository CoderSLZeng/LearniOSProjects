//
//  XMTtest2Controller.m
//  小马微博
//
//  Created by Anthony on 16/3/6.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMTtest2Controller.h"
#import "XMTest3Controller.h"

@interface XMTtest2Controller ()

@end

@implementation XMTtest2Controller

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    XMTest3Controller *test3 = [[XMTest3Controller alloc] init];
    test3.title = @"测试3控制器";

    [self.navigationController pushViewController:test3 animated:YES];
}
@end
