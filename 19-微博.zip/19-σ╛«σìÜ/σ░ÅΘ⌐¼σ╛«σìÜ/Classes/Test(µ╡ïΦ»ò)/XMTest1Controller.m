//
//  XMTest1Controller.m
//  小马微博
//
//  Created by Anthony on 16/3/6.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMTest1Controller.h"
#import "XMTtest2Controller.h"

@interface XMTest1Controller ()

@end

@implementation XMTest1Controller

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{

    XMTtest2Controller *test2 = [[XMTtest2Controller alloc] init];
    test2.title = @"测试2控制器";
    [self.navigationController pushViewController:test2 animated:YES];
}
@end
