//
//  XMEmotionAttachment.m
//  小马微博
//
//  Created by Anthony on 16/3/26.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMEmotionAttachment.h"
#import "XMEmotion.h"

@implementation XMEmotionAttachment

- (void)setEmotion:(XMEmotion *)emotion
{
    _emotion = emotion;
    self.image = [UIImage imageNamed:emotion.png];
}

@end
