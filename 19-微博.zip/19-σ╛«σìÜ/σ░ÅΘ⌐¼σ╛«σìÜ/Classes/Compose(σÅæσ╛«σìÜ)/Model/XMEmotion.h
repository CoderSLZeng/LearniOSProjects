//
//  XMEmotion.h
//  小马微博
//
//  Created by Anthony on 16/3/23.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XMEmotion : NSObject <NSCoding>

/**
 *  表情的文字描述
 */
@property (nonatomic, copy) NSString *chs;

/**
 *  表情的png图片名
 */
@property (nonatomic, copy) NSString *png;
/**
 *  emoji表情的16进制编码
 */
@property (nonatomic, copy) NSString *code;

@end
