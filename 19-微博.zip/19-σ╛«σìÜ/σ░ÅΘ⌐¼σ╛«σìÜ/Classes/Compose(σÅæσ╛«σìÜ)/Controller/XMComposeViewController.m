//
//  XMComposeViewController.m
//  小马微博
//
//  Created by Anthony on 16/3/21.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMComposeViewController.h"
#import "XMAccountTool.h"
#import "XMEmotionTextView.h"
#import "AFNetworking.h"
#import "MBProgressHUD+MJ.h"
#import "XMComposeToolbar.h"
#import "XMComposePhotosView.h"
#import "XMEmotionKeyboard.h"
#import "XMEmotion.h"



@interface XMComposeViewController() <XMComposeToolbarDelegate, UITextViewDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate>

@property (nonatomic, weak) XMEmotionTextView *textView;
@property (nonatomic, weak) XMComposeToolbar *toolbar;
@property (nonatomic, weak) XMComposePhotosView *photosView;
@property (nonatomic, strong) XMEmotionKeyboard *emotionKeyboard;
@property (nonatomic, assign) BOOL switchingKeyboard;

@end

@implementation XMComposeViewController

#pragma mark - 懒加载
- (XMEmotionKeyboard *)emotionKeyboard
{
    if (!_emotionKeyboard) {
        self.emotionKeyboard = [[XMEmotionKeyboard alloc] init];
        self.emotionKeyboard.width = self.view.width;
        self.emotionKeyboard.height = 216;
        
    }
    
    return _emotionKeyboard;
}


#pragma mark - 系统方法
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // 设置导航栏
    [self setupNav];
    
    // 添加文本输入框
    [self setupTextView];
    
    // 添加工具条
    [self setupToolbar];
    
    // 添加相册
    [self setupPhotosView];
}

- (void)dealloc
{
    [XMNotificationCenter removeObserver:self];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [self.textView becomeFirstResponder];
    
}

#pragma mark - 初始化方法
/**
 *  设置导航栏
 */
- (void)setupNav
{
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"取消" style:UIBarButtonItemStyleDone target:self action:@selector(cancle)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"发送" style:UIBarButtonItemStyleDone target:self action:@selector(send)];
    self.navigationItem.rightBarButtonItem.enabled = NO;
    
    NSString *name = [XMAccountTool account].name;
    NSString *prefiex = @"发微博";
    if (name) {
        UILabel *tilteView = [[UILabel alloc] init];
        tilteView.width = 200;
        tilteView.height = 100;
        tilteView.textAlignment = NSTextAlignmentCenter;
        tilteView.numberOfLines = 0;
        
        NSString *str = [NSString stringWithFormat:@"%@\n%@", prefiex, name];
        NSMutableAttributedString *attrStr = [[NSMutableAttributedString alloc] initWithString:str];
        [attrStr addAttribute:NSFontAttributeName value:[UIFont boldSystemFontOfSize:16] range:[str rangeOfString:prefiex]];
        [attrStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:12] range:[str rangeOfString:name]];
        tilteView.attributedText = attrStr;
        self.navigationItem.titleView = tilteView;
        
    } else {
        self.title = prefiex;
    }
}

/**
 *  添加文本输入框
 */
- (void)setupTextView
{
    XMEmotionTextView *textView = [[XMEmotionTextView alloc] init];
    textView.frame = self.view.bounds;
    textView.alwaysBounceVertical = YES;
    textView.font = [UIFont systemFontOfSize:15];
    textView.placeholder = @"分享新鲜事...";
    textView.delegate = self;
    [self.view addSubview:textView];
    
    self.textView = textView;
    
    [XMNotificationCenter addObserver:self selector:@selector(textDidChange) name:UITextViewTextDidChangeNotification object:textView];
    
    [XMNotificationCenter addObserver:self selector:@selector(keyboardWillChangeFrame:) name:UIKeyboardWillChangeFrameNotification object:nil];
    
    [XMNotificationCenter addObserver:self selector:@selector(emotionDidSelected:) name:XMEmotionDidSelectedNotification object:nil];
    
    [XMNotificationCenter addObserver:self selector:@selector(emotionDidDelete) name:XMEmotionDidDeleteNotification object:nil];
    
    
}

/**
 *  添加工具栏
 */
- (void)setupToolbar
{
    XMComposeToolbar *toolbar = [XMComposeToolbar toolbar];
    toolbar.width = self.view.width;
    toolbar.height = 44;
    toolbar.x = 0;
    [self.view addSubview:toolbar];
    
    toolbar.delegate = self;
    self.toolbar = toolbar;
}

/**
 *  添加相册
 */
- (void)setupPhotosView
{
    XMComposePhotosView *photosView = [[XMComposePhotosView alloc] init];
    photosView.width = self.textView.width;
    photosView.height = self.textView.height;
    photosView.x = self.textView.x;
    photosView.y = 100;
    [self.textView addSubview:photosView];
    
    self.photosView = photosView;
    
}

#pragma mark - 监听方法
/**
 *  取消
 */
- (void)cancle
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

/**
 *  发送
 */
- (void)send
{
    if (self.photosView.photos.count) { // 有图片
        [self sendWithImage];
    } else { // 没有图片
        [self sendWithoutImage];
    }
   
}

/**
 *  发送有图片的微博
 */
- (void)sendWithImage
{
    // https://upload.api.weibo.com/2/statuses/upload.json
    //    access_token	true	string	采用OAuth授权方式为必填参数，OAuth授权后获得。
    //    status	true	string	要发布的微博文本内容，必须做URLencode，内容不超过140个汉字。
    
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"access_token"] = [XMAccountTool account].access_token;
    params[@"status"] = self.textView.fullText;
    
    [mgr POST:@"https://upload.api.weibo.com/2/statuses/upload.json" parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        
        //    pic	true	binary	要上传的图片，仅支持JPEG、GIF、PNG格式，图片大小小于5M。
        UIImage *image = [self.photosView.photos firstObject];
        NSData *data = UIImageJPEGRepresentation(image, 1.0);
        [formData appendPartWithFileData:data name:@"pic" fileName:@"test.jpg" mimeType:@"image/jpeg"];
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [MBProgressHUD showSuccess:@"发送成功"];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD showError:@"发送失败"];
    }];
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

/**
 *  发送没有图片的微博
 */
- (void)sendWithoutImage
{
    // https://api.weibo.com/2/statuses/update.json
    //    access_token	true	string	采用OAuth授权方式为必填参数，OAuth授权后获得。
    //    status	true	string	要发布的微博文本内容，必须做URLencode，内容不超过140个汉字。
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"access_token"] = [XMAccountTool account].access_token;
    params[@"status"] = self.textView.fullText;
    
    [mgr POST:@"https://api.weibo.com/2/statuses/update.json" parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [MBProgressHUD showSuccess:@"发送成功"];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD showError:@"发送失败"];
    }];
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

/**
 *  textView内容改变
 */
- (void)textDidChange
{
    self.navigationItem.rightBarButtonItem.enabled = self.textView.hasText;
}

/**
 *  键盘的fram发生改变时
 *
 *  @param notification 通知
 */
- (void)keyboardWillChangeFrame:(NSNotification *)notification
{
    if (self.switchingKeyboard) return;
    
    NSDictionary *userInfo = notification.userInfo;
    // 动画的持续时间
    double duration = [userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    // 键盘的frame
    CGRect keyboardF =[userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    // 执行动画
    [UIView animateWithDuration:duration animations:^{
        // 工具条的Y值 == 键盘的Y值 - 工具条的高度
        if (keyboardF.origin.y > self.view.height) {
            self.toolbar.y = self.view.height - self.toolbar.height;
        } else {
            self.toolbar.y = keyboardF.origin.y - self.toolbar.height;
        }
    }];
}

/**
 *  删除文字
 */
- (void)emotionDidDelete
{
    [self.textView deleteBackward];
}

/**
 *  添加选中选中表情
 */
- (void)emotionDidSelected:(NSNotification *)notification
{
    XMEmotion *emotion = notification.userInfo[XMSelectonEmotionKey];
    [self.textView insertEmotion:emotion];

}

#pragma mark - UITextViewDelegate
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [self.view endEditing:YES];
}

#pragma mark - XMComposeToolbarDelegate
- (void)composeToolbar:(XMComposeToolbar *)toolbar didClickButtonType:(XMComposeToolbarType)type
{
    switch (type) {
        case XMComposeToolbarTypeCamer:
            [self openCamer];
            break;
            
        case XMComposeToolbarTypePicture:
            [self openAlbum];
            break;
            
        case XMComposeToolbarTypeTrend:
            XMLog(@"#热门事件#");
            break;
            
        case XMComposeToolbarTypeMention:
            XMLog(@"@好友");
            break;
            
        case XMComposeToolbarTypeEmotion:
            [self switchKeyboard];
            break;
    }
}

- (void)switchKeyboard
{
    if (self.textView.inputView == nil) {
        self.textView.inputView = self.emotionKeyboard;
        
        self.toolbar.showKeyboardButton = YES;
    } else {
        self.textView.inputView = nil;
        self.toolbar.showKeyboardButton = NO;
    }
    
    // 开始切换键盘
    self.switchingKeyboard = YES;
    // 退出键盘
    [self.textView endEditing:YES];
    // 结束切换键盘
    self.switchingKeyboard = NO;
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // 弹出键盘
        [self.textView becomeFirstResponder];
    });
}

/**
 *  打开相机
 */
- (void)openCamer
{
    [self openImagePickerController:UIImagePickerControllerSourceTypeCamera];
}

/**
 *  打开相册
 */
- (void)openAlbum
{
    // 如果想自己写的图片选择器，得利用AssetsLibrary.frameWork框架，可以获得手机上的所有相册图片
    // UIImagePickerControllerSourceTypePhotoLibrary > UIImagePickerControllerSourceTypeSavedPhotosAlbum
    [self openImagePickerController:UIImagePickerControllerSourceTypePhotoLibrary];
}

- (void)openImagePickerController:(UIImagePickerControllerSourceType)type
{
    // 如果不是有效的类型，直接返回
    if (![UIImagePickerController isSourceTypeAvailable:type]) return;
    
    UIImagePickerController *ipc = [[UIImagePickerController alloc] init];
    ipc.sourceType = type;
    ipc.delegate = self;
    [self presentViewController:ipc animated:YES completion:nil];

}

#pragma mark - UINavigationControllerDelegate, UIImagePickerControllerDelegate
/**
 *  从图片选择器选择完图片后就调用（拍照完毕或者选择相册图片完毕）
 */
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    [picker dismissViewControllerAnimated:YES completion:nil];
    
    // info中包含了选择的图片
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    
    [self.photosView addPhoto:image];
    
}

@end
