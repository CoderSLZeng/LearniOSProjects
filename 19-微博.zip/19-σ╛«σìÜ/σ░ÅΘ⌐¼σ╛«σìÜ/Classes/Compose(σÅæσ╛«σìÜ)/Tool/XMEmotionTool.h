//
//  XMEmotionTool.h
//  小马微博
//
//  Created by Anthony on 16/3/26.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <Foundation/Foundation.h>
@class XMEmotion;

@interface XMEmotionTool : NSObject
+ (void)addRecentEmotion:(XMEmotion *)emotion;
+ (NSArray *)recentEmotions;

@end
