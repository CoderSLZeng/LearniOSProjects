//
//  XMEmotionTool.m
//  小马微博
//
//  Created by Anthony on 16/3/26.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#define XMRecentEmotionPath [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"emotions.archiver"]

#import "XMEmotionTool.h"


@implementation XMEmotionTool
static NSMutableArray *_recentEmotion;

+ (void)initialize
{
    
    _recentEmotion = [NSKeyedUnarchiver unarchiveObjectWithFile:XMRecentEmotionPath];
    if (_recentEmotion == nil) {
        _recentEmotion = [NSMutableArray array];
    }
}

+ (void)addRecentEmotion:(XMEmotion *)emotion
{
    // 加载沙盒中的表情数据
//    NSMutableArray *emotions = (NSMutableArray *)[self recentEmotions];
//    if (emotions == nil) {
//        emotions = [NSMutableArray array];
//    }
  
    // 删除重复的表情
    [_recentEmotion removeObject:emotion];
    
    // 将表情放到数组的最前面
//    [emotions insertObject:emotion atIndex:0];
    [_recentEmotion insertObject:emotion atIndex:0];
    
    // 将所有的表情数据写入沙盒
    [NSKeyedArchiver archiveRootObject:_recentEmotion toFile:XMRecentEmotionPath];
}

/**
 *  返回装XMEmotion模型的数组
 */
+ (NSArray *)recentEmotions
{
//    return [NSKeyedUnarchiver unarchiveObjectWithFile:XMRecentEmotionPath];
    
    return _recentEmotion;
}
@end
