//
//  XMComposePhotosView.h
//  小马微博
//
//  Created by Anthony on 16/3/21.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XMComposePhotosView : UIView
- (void)addPhoto:(UIImage *)photo;
@property (nonatomic, strong, readonly) NSMutableArray *photos;


@end
