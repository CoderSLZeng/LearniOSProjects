//
//  XMComposeToolbar.h
//  小马微博
//
//  Created by Anthony on 16/3/21.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    XMComposeToolbarTypeCamer,      // 拍照
    XMComposeToolbarTypePicture,    // 相册
    XMComposeToolbarTypeTrend,      // #
    XMComposeToolbarTypeMention,    // @
    XMComposeToolbarTypeEmotion     // 表情
}XMComposeToolbarType;

@class XMComposeToolbar;

@protocol XMComposeToolbarDelegate <NSObject>

@optional
- (void)composeToolbar:(XMComposeToolbar *)toolbar didClickButtonType:(XMComposeToolbarType)type;

@end

@interface XMComposeToolbar : UIView

+ (instancetype)toolbar;

@property (nonatomic, weak) id<XMComposeToolbarDelegate> delegate;

@property (nonatomic, assign) BOOL showKeyboardButton;

@end
