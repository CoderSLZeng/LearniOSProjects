//
//  XMEmotionTabBar.h
//  小马微博
//
//  Created by Anthony on 16/3/23.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    XMEmotionTabBarButtonTypeRecent, // 最近
    XMEmotionTabBarButtonTypeDefault, // 默认
    XMEmotionTabBarButtonTypeEmoji, // emoji
    XMEmotionTabBarButtonTypeLxh // 浪小花
    
} XMEmotionTabBarButtonType;

@class XMEmotionTabBar;

@protocol XMEmotionTabBarDelegate <NSObject>

@optional
- (void)emotionTabBar:(XMEmotionTabBar *)tabbar didSelectedButtonTpye:(XMEmotionTabBarButtonType)ButtonType;

@end

@interface XMEmotionTabBar : UIView

@property (nonatomic, weak) id<XMEmotionTabBarDelegate> delegate;

@end
