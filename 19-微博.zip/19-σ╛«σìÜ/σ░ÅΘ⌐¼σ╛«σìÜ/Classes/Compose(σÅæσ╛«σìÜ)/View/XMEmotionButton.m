//
//  XMEmotionButton.m
//  小马微博
//
//  Created by Anthony on 16/3/25.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMEmotionButton.h"
#import "XMEmotion.h"

@implementation XMEmotionButton

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self setup];
    }
    
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)decoder
{
    if (self = [super initWithCoder:decoder]) {
        [self setup];
    }
    
    return self;
}


- (void)setup
{
    self.titleLabel.font = [UIFont systemFontOfSize:32];
}

- (void)setEmotion:(XMEmotion *)emotion
{
    _emotion = emotion;
    
    if (emotion.png) {
        [self setImage:[UIImage imageNamed:emotion.png] forState:UIControlStateNormal];
    } else if (emotion.code) {
        // 设置emoji
        [self setTitle:emotion.code.emoji forState:UIControlStateNormal];
        
    }

    
}

@end
