//
//  XMEmotionKeyboard.m
//  小马微博
//
//  Created by Anthony on 16/3/23.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMEmotionKeyboard.h"
#import "XMEmotionListView.h"
#import "XMEmotionTabBar.h"
#import "XMEmotion.h"
#import "MJExtension.h"
#import "XMEmotionTool.h"

@interface XMEmotionKeyboard() <XMEmotionTabBarDelegate>

@property (nonatomic, weak) XMEmotionListView *showingListView;

@property (nonatomic, strong) XMEmotionListView *recentListView;
@property (nonatomic, strong) XMEmotionListView *defaultListView;
@property (nonatomic, strong) XMEmotionListView *emojiListView;
@property (nonatomic, strong) XMEmotionListView *lxhListView;

@property (nonatomic, weak) XMEmotionTabBar *tabBar;

@end

@implementation XMEmotionKeyboard

#pragma mark - 懒加载
- (XMEmotionListView *)recentListView
{
    if (!_recentListView) {
        self.recentListView = [[XMEmotionListView alloc] init];
        // 加载沙盒中的数据
        self.recentListView.emotions = [XMEmotionTool recentEmotions];
    }
    
    return _recentListView;
}


- (XMEmotionListView *)defaultListView
{
    if (!_defaultListView) {
        self.defaultListView = [[XMEmotionListView alloc] init];
        
        NSString *path =[[NSBundle mainBundle] pathForResource:@"EmotionIcons/default/info.plist" ofType:nil];
        self.defaultListView.emotions = [XMEmotion objectArrayWithKeyValuesArray:[NSArray arrayWithContentsOfFile:path]];
        
    }
    
    return _defaultListView;
}

- (XMEmotionListView *)emojiListView
{
    if (!_emojiListView) {
        self.emojiListView = [[XMEmotionListView alloc] init];
        
        
        NSString *path =[[NSBundle mainBundle] pathForResource:@"EmotionIcons/emoji/info.plist" ofType:nil];
        self.emojiListView.emotions = [XMEmotion objectArrayWithKeyValuesArray:[NSArray arrayWithContentsOfFile:path]];
       
    }
    
    return _emojiListView;
}

- (XMEmotionListView *)lxhListView
{
    if (!_lxhListView) {
        self.lxhListView = [[XMEmotionListView alloc] init];
        
        NSString *path =[[NSBundle mainBundle] pathForResource:@"EmotionIcons/lxh/info.plist" ofType:nil];
        self.lxhListView.emotions = [XMEmotion objectArrayWithKeyValuesArray:[NSArray arrayWithContentsOfFile:path]];
    }
    
    return _lxhListView;
}


#pragma mark - 系统方法
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // tabBar
        XMEmotionTabBar *tabBar = [[XMEmotionTabBar alloc] init];
        tabBar.delegate = self;
        [self addSubview:tabBar];
        self.tabBar = tabBar;
        
        [XMNotificationCenter addObserver:self selector:@selector(emotionDidSelect) name:XMEmotionDidSelectedNotification object:nil];
    }
    return self;
}

- (void)emotionDidSelect
{
    self.recentListView.emotions = [XMEmotionTool recentEmotions];
}

- (void)dealloc
{
    [XMNotificationCenter removeObserver:self];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    // 1.tabBar的位置
    self.tabBar.width = self.width;
    self.tabBar.height = 37;
    self.tabBar.x = 0;
    self.tabBar.y = self.height - self.tabBar.height;
    
    // 2.表情内容的位置
    self.showingListView.x = self.showingListView.y = 0;
    self.showingListView.width = self.width;
    self.showingListView.height = self.tabBar.y;
    
    UIView *childView = [self.showingListView.subviews lastObject];
    childView.frame = self.showingListView.bounds;
}

#pragma mark - XMEmotionTabBarDelegate
- (void)emotionTabBar:(XMEmotionTabBar *)tabbar didSelectedButtonTpye:(XMEmotionTabBarButtonType)ButtonType
{
    // 移除正在显示的listView控件
    [self.showingListView removeFromSuperview];
    
    switch (ButtonType) {
        case XMEmotionTabBarButtonTypeRecent: {
            
            [self addSubview:self.recentListView];
            break;
        }
            
        case XMEmotionTabBarButtonTypeDefault: {
            [self addSubview:self.defaultListView];
            break;
        }
            
        case XMEmotionTabBarButtonTypeEmoji: {
            [self addSubview:self.emojiListView];
            break;
        }
        case XMEmotionTabBarButtonTypeLxh: {
            [self addSubview:self.lxhListView];
            break;
        }
    }
    
    self.showingListView = [self.subviews lastObject];
    
    [self setNeedsLayout];
}

@end
