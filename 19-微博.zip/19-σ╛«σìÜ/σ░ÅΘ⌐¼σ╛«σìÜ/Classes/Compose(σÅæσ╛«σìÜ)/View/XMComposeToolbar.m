//
//  XMComposeToolbar.m
//  小马微博
//
//  Created by Anthony on 16/3/21.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMComposeToolbar.h"

@interface XMComposeToolbar()

@property (nonatomic, weak) UIButton *emotionButton;

@end

@implementation XMComposeToolbar

#pragma mark - 系统方法
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
    if (self) {
        self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"compose_toolbar_background"]];
        
        [self addButtonWithNorImage:@"compose_camerabutton_background" highImage:@"compose_camerabutton_background_highlighted" buttonType:XMComposeToolbarTypeCamer];
        [self addButtonWithNorImage:@"compose_toolbar_picture" highImage:@"compose_toolbar_picture_highlighted" buttonType:XMComposeToolbarTypePicture];
        [self addButtonWithNorImage:@"compose_trendbutton_background" highImage:@"compose_trendbutton_background_highlighted" buttonType:XMComposeToolbarTypeTrend];
        [self addButtonWithNorImage:@"compose_mentionbutton_background" highImage:@"compose_mentionbutton_background" buttonType:XMComposeToolbarTypeMention];
        self.emotionButton = [self addButtonWithNorImage:@"compose_emoticonbutton_background" highImage:@"compose_emoticonbutton_background_highlighted" buttonType:XMComposeToolbarTypeEmotion];
        
    }
    
    return self;
}

- (void)setShowKeyboardButton:(BOOL)showKeyboardButton
{
    _showKeyboardButton = showKeyboardButton;

    NSString *norImageName = @"compose_emoticonbutton_background";
    NSString *highImageName = @"compose_emoticonbutton_background_highlighted";
    
    // 显示键盘图标
    if (showKeyboardButton) {
        norImageName = @"compose_keyboardbutton_background";
        highImageName = @"compose_keyboardbutton_background_highlighted";
    }
    // 显示表情图标
    [self.emotionButton setImage:[UIImage imageNamed:norImageName] forState:UIControlStateNormal];
    [self.emotionButton setImage:[UIImage imageNamed:highImageName] forState:UIControlStateHighlighted];
        
    
}

+ (instancetype)toolbar
{
    return [[self alloc] init];
}


- (void)layoutSubviews
{
    [super layoutSubviews];
    
    NSUInteger count = self.subviews.count;
    CGFloat btnW = self.width / count;
    CGFloat btnH = self.height;
    
    for (int i = 0; i < count; i++) {
        
        UIButton *btn = self.subviews[i];
        btn.x = i  * btnW;
        btn.y = 0;
        btn.width = btnW;
        btn.height = btnH;
    }
}

#pragma mark - 自定义方法
- (UIButton *)addButtonWithNorImage:(NSString *)norImage highImage:(NSString *)highImage buttonType:(XMComposeToolbarType)type
{
    UIButton *btn = [[UIButton alloc] init];
    
    [btn setImage:[UIImage imageNamed:norImage] forState:UIControlStateNormal];
    [btn setImage:[UIImage imageNamed:highImage] forState:UIControlStateHighlighted];
    btn.tag = type;
    [btn addTarget:self action:@selector(buttonOnClick:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:btn];
    
    return btn;
}

#pragma mark - 监听方法
- (void)buttonOnClick:(UIButton *)btn
{
    if ([self.delegate respondsToSelector:@selector(composeToolbar:didClickButtonType:)]) {
        [self.delegate composeToolbar:self didClickButtonType:(int)btn.tag];
    }
}
@end
