//
//  XMEmotionPageView.h
//  小马微博
//
//  Created by Anthony on 16/3/23.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <UIKit/UIKit.h>

#define XMEotionMaxCols 7
#define XMEotionMaxRows 3

@interface XMEmotionPageView : UIView

/**
 *  这一页显示的表情（里面都是XMEmotion模型）
 */
@property (nonatomic, strong) NSArray *emotions;

@end
