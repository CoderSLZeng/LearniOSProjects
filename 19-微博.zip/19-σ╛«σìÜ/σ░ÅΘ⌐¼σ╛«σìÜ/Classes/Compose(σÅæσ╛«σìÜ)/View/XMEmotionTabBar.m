//
//  XMEmotionTabBar.m
//  小马微博
//
//  Created by Anthony on 16/3/23.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMEmotionTabBar.h"
#import "XMEmotionTabBarButton.h"

@interface XMEmotionTabBar()

@property (nonatomic, weak) XMEmotionTabBarButton *selectedBtn;

@end

@implementation XMEmotionTabBar

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setupButtonWithTitle:@"最近" buttonType:XMEmotionTabBarButtonTypeRecent];
        [self setupButtonWithTitle:@"默认" buttonType:XMEmotionTabBarButtonTypeDefault];
        [self setupButtonWithTitle:@"Emoji" buttonType:XMEmotionTabBarButtonTypeEmoji];
        [self setupButtonWithTitle:@"浪小花" buttonType:XMEmotionTabBarButtonTypeLxh];
    }
    return self;
}

- (void)setupButtonWithTitle:(NSString *)title buttonType:(XMEmotionTabBarButtonType)buttonType
{
    XMEmotionTabBarButton *btn = [[XMEmotionTabBarButton alloc] init];
    [btn addTarget:self action:@selector(buttonOnClick:) forControlEvents:UIControlEventTouchDown];
    btn.tag = buttonType;
    [btn setTitle:title forState:UIControlStateNormal];
    [self addSubview:btn];
    
    if (buttonType == XMEmotionTabBarButtonTypeDefault) {
        [self buttonOnClick:btn];
    }
    
    // 设置背景图片
    NSString *norImageName = @"compose_emotion_table_mid_normal";
    NSString *selectedImageName = @"compose_emotion_table_mid_selected";
    
    
    if (self.subviews.count == 1) {
        norImageName = @"compose_emotion_table_left_normal";
        selectedImageName = @"compose_emotion_table_left_selected";
    } else if (self.subviews.count == 4) {
        norImageName = @"compose_emotion_table_right_normal";
        selectedImageName = @"compose_emotion_table_right_selected";
    }
    
    UIImage *strhNorImage = [self stretchImageWithimageName:norImageName];
    UIImage *strhSelImage = [self stretchImageWithimageName:selectedImageName];
    
    [btn setBackgroundImage:strhNorImage forState:UIControlStateNormal];
    [btn setBackgroundImage:strhSelImage forState:UIControlStateDisabled];
    
}

/**
 *  拉伸图片
 */
- (UIImage *)stretchImageWithimageName:(NSString *)imageName;
{
    
    UIImage *image = [UIImage imageNamed:imageName];
    CGFloat norImageW = image.size.width * 0.5;
    
    // 拉伸图片
    UIImage *sthImage = [image resizableImageWithCapInsets:UIEdgeInsetsMake(0, norImageW, 0, norImageW) resizingMode:UIImageResizingModeStretch];
    
    return sthImage;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    NSUInteger count = self.subviews.count;
    CGFloat btnW = self.width / count;
    CGFloat btnH = self.height;
    for (int i = 0; i < count; i++) {
        XMEmotionTabBarButton *btn = self.subviews[i];
        
        btn.x = i * btnW;
        btn.y = 0;
        btn.width = btnW;
        btn.height = btnH;
    }
}

- (void)setDelegate:(id<XMEmotionTabBarDelegate>)delegate
{
    _delegate = delegate;
    
    // 选中“默认”按钮
    [self buttonOnClick:[self viewWithTag:XMEmotionTabBarButtonTypeDefault]];
}

- (void)buttonOnClick:(XMEmotionTabBarButton *)btn
{
    self.selectedBtn.enabled = YES;
    btn.enabled = NO;
    self.selectedBtn = btn;
    
    if ([self.delegate respondsToSelector:@selector(emotionTabBar:didSelectedButtonTpye:)]) {
        [self.delegate emotionTabBar:self didSelectedButtonTpye:(int)btn.tag];
    }
    
}

@end
