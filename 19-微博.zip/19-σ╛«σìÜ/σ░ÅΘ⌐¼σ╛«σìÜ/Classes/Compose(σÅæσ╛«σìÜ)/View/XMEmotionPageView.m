
//
//  XMEmotionPageView.m
//  小马微博
//
//  Created by Anthony on 16/3/23.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMEmotionPageView.h"
#import "XMEmotion.h"
#import "XMEmotionPopView.h"
#import "XMEmotionButton.h"
#import "XMEmotionTool.h"

@interface XMEmotionPageView ()

@property (nonatomic, strong) XMEmotionPopView *popView;

/**
 *  删除按钮
 */
@property (nonatomic, weak) UIButton *deleteButton;

@end

@implementation XMEmotionPageView

#pragma mark - 懒加载
- (XMEmotionPopView *)popView
{
    if (!_popView) {
        self.popView = [XMEmotionPopView popView];
    }
    
    return _popView;
}


- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        // 1.删除按钮
        UIButton *deleteButton = [[UIButton alloc] init];
        [deleteButton setImage:[UIImage imageNamed:@"compose_emotion_delete"] forState:UIControlStateNormal];
        [deleteButton setImage:[UIImage imageNamed:@"compose_emotion_delete_highlighted"] forState:UIControlStateHighlighted];
        [self addSubview:deleteButton];
        self.deleteButton = deleteButton;
        
        [deleteButton addTarget:self action:@selector(deleteButtonDidOnClick:) forControlEvents:UIControlEventTouchUpInside];
        
        // 2.添加长按手势
        [self addGestureRecognizer:[[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressPageView:)]];
    }
    return self;
}

- (XMEmotionButton *)emotionButtonWithLocation:(CGPoint)location
{
    NSUInteger count = self.emotions.count;
    for (int i = 0; i < count; i++) {
        XMEmotionButton *btn = self.subviews[i + 1];
        if (CGRectContainsPoint(btn.frame, location)) {
            return btn;
        }
    }
    return nil;
}

- (void)longPressPageView:(UILongPressGestureRecognizer *)recognizer
{
    CGPoint location = [recognizer locationInView:recognizer.view];
    
    XMEmotionButton *btn = [self emotionButtonWithLocation:location];
    
    switch (recognizer.state) {
        case UIGestureRecognizerStateCancelled:
        case UIGestureRecognizerStateEnded:
            [self.popView removeFromSuperview];
            
            if (btn) {
                [self selectEmotion:btn.emotion];
            }
            break;
            
            case UIGestureRecognizerStateBegan:
            case UIGestureRecognizerStateChanged:
        {
            [self.popView showFrom:btn];
            break;
        }
            
        default:
            break;
    }
}



- (void)dealloc
{
    [XMNotificationCenter removeObserver:self];
}

- (void)setEmotions:(NSArray *)emotions
{
    _emotions = emotions;
    
    NSUInteger count = emotions.count;
    
    for (int i = 0; i < count; i++) {
        XMEmotionButton *btn = [[XMEmotionButton alloc] init];
        [self addSubview:btn];
        btn.emotion = emotions[i];
        [btn addTarget:self action:@selector(btnOnClick:) forControlEvents:UIControlEventTouchUpInside];
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    // 内边距
    CGFloat padding = 20;
    NSUInteger count = self.emotions.count;
    CGFloat btnW = (self.width - 2 * padding) / XMEotionMaxCols;
    CGFloat btnH = (self.height - padding) / XMEotionMaxRows;
    
    for (int i = 0; i < count; i++) {
        UIButton *btn = self.subviews[i + 1];
        btn.width = btnW;
        btn.height = btnH;
        btn.x = padding + (i % XMEotionMaxCols) * btnW;
        btn.y = padding + (i / XMEotionMaxCols) * btnH;
    }
    
    self.deleteButton.width = btnW;
    self.deleteButton.height = btnH;
    self.deleteButton.x = self.width - padding - btnW;
    self.deleteButton.y = self.height - btnH;
    
}

#pragma mark - 监听方法
- (void)deleteButtonDidOnClick:(XMEmotionButton *)btn
{
    [XMNotificationCenter postNotificationName:XMEmotionDidDeleteNotification object:nil];
}

/**
 *  监听表情按钮点击
 *
 *  @param btn 被点击的按钮
 */
- (void)btnOnClick:(XMEmotionButton *)btn
{
    [self.popView showFrom:btn];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.popView removeFromSuperview];
    });
    
    [self selectEmotion:btn.emotion];
    
}

- (void)selectEmotion:(XMEmotion *)emotion
{
    // 将这个表情存进沙盒
    [XMEmotionTool addRecentEmotion:emotion];
    
    // 发出通知
    NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
    userInfo[XMSelectonEmotionKey] = emotion;
    [XMNotificationCenter postNotificationName:XMEmotionDidSelectedNotification object:nil userInfo:userInfo];
}

@end
