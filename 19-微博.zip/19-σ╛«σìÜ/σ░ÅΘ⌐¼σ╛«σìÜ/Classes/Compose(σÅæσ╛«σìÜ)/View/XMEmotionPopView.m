//
//  XMEmotionPopView.m
//  小马微博
//
//  Created by Anthony on 16/3/25.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMEmotionPopView.h"
#import "XMEmotion.h"
#import "XMEmotionButton.h"

@interface XMEmotionPopView()


@property (weak, nonatomic) IBOutlet XMEmotionButton *emotionBtn;

@end

@implementation XMEmotionPopView

+ (instancetype)popView
{
    return [[[NSBundle mainBundle] loadNibNamed:@"XMEmotionPopView" owner:nil options:nil] lastObject];
}

- (void)setEmotion:(XMEmotion *)emotion
{
    _emotion = emotion;
    
    self.emotionBtn.emotion = emotion;
}

- (void)showFrom:(XMEmotionButton *)button
{
    // 给popView传递数据
    self.emotion = button.emotion;
    
    // 取得最上面的window
    UIWindow *window = [[UIApplication sharedApplication].windows lastObject];
    [window addSubview:self];
    
    // 计算被点击的按钮在window中的frame
    CGRect btnFrame = [button convertRect:button.bounds toView:window];
    self.y = CGRectGetMidY(btnFrame) - self.height;
    self.centerX = CGRectGetMidX(btnFrame);
}

@end
