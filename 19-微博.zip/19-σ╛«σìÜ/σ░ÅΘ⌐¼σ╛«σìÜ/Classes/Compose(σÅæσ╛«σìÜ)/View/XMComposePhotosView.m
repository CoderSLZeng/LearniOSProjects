//
//  XMComposePhotosView.m
//  小马微博
//
//  Created by Anthony on 16/3/21.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMComposePhotosView.h"

@implementation XMComposePhotosView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
    if (self) {
        _photos = [NSMutableArray array];
    }
    
    return self;
}

- (void)addPhoto:(UIImage *)photo
{
    UIImageView *photoView = [[UIImageView alloc] init];
    photoView.image = photo;
    [self addSubview:photoView];
    
    [self.photos addObject:photo];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    NSUInteger count = self.subviews.count;
    CGFloat imageWH = 70;
    CGFloat imageMargin = 10;
    int maxCol = 4;
    for (int i = 0; i < count; i++) {
        UIImageView *photoView = self.subviews[i];
        
        int col = i % maxCol;
        photoView.x = col * (imageWH + imageMargin);
        
        int row = i / maxCol;
        photoView.y = row * (imageWH + imageMargin);
        photoView.width = imageWH;
        photoView.height = imageWH;
    }
    
}


@end
