
//
//  XMEmotionTextView.m
//  小马微博
//
//  Created by Anthony on 16/3/25.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMEmotionTextView.h"
#import "xmemotion.h"
#import "XMEmotionAttachment.h"

@implementation XMEmotionTextView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self setup];
    }
    return self;
}


- (instancetype)initWithCoder:(NSCoder *)decoder
{
    if (self = [super initWithCoder:decoder]) {
        [self setup];
    }
    return self;
}

- (void)setup
{

}

- (void)insertEmotion:(XMEmotion *)emotion
{
    if (emotion.code) {
        [self insertText:emotion.code.emoji];
    } else if (emotion.png) {
        
        XMEmotionAttachment *attch = [[XMEmotionAttachment alloc] init];
        attch.emotion = emotion;
        CGFloat attchWH = self.font.lineHeight;
        attch.bounds = CGRectMake(0, -4, attchWH, attchWH);
        
         NSAttributedString *imageStr = [NSAttributedString attributedStringWithAttachment:attch];
        
        [self insertAttributedText:imageStr settingBlock:^(NSMutableAttributedString *attributedText) {
            [attributedText addAttribute:NSFontAttributeName value:self.font range:NSMakeRange(0, attributedText.length)];
        }];
                                                                                 
    }
}

- (NSString *)fullText
{
    NSMutableString *fullText = [NSMutableString string];
    // 遍历所有的属性文字
    [self.attributedText enumerateAttributesInRange:NSMakeRange(0, self.attributedText.length) options:0 usingBlock:^(NSDictionary<NSString *,id> * _Nonnull attrs, NSRange range, BOOL * _Nonnull stop) {
        // 如果是图片表情
        XMEmotionAttachment *attch = attrs[@"NSAttachment"];
        if (attch) { // 图片
            [fullText appendString:attch.emotion.chs];
        } else { // emoji、普通文字
            // 获得这个范围的文字
            NSAttributedString *str = [self.attributedText attributedSubstringFromRange:range];
            [fullText appendString:str.string];
        }
    }];
    
    return fullText;

}

@end