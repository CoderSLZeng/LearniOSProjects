//
//  XMOAuthViewController.m
//  小马微博
//
//  Created by Anthony on 16/3/7.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMOAuthViewController.h"
#import "AFNetworking.h"
#import "XMAccountTool.h"
#import "UIWindow+Extension.h"



@interface XMOAuthViewController () <UIWebViewDelegate>

@end

@implementation XMOAuthViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIWebView *webView = [[UIWebView alloc] init];
    webView.frame = self.view.bounds;
    webView.delegate = self;
    [self.view addSubview:webView];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"https://api.weibo.com/oauth2/authorize?client_id=1108855842&redirect_uri=http://"]];
    [webView loadRequest:request];
    
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    NSString *url = request.URL.absoluteString;
    
    NSRange range = [url rangeOfString:@"code="];
    
    if (range.length != 0) {
        long fromIndex = range.location + range.length;
        NSString *code = [url substringFromIndex:fromIndex];
        [self accessTokenWithCode:code];
    }
    return YES;
}

- (void)accessTokenWithCode:(NSString *)code
{
    
    /*
     client_id	true	string	申请应用时分配的AppKey。
     client_secret	true	string	申请应用时分配的AppSecret。
     grant_type	true	string	请求的类型，填写authorization_code
     
     grant_type为authorization_code时
     必选	类型及范围	说明
     code	true	string	调用authorize获得的code值。
     redirect_uri	true	string	回调地址，需需与注册应用里的回调地址一致。
     */
    AFHTTPRequestOperationManager *mgr = [[AFHTTPRequestOperationManager alloc] init];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    
    params[@"client_id"] = @"1108855842";
    params[@"client_secret"] = @"d771ea9eb5f493d0ee9a5409026ead01";
    params[@"grant_type"] = @"authorization_code";
    params[@"redirect_uri"] = @"http://";
    params[@"code"] = code;
    
    [mgr POST:@"https://api.weibo.com/oauth2/access_token" parameters:params success:^(AFHTTPRequestOperation *operation, NSDictionary *responseObject) {
        
        XMAccount *account = [XMAccount accountWithDict:responseObject];
        [XMAccountTool saveAccount:account];
    
        UIWindow *window = [UIApplication sharedApplication].keyWindow;
        [window switchRootViewController];
//        XMLog(@"请求成功-%@", responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        XMLog(@"请求失败-%@", error);
    }];
}

@end
