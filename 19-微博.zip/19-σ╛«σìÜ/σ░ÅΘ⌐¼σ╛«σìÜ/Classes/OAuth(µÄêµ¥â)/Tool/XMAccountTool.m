//
//  XMAccountTool.m
//  小马微博
//
//  Created by Anthony on 16/3/11.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "XMAccountTool.h"
#define XMAccountPath [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"account.archiver"]

@implementation XMAccountTool

+ (void)saveAccount:(XMAccount *)account
{
//    account.created_time = [NSDate date];
    [NSKeyedArchiver archiveRootObject:account toFile:XMAccountPath];
}


+ (XMAccount *)account
{
    // 加载模型
    XMAccount *account = [NSKeyedUnarchiver unarchiveObjectWithFile:XMAccountPath];
    
    /* 验证是否过期 */
    
    // 过期的秒数
    long long expires_in = [account.expires_in longLongValue];
    
    // 获得过期的时间
    NSDate *expiresTime = [account.created_time dateByAddingTimeInterval:expires_in];
    // 获得当前的时间
    NSDate *now = [NSDate date];
     
    NSComparisonResult result = [expiresTime compare:now];

    if (result != NSOrderedDescending) {
        return nil;
    }
    return account;
}

@end
