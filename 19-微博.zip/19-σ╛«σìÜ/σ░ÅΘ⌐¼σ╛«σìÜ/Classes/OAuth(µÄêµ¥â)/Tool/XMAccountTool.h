//
//  XMAccountTool.h
//  小马微博
//
//  Created by Anthony on 16/3/11.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XMAccount.h"

@interface XMAccountTool : NSObject

/**
 *  存储账号信息
 */
+ (void)saveAccount:(XMAccount *)account;

/**
 *  返回账号信息
 *
 *  @return 账号模型（如果过期，返回nil）
 */
+ (XMAccount *)account;
@end
