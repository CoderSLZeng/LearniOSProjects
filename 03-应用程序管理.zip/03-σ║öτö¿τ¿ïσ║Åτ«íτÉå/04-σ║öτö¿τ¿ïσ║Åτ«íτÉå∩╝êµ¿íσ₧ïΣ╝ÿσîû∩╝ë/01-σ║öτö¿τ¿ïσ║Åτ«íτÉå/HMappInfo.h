//
//  HMappInfo.h
//  01-应用程序管理
//
//  Created by Luffy on 15/7/20.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HMappInfo : NSObject

@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *icon;

- (id)initWithDict:(NSDictionary *)dict;
+ (id)appInfoWithDict:(NSDictionary *)dict;

@end
