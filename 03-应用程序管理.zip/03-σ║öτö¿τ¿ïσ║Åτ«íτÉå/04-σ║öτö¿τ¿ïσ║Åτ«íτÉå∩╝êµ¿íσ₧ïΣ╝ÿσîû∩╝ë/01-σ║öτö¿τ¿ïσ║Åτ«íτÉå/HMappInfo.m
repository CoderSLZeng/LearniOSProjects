//
//  HMappInfo.m
//  01-应用程序管理
//
//  Created by Luffy on 15/7/20.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMappInfo.h"

@implementation HMappInfo

/**
 *  对象方法 - 重写init方法
 *
 *  @param dict 字典
 *
 *  @return 带参数的值
 */
- (instancetype)initWithDict:(NSDictionary *)dict
{
    self = [super init];
    if (self) {
        self.name = dict[@"name"];
        self.icon = dict[@"icon"];
    }
    return self;
}

/**
 *  类方法
 *
 *  @param dict 字典
 *
 *  @return 调用对象方法的init方法得到的值
 */
+ (instancetype)appInfoWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}
@end
