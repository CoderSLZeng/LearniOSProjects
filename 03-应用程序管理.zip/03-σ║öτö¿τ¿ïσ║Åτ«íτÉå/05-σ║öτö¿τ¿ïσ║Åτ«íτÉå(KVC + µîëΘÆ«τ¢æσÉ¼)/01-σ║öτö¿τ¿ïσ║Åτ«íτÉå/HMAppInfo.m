//
//  HMAppInfo.m
//  01-应用程序管理
//
//  Created by apple on 14-8-14.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import "HMAppInfo.h"

@implementation HMAppInfo

@synthesize image = _image;

- (UIImage *)image
{
    if (_image == nil) {
        _image = [UIImage imageNamed:self.icon];
    }
    return _image;
}

- (instancetype)initWithDict:(NSDictionary *)dict
{
    // self 是 对象
    self = [super init];
    if (self) {
        // 用字典给属性赋值，所有与plist键值有关的方法，均在此处！
//        self.name = dict[@"name"];
//        self.icon = dict[@"icon"];

        [self setValuesForKeysWithDictionary:dict];

    }
    return self;
}

+ (instancetype)appInfoWithDict:(NSDictionary *)dict
{
    // self 是 class
    return [[self alloc] initWithDict:dict];
}
+ (NSArray *)appList
{
    NSArray *array = [[NSArray alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"app.plist" ofType:nil]];
    
    NSMutableArray *arrayM = [NSMutableArray array];
    
    for (NSDictionary *dict in array) {
        [arrayM addObject:[HMAppInfo appInfoWithDict:dict]];
    }
    return arrayM;
}

@end
