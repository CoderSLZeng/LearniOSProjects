//
//  ViewController.m
//  01-应用程序管理
//
//  Created by Luffy on 15/7/19.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

#define kAppViewW 80
#define kAppViewH 90
#define kColCount 3
#define kStartY 20

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 边缘间距值
    CGFloat marginX = (self.view.bounds.size.width - kColCount * kAppViewW) / (kColCount + 1);
    CGFloat marginY = 10;
    for (int i=0; i<12; i++) {
        
        // 行
        // 0 1 2 => 0
        // 3 4 5 => 1
        int row = i / kColCount;
        
        // 列
        // 0 3 6 => 0
        // 1 4 7 => 1
        // 2 5 8 => 2
        int col = i % kColCount;
        
        CGFloat x = marginX + col * (kAppViewW + marginX);
        CGFloat y = kStartY + marginY + row * (kAppViewH + marginY);
        
        UIView *appView = [[UIView alloc] initWithFrame:CGRectMake(x, y, kAppViewW, kAppViewH)];
        [appView setBackgroundColor:[UIColor redColor]];
        [self.view addSubview:appView];
        
    }
    
    
    //    UIView *view2 = [[UIView alloc] initWithFrame:CGRectMake(120, 20, 80, 90)];
    //    [view2 setBackgroundColor:[UIColor redColor]];
    //    [self.view addSubview:view2];
    //    UIView *view3 = [[UIView alloc] initWithFrame:CGRectMake(220, 20, 80, 90)];
    //    [view3 setBackgroundColor:[UIColor redColor]];
    //    [self.view addSubview:view3];
    //    UIView *view4 = [[UIView alloc] initWithFrame:CGRectMake(20, 120, 80, 90)];
    //    [view4 setBackgroundColor:[UIColor redColor]];
    //    [self.view addSubview:view4];
    //    UIView *view5 = [[UIView alloc] initWithFrame:CGRectMake(120, 120, 80, 90)];
    //    [view5 setBackgroundColor:[UIColor redColor]];
    //    [self.view addSubview:view5];
    //    UIView *view6 = [[UIView alloc] initWithFrame:CGRectMake(220, 120, 80, 90)];
    //    [view6 setBackgroundColor:[UIColor redColor]];
    //    [self.view addSubview:view6];
    //    
    
}


@end
