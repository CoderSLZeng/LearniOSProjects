//
//  HMAppView.h
//  01-应用程序管理
//
//  Created by Luffy on 15/7/21.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HMAppView : UIView
@property (weak, nonatomic) IBOutlet UIImageView *iconView;
@property (weak, nonatomic) IBOutlet UILabel *lavelView;
@property (weak, nonatomic) IBOutlet UIButton *buttonView;

@end
