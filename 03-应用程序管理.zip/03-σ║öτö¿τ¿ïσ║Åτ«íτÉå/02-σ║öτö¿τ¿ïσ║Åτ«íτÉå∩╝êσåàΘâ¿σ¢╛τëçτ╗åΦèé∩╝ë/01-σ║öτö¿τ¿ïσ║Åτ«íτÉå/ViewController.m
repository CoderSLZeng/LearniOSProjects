//
//  ViewController.m
//  01-应用程序管理
//
//  Created by Luffy on 15/7/19.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (nonatomic, strong) NSArray *appList;

@end

@implementation ViewController

- (NSArray *)appList
{
    if (_appList == nil) {
        _appList = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"app.list" ofType:nil]];
    }
    return _appList;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 搭界面， 九宫格
#define kAppViewW 80
#define kAppViewH 90
#define kColCount 3
#define kStartY 20
    // 边缘间距值
    CGFloat marginX = (self.view.bounds.size.width - kColCount * kAppViewW) / (kColCount + 1);
    CGFloat marginY = 10;
    for (int i=0; i<12; i++) {
        
        // 行
        // 0 1 2 => 0
        // 3 4 5 => 1
        int row = i / kColCount;
        
        // 列
        // 0 3 6 => 0
        // 1 4 7 => 1
        // 2 5 8 => 2
        int col = i % kColCount;
        
        CGFloat x = marginX + col * (kAppViewW + marginX);
        CGFloat y = kStartY + marginY + row * (kAppViewH + marginY);
        
        UIView *appView = [[UIView alloc] initWithFrame:CGRectMake(x, y, kAppViewW, kAppViewH)];
        [appView setBackgroundColor:[UIColor redColor]];
        [self.view addSubview:appView];
        
        // 实现视图内部细节
        // 1> UIImageView -> 显示app的图片
        UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, kAppViewW, 50)];
        icon.backgroundColor = [UIColor blueColor];
        [appView addSubview:icon];
        
        // 2> UILabel -> 应用程序的名称
        UILabel *descLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(icon.frame), kAppViewW, 20)];
        descLabel.backgroundColor = [UIColor yellowColor];
        [appView addSubview:descLabel];
        
        // 3> UIButton -> 下载按钮
        UIButton *downButton = [[UIButton alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(descLabel.frame), kAppViewW, 20)];
         downButton.backgroundColor = [UIColor greenColor];
        [appView addSubview:downButton];
        
    }
   
    
}


@end
