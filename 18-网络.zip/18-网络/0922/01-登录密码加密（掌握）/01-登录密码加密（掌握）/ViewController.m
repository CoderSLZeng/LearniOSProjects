//
//  ViewController.m
//  01-登录密码加密（掌握）
//
//  Created by Anthony on 16/1/11.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import "MBProgressHUD+MJ.h"
#import "NSString+Hash.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *username;
@property (weak, nonatomic) IBOutlet UITextField *pwd;
- (IBAction)login;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

- (IBAction)login {
    NSString *usernameText = self.username.text;
    if (0 == usernameText.length) {
        [MBProgressHUD showError:@"请输入用户名"];
        return;
    }
    
    NSString *pwdText = self.pwd.text;
    if (0 == pwdText.length) {
        [MBProgressHUD showError:@"请输入密码"];
        return;
    }
    
    [MBProgressHUD showMessage:@"正在拼命登录中..."];
    NSURL *url = [NSURL URLWithString:@"http://localhost:8080//MJServer/login"];
    NSMutableURLRequest *requestM = [NSMutableURLRequest requestWithURL:url];
    
    requestM.timeoutInterval = 15;
    
    requestM.HTTPMethod = @"POST";
    
#warning 对pwdText进行加密
    pwdText = [self MD5Reorder:pwdText];
    
    NSString *param = [NSString stringWithFormat:@"username=%@&pwd=%@", usernameText, pwdText];
    
    NSLog(@"%@", param);
    
    requestM.HTTPBody = [param dataUsingEncoding:NSUTF8StringEncoding];
    
    [requestM setValue:@"iPhone 6s Plus" forHTTPHeaderField:@"User-Agent"];
    
    [NSURLConnection sendAsynchronousRequest:requestM queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse * _Nullable response, NSData * _Nullable data, NSError * _Nullable connectionError) {
        [MBProgressHUD hideHUD];
        
        if (connectionError || data == nil) {
            [MBProgressHUD showError:@"请求失败"];
            return;
        }
        
        NSDictionary *dict =  [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        NSString *error = dict[@"error"];
        if (error) {
            [MBProgressHUD showError:error];
        } else {
            NSString *success = dict[@"success"];
            [MBProgressHUD showSuccess:success];
        }
    }];
    
}

/**
 *  MD5($pass.$salt)
 *
 *  @param text 明文
 *
 *  @return 加密后的密文
 */
- (NSString *)MD5Slat:(NSString *)text
{
    // 撒盐：随机地往明文中插入任意字符串
    NSString *slat = [text stringByAppendingString:@"aaa"];
    return [slat md5String];
}

/**
 *  MD5($pass)
 *
 *  @param text 明文
 *
 *  @return 加密后的密文
 */
- (NSString *)doubleMD5:(NSString *)text
{
    return [[text md5String] md5String];
}

/**
 *  先加密，后乱序
 *
 *  @param text 明文
 *
 *  @return 加密后的密文
 */
- (NSString *)MD5Reorder:(NSString *)text
{
    NSString *pwd = [text md5String];
    
    NSString *prefix = [pwd substringFromIndex:2];
    NSString *subfix = [pwd substringFromIndex:2];
    
    NSString *result = [prefix stringByAppendingString:subfix];
    
    NSLog(@"\ntext=%@\npwd=%@\nresult=%@", text, pwd, result);
    return result;
}



@end
