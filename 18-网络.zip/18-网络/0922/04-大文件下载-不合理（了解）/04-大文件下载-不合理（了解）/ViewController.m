//
//  ViewController.m
//  04-大文件下载-不合理（了解）
//
//  Created by Anthony on 16/1/11.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import "DACircularProgressView.h"

@interface ViewController () <NSURLConnectionDelegate>
@property (weak, nonatomic) IBOutlet UIProgressView *progressView;
@property (nonatomic, strong) NSMutableData *fileData;

@property (nonatomic, assign) long long totalLength;
@property (weak, nonatomic) DACircularProgressView *circleView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    DACircularProgressView *circleView = [[DACircularProgressView alloc] init];
    circleView.frame = CGRectMake(100, 50, 100, 100);
    circleView.progressTintColor = [UIColor redColor];
    circleView.trackTintColor = [UIColor blueColor];
    circleView.progress = 0.01;
    [self.view addSubview:circleView];
    self.circleView = circleView;
    
}

- (void)download
{
    NSURL *url = [NSURL URLWithString:@"http://localhost:8080/MJServer/resources/videos.zip"];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [NSURLConnection connectionWithRequest:request delegate:self];
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self download];
}


#pragma mark - NSURLConnectionDelegate
/**
 *  1.接收到服务器的响应就会调用
 *
 *  @param response   响应
 */
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    self.fileData = [NSMutableData data];
    
    self.totalLength = response.expectedContentLength;
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [self.fileData appendData:data];
    self.progressView.progress  = (double)self.fileData.length / self.totalLength;
    self.circleView.progress = (double)self.fileData.length / self.totalLength;
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSString *cache = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject];
    
    NSString *file = [cache stringByAppendingPathComponent:@"videos.zip"];
    
    [self.fileData writeToFile:file atomically:YES];
}


@end
