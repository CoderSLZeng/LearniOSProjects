//
//  ViewController.m
//  03-小文件下载（了解）
//
//  Created by Anthony on 16/1/11.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 下载小文件的方式
    // 1.NSData dataWithContentsOfURL
    // 2.NSURLConnection
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self downloadFile];
//    [self downloadFile2];
}

// 1.NSData dataWithContentsOfURL
- (void)downloadFile
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSURL *url = [NSURL URLWithString:@"http://localhost:8080/MJServer/resources/images/minion_01.png"];
        NSData *data = [NSData dataWithContentsOfURL:url];
        NSLog(@"%ld", data.length);
    });
}

// 2.NSURLConnection
- (void)downloadFile2
{
    NSURL *url = [NSURL URLWithString:@"http://localhost:8080/MJServer/resources/images/minion_01.png"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse * _Nullable response, NSData * _Nullable data, NSError * _Nullable connectionError) {
        NSLog(@"%ld", data.length);
    }];
    
}

@end
