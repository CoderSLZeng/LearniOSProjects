//
//  HMNetworkTool.h
//  02-网络状态监测（掌握）
//
//  Created by Anthony on 16/1/11.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HMNetworkTool : NSObject

/**
 *  是否
 */
+ (BOOL)isEnableWIFI;

/**
 *  是否
 */
+ (BOOL)isEnable3G;



@end
