//
//  ViewController.m
//  02-网络状态监测（掌握）
//
//  Created by Anthony on 16/1/11.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import "Reachability.h"
#import "HMNetworkTool.h"

@interface ViewController ()
@property (nonatomic, strong) Reachability *reachability;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 监听网络状态发送改变的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(networkStateChange) name:kReachabilityChangedNotification object:nil];
    
    // 获得Reachability对象
    self.reachability = [Reachability reachabilityForInternetConnection];
    
    // 开始监控网络
    [self.reachability startNotifier];

}

- (void)dealloc
{
    [self.reachability stopNotifier];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
}

- (void)networkStateChange
{
    NSLog(@"网络状态改变了");
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self checkNetworkState];
}

- (void)checkNetworkState
{
    if ([HMNetworkTool isEnableWIFI]) {
        NSLog(@"WIFI环境");
    } else if ([HMNetworkTool isEnable3G]) {
        NSLog(@"手机自带网络");
    } else {
        NSLog(@"没有网络");
    }
}

@end
