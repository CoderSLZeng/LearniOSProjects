//
//  ViewController.m
//  06-AFN01-基本使用（掌握）
//
//  Created by Anthony on 16/1/11.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self postJSON];
}


- (void)getSession
{
    AFHTTPSessionManager *mgr = [AFHTTPSessionManager manager];
    [mgr GET:@"" parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        
    }];
}

/**
 *  利用AFN发送一个POST请求，服务器返回的JSON数据
 */
- (void)postJSON
{
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"username"] = @"哈哈哈";
    params[@"pwd"] = @"123";
    
    NSString *url = @"http://localhost:8080/MJServer/login";
    [mgr POST:url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"请求成功----%@", responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"请求失败");
    }];

}


/**
 *  利用AFN发送一个GET请求，服务器返回的JSON数据，让AFN直接返回data
 */
- (void)getData
{
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    mgr.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"username"] = @"哈哈哈";
    params[@"pwd"] = @"123";
    
    NSString *url = @"http://localhost:8080/MJServer/login";
    [mgr GET:url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        NSLog(@"%@", dict);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"请求失败");
    }];
}


/**
 *  利用AFN发送一个GET请求，服务器返回的XML数据
 */
- (void)getXML
{
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    mgr.responseSerializer = [AFXMLParserResponseSerializer serializer];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"username"] = @"哈哈哈";
    params[@"pwd"] = @"123";
    params[@"type"] = @"XML";
    
    NSString *url = @"http://localhost:8080/MJServer/login";
    [mgr GET:url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"请求成功---%@", responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"请求失败");
    }];
}

/**
 *  利用AFN发送一个GET请求，服务器返回的JSON数据
 */
- (void)getJSON
{
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
//    mgr.responseSerializer = [AFJSONRequestSerializer serializer];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"username"] = @"哈哈哈";
    params[@"pwd"] = @"123";
    
    NSString *url = @"http://localhost:8080/MJServer/login";
    [mgr GET:url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"请求成功---%@", responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"请求失败");
    }];
    
}





@end
