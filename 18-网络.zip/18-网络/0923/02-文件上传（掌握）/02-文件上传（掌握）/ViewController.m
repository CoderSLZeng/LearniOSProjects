//
//  ViewController.m
//  02-文件上传（掌握）
//
//  Created by Anthony on 16/1/11.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#define HMFileBoundary @"heima"
#define HMNewLine @"\r\n"
#define HMEncode(str) [str dataUsingEncoding:NSUTF8StringEncoding]

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    
}

- (void)upload
{
    NSURL *url = [NSURL URLWithString:@"http://localhost:8080/MJServer/upload"];
    
    NSMutableURLRequest *requestM = [NSMutableURLRequest requestWithURL:url];
    requestM.HTTPMethod = @"POST";
    
    NSMutableData *body = [NSMutableData data];
    
    [body appendData:HMEncode(@"--")];
    [body appendData:HMEncode(HMFileBoundary)];
    [body appendData:HMEncode(HMNewLine)];
    
    [body appendData:HMEncode(@"Content-Disposition: form-data; name=\"file\"; filename=\"test123.png\"")];
    [body appendData:HMEncode(HMNewLine)];
    
    [body appendData:HMEncode(@"Content-Type: image/png")];
    [body appendData:HMEncode(HMNewLine)];
    
    [body appendData:HMEncode(HMNewLine)];
    UIImage *image = [UIImage imageNamed:@"minion_03"];
    NSData *imageData = UIImagePNGRepresentation(image);
    [body appendData:imageData];
    [body appendData:HMEncode(HMNewLine)];
    
    // 3.2.用户名参数
    [body appendData:HMEncode(@"--")];
    [body appendData:HMEncode(HMFileBoundary)];
    [body appendData:HMEncode(HMNewLine)];
    
    [body appendData:HMEncode(@"Content-Disposition: form-data; name=\"username\"")];
    [body appendData:HMEncode(HMNewLine)];
    
    [body appendData:HMEncode(HMNewLine)];
    [body appendData:HMEncode(@"张三")];
    [body appendData:HMEncode(HMNewLine)];
    
    // 3.3.结束标记
    [body appendData:HMEncode(@"--")];
    [body appendData:HMEncode(HMFileBoundary)];
    [body appendData:HMEncode(@"--")];
    [body appendData:HMEncode(HMNewLine)];
    
    requestM.HTTPBody = body;
    
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", HMFileBoundary];
    [requestM setValue:contentType forHTTPHeaderField:@"Content-Type"];
    
    [NSURLConnection sendAsynchronousRequest:requestM queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse * _Nullable response, NSData * _Nullable data, NSError * _Nullable connectionError) {
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        NSLog(@"%@", dict);
    }];
}

@end
