//
//  ViewController.m
//  02-文件上传（掌握）
//
//  Created by Anthony on 16/1/11.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#define HMFileBoundary @"heima"
#define HMNewLine @"\r\n"
#define HMEncode(str) [str dataUsingEncoding:NSUTF8StringEncoding]

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *name = @"jack";
    
    [self test:&name];
}

- (void)test:(NSString **)str
{
    *str = @"rose";
}

- (NSString *)MIMEType:(NSURL *)url
{
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    NSURLResponse *response = nil;
    [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];
    return response.MIMEType;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    
}

- (void)upload
{
    NSDictionary *params = @{
                             @"username" : @"李四",
                             @"pwd" : @"123",
                             @"age" : @30,
                             @"height" : @"1.55"
                             };
    NSURL *url = [[NSBundle mainBundle] URLForResource:@"autolayout" withExtension:@"txt"];
    NSData *data = [NSData dataWithContentsOfURL:url];
    NSString *MIMEType = [self MIMEType:url];
    [self upload:@"text.txt" mineType:MIMEType fileData:data params:params];
}

- (void)upload:(NSString *)filename mineType:(NSString *)mineType fileData:(NSData *)fileData params:(NSDictionary *)params
{
    NSURL *url = [NSURL URLWithString:@"http://localhost:8080/MJServer/upload"];
    
    NSMutableURLRequest *requestM = [NSMutableURLRequest requestWithURL:url];
    requestM.HTTPMethod = @"POST";
    
    NSMutableData *body = [NSMutableData data];
    
    [body appendData:HMEncode(@"--")];
    [body appendData:HMEncode(HMFileBoundary)];
    [body appendData:HMEncode(HMNewLine)];
    
//    [body appendData:HMEncode(@"Content-Disposition: form-data; name=\"file\"; filename=\"test123.png\"")];
    NSString *disposition = [NSString stringWithFormat:@"Content-Disposition: form-data; name=\"file\"; filename=\"%@\"", filename];
    [body appendData:HMEncode(disposition)];
    [body appendData:HMEncode(HMNewLine)];
    
//    [body appendData:HMEncode(@"Content-Type: image/png")];
    NSString *type = [NSString stringWithFormat:@"Content-Type: %@", mineType];
    [body appendData:HMEncode(type)];
    [body appendData:HMEncode(HMNewLine)];
    
    [body appendData:HMEncode(HMNewLine)];
//    UIImage *image = [UIImage imageNamed:@"minion_03"];
//    NSData *imageData = UIImagePNGRepresentation(image);
//    [body appendData:imageData];
    [body appendData:fileData];
    [body appendData:HMEncode(HMNewLine)];
    
    // 3.2.用户名参数
    [params enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        
        [body appendData:HMEncode(@"--")];
        [body appendData:HMEncode(HMFileBoundary)];
        [body appendData:HMEncode(HMNewLine)];
        
//        [body appendData:HMEncode(@"Content-Disposition: form-data; name=\"username\"")];
        NSString *dispositiong = [NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@", key];
        [body appendData:HMEncode(disposition)];
        [body appendData:HMEncode(HMNewLine)];
        
        [body appendData:HMEncode(HMNewLine)];
//        [body appendData:HMEncode(@"张三")];
        [body appendData:HMEncode([obj description])];
        [body appendData:HMEncode(HMNewLine)];
    }];
    
    
    // 3.3.结束标记
    [body appendData:HMEncode(@"--")];
    [body appendData:HMEncode(HMFileBoundary)];
    [body appendData:HMEncode(@"--")];
    [body appendData:HMEncode(HMNewLine)];
    
    requestM.HTTPBody = body;
    
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", HMFileBoundary];
    [requestM setValue:contentType forHTTPHeaderField:@"Content-Type"];
    
    [NSURLConnection sendAsynchronousRequest:requestM queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse * _Nullable response, NSData * _Nullable data, NSError * _Nullable connectionError) {
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        NSLog(@"%@", dict);
    }];

}

@end
