//
//  HMApp.h
//  05-黑酷-NSXMLparser（掌握）
//
//  Created by Anthony on 16/1/8.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HMVideo : NSObject
/**
 *  ID
 */
@property (nonatomic, assign) int id;
/**
 *  时长
 */
@property (nonatomic, assign) int length;
/**
 *  图片（视频截图）
 */
@property (nonatomic, copy) NSString *image;
/**
 *  视频名字
 */
@property (nonatomic, copy) NSString *name;
/**
 *  视频的播放路径
 */
@property (nonatomic, copy) NSString *url;

- (instancetype)initWithDict:(NSDictionary *)dict;

+ (instancetype)videoWithDict:(NSDictionary *)dict;

@end
