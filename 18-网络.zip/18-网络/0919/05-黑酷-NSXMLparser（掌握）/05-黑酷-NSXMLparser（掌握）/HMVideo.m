
//
//  HMApp.m
//  05-黑酷-NSXMLparser（掌握）
//
//  Created by Anthony on 16/1/8.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "HMVideo.h"

@implementation HMVideo

- (instancetype)initWithDict:(NSDictionary *)dict
{
    
    self = [super init];
    if (self) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+ (instancetype)videoWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}

@end
