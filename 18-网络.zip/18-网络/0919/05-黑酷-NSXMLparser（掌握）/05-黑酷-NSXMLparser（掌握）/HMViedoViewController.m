//
//  HMViedoViewController.m
//  05-黑酷-NSXMLparser（掌握）
//
//  Created by Anthony on 16/1/8.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "HMViedoViewController.h"
#import "HMVideo.h"
#import "MBProgressHUD+MJ.h"
#import "UIImageView+WebCache.h"
#import <MediaPlayer/MediaPlayer.h>

#define HMUrl(path) [NSURL URLWithString:[NSString stringWithFormat:@"http://localhost:8080/MJServer/%@", path]]

@interface HMViedoViewController () <NSXMLParserDelegate>

@property (nonatomic, strong) NSMutableArray *videos;

@end

@implementation HMViedoViewController

#pragma mark - 懒加载
- (NSMutableArray *)videos
{
    if (!_videos) {
        self.videos = [[NSMutableArray alloc] init];
    }
    return _videos;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 1.创建url
    NSURL *url = HMUrl(@"video?type=XML");
    // 2.创建请求
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    // 3.发送请求
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse * _Nullable response, NSData * _Nullable data, NSError * _Nullable connectionError) {
        if (connectionError || data == nil) {
            [MBProgressHUD showError:@"网络繁忙，请稍后再试"];
            return;
        }
        
        // 解析XML数据
        // 1.创建XML解析器 -- SAX -- 逐个元素往下解析
        NSXMLParser *parser = [[NSXMLParser alloc] initWithData:data];
        
        // 2.设置代理
        parser.delegate = self;
        
        // 3.开始解析（同步执行）
        [parser parse];
        
        // 4.刷新数据
        [self.tableView reloadData];
        
    }];
    
}

#pragma mark - NSXMLParse的代理方法
/**
 *  解析到文档的开头时会调用
 */
- (void)parserDidStartDocument:(NSXMLParser *)parser
{
    NSLog(@"parserDidStartDocument");
}

/**
 *  解析到一个元素的开始就会调用
 *  @param elementName   元素名称
 *  @param attributeDict 属性字典
 */
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary<NSString *,NSString *> *)attributeDict
{
    if ([@"videos" isEqualToString:elementName]) return;
    
    HMVideo *video = [HMVideo videoWithDict:attributeDict];
    [self.videos addObject:video];
}

/**
 *  解析到一个元素的结束就会调用
 *  @param elementName  元素名称
 */
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    NSLog(@"parsedidEndElement---");
}

/**
 * 解析到文档的结尾时会调用（解析结束）
 */
- (void)parserDidEndDocument:(NSXMLParser *)parser
{
    NSLog(@"parserDidEndDocument");
}


#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
#warning Incomplete implementation, return the number of rows
    return self.videos.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"video";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identifier];
    }
    
    // 1.取出模型
    HMVideo *video = self.videos[indexPath.row];
    
    // 2.设置基本信息
    cell.textLabel.text = video.name;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"时长：%d 分钟", video.length];
    
    // 3. 显示视频截图
    [cell.imageView sd_setImageWithURL:HMUrl(video.image) placeholderImage:[UIImage imageNamed:@"placehoder"]];
    
    return cell;
}

#pragma mark - 数据源代理方法
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 1.取出对应的视频模型
    HMVideo *video = self.videos[indexPath.row];
    
    // 2.创建系统自带的视频播放控制器
    MPMoviePlayerViewController *playerVc = [[MPMoviePlayerViewController alloc] initWithContentURL:HMUrl(video.url)];
    
    // 3.显示播放
    [self presentViewController:playerVc animated:YES completion:nil];
}

@end
