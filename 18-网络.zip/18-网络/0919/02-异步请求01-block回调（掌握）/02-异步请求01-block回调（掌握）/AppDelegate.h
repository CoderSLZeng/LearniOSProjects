//
//  AppDelegate.h
//  02-异步请求01-block回调（掌握）
//
//  Created by Anthony on 16/1/7.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

