//
//  ViewController.m
//  06-POST请求（掌握）
//
//  Created by Anthony on 16/1/8.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import "MBProgressHUD+MJ.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *username;
@property (weak, nonatomic) IBOutlet UITextField *pwd;
- (IBAction)login;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)login {
    
    // 1.用户名
    NSString *usernameText = self.username.text;
    if (0 == usernameText.length) {
        [MBProgressHUD showError:@"请输入用户名"];
    }
    
    // 2.密码
    NSString *pwdText = self.pwd.text;
    if (0 == pwdText.length) {
        [MBProgressHUD showError:@"请输入密码"];
    }
    
    // 3.增加蒙版
    [MBProgressHUD showMessage:@"正在拼命登录中..."];
    
    // 4.发送给服务器
    // 4.1创建一个URL
    NSURL *url = [NSURL URLWithString:@"http://localhost:8080/MJServer/login"];
    // 4.2创建一个请求
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    
    // 4.3 5秒后算请求超市
    request.timeoutInterval = 15;
    
    request.HTTPMethod = @"POST";
    
    // 设置请求体
    NSString *param = [NSString stringWithFormat:@"username=%@&pwd=%@", usernameText, pwdText];
    request.HTTPBody = [param dataUsingEncoding:NSUTF8StringEncoding];
    
    // 设置请求头信息
    [request setValue:@"iPhone 6s Plus" forHTTPHeaderField:@"User-Agent"];
    
    // 发送一个同步请求
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse * _Nullable response, NSData * _Nullable data, NSError * _Nullable connectionError) {
        // 隐藏蒙版
        [MBProgressHUD hideHUD];
        
        // 这个block会在请求完毕的时候自动调用
        if (connectionError || data == nil) {
            [MBProgressHUD showError:@"请求失败"];
            return;
        }
        
        // 解析服务器返回的JSON数据
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        NSString *error = dict[@"error"];
        if (error) {
            [MBProgressHUD showError:error];
        } else {
            NSString *success = dict[@"success"];
            [MBProgressHUD showSuccess:success];
        }
    }];
}
@end
