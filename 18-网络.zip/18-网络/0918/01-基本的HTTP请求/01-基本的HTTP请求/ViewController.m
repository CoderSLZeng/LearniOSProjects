//
//  ViewController.m
//  01-基本的HTTP请求
//
//  Created by Anthony on 16/1/6.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "ViewController.h"
#import "MBProgressHUD+MJ.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *username;
@property (weak, nonatomic) IBOutlet UITextField *pwd;

- (IBAction)login;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)login {
    // 1.用户名
    NSString *usernameText = self.username.text;
    if (usernameText.length == 0) {
        [MBProgressHUD showError:@"请输入用户名"];
        return;
    }
    
    // 2.密码
    NSString *pwdText = self.pwd.text;
    if (pwdText.length == 0) {
        [MBProgressHUD showError:@"请输入密码"];
    }
    
    // 3.发生用户名和密码给服务器（走HTTP协议）
    // 3.1创建一个URL：请求路径
    NSString *urlStr = [NSString stringWithFormat:@"http://localhost:8080/MJServer/login?username=%@&pwd=%@", usernameText, pwdText];
    NSURL *url = [NSURL URLWithString:urlStr];
    
    // 3.2创建一个请求
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    // 3.3发送一个同步请求（在主线程发送请求）
    NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    
    NSLog(@"%@", data);
}
@end
