//
//  HMApp.h
//  01-cell图片下载（了解）
//
//  Created by Anthony on 16/1/6.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HMApp : NSObject

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *download;
@property (nonatomic, copy) NSString *icon;

- (instancetype)initWithDict:(NSDictionary *)dict;

+ (instancetype)appWithDict:(NSDictionary *)dict;
@end
