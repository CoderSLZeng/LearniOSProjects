//
//  HMApp.m
//  01-cell图片下载（了解）
//
//  Created by Anthony on 16/1/6.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "HMApp.h"

@implementation HMApp

- (instancetype)initWithDict:(NSDictionary *)dict
{
    
    self = [super init];
    if (self) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+ (instancetype)appWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}

@end
