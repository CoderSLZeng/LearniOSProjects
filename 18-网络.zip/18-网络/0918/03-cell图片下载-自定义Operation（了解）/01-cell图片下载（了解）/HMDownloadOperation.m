//
//  HMDownloadOperation.m
//  01-cell图片下载（了解）
//
//  Created by Anthony on 16/1/7.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import "HMDownloadOperation.h"

@implementation HMDownloadOperation
- (void)mian
{
    if (self.isCancelled) return;
    
    NSURL *url = [NSURL URLWithString:self.imageUrl];
    NSData *data = [NSData dataWithContentsOfURL:url];
    UIImage *image = [UIImage imageWithData:data];

    if (self.isCancelled) return;
    
    [[NSOperationQueue mainQueue] addOperationWithBlock:^{
        if ([self.delegate respondsToSelector:@selector(downloadOperation:didFinishDownload:)]) {
            [self.delegate downloadOperation:self didFinishDownload:image];
        }
    }];
    
}
@end
