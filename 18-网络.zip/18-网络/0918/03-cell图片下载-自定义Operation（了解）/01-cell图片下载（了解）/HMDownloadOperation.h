//
//  HMDownloadOperation.h
//  01-cell图片下载（了解）
//
//  Created by Anthony on 16/1/7.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class HMDownloadOperation;

@protocol HMDownloadOperationDelegate <NSObject>

@optional
- (void)downloadOperation:(HMDownloadOperation *)operation didFinishDownload:(UIImage *)image;

@end

@interface HMDownloadOperation : NSOperation
@property (nonatomic, copy) NSString *imageUrl;
@property (nonatomic, strong) NSIndexPath *indexPath;
@property (weak, nonatomic) id<HMDownloadOperationDelegate> delegate;

@end
