//
//  NJView.m
//  03-图形上下文栈
//
//  Created by Luffy on 15/9/5.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJView.h"

@implementation NJView


- (void)drawRect:(CGRect)rect {

    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    CGContextSaveGState(ctx);
    
    CGContextMoveToPoint(ctx, 50, 50);
    CGContextAddLineToPoint(ctx, 100, 50);
    
    CGContextSetLineWidth(ctx, 10);
    CGContextSetLineCap(ctx, kCGLineCapRound);
    
    CGContextSaveGState(ctx);
    
    [[UIColor redColor] set];
    
    CGContextStrokePath(ctx);
    
    CGContextRestoreGState(ctx);
    
    CGContextMoveToPoint(ctx, 150, 100);
    
    CGContextAddLineToPoint(ctx, 250, 200);
    
    CGContextStrokePath(ctx);
    
    CGContextRestoreGState(ctx);
    
    CGContextMoveToPoint(ctx, 200, 200);
    CGContextAddLineToPoint(ctx, 200, 300);
    
    CGContextStrokePath(ctx);
    
    
}


@end
