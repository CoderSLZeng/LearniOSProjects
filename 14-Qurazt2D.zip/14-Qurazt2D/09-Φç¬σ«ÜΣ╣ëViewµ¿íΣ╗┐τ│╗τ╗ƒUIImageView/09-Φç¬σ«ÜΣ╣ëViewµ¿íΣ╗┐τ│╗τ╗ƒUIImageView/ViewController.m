//
//  ViewController.m
//  09-自定义View模仿系统UIImageView
//
//  Created by Luffy on 15/9/6.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "NJImageView.h"


@interface ViewController ()

@property (weak, nonatomic) UIImageView *imageView;
@property (weak, nonatomic) NJImageView *njIV;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /*
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(100, 150, 100, 100)];
    imageView.image = [UIImage imageNamed:@"me"];
    [self.view addSubview:imageView];
    */
    
    NJImageView *njIV = [[NJImageView alloc] init];
    njIV.frame = CGRectMake(100, 100, 100, 100);
    njIV.image = [UIImage imageNamed:@"me"];
    [self.view addSubview:njIV];
    self.njIV = njIV;
    
    
    
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(50, 30, 150, 44)];
    [btn setTitle:@"点击切换图片" forState:UIControlStateNormal];
    [btn setTitle:@"已经切换图片" forState:UIControlStateHighlighted];
    btn.backgroundColor = [UIColor redColor];
    [self.view addSubview:btn];
    [btn addTarget:self action:@selector(btnOnClick) forControlEvents:UIControlEventTouchUpInside];
    
}


- (void)btnOnClick {
    
    NSLog(@"%s", __func__);
    
    UIImage *image = [UIImage imageNamed:@"psb.jpeg"];
//    self.imageView.image = image;
    
    self.njIV.image = image;
}


@end
