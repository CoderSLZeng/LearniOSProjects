//
//  NJImageView.m
//  09-自定义View模仿系统UIImageView
//
//  Created by Luffy on 15/9/6.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJImageView.h"

@implementation NJImageView


- (void)drawRect:(CGRect)rect {
    // Drawing code
    
    [self.image drawInRect:rect];
}

- (void)setImage:(UIImage *)image
{
    _image = image;
    
    [self setNeedsDisplay];
    
}


@end
