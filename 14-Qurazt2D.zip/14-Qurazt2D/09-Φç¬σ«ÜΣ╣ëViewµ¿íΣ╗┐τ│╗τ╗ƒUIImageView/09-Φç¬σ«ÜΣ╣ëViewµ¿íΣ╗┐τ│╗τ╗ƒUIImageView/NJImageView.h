//
//  NJImageView.h
//  09-自定义View模仿系统UIImageView
//
//  Created by Luffy on 15/9/6.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NJImageView : UIView

@property (nonatomic, strong) UIImage *image;

@end
