//
//  NJView.m
//  14-view拖拽
//
//  Created by Luffy on 15/9/7.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJView.h"

@implementation NJView

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
      NSLog(@"%s", __func__);
    
//    [event allTouches] == touches;
    
//    NSSet *set = @[@"1", @"2", @"3"];
    
//    UITouch *touch = [touches anyObject];
//    NSLog(@"%p", touch);
    
//    CGPoint point = [touch locationInView:self];
//    CGPoint point = [touch locationInView:self.superview];
//    NSLog(@"%@", NSStringFromCGPoint(point));
    
//    NSLog(@"tapCount = %d", touch.tapCount);
    
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"%s", __func__);
    
    UITouch *touch = [touches anyObject];
    CGPoint prePoint = [touch previousLocationInView:self];
    NSLog(@"prePoint = %@", NSStringFromCGPoint(prePoint));
    
    CGPoint currentPoit = [touch locationInView:self];
    NSLog(@"currentPoint = %@", NSStringFromCGPoint(currentPoit));
    
    CGFloat moveX = currentPoit.x - prePoint.x;
    CGFloat moveY = currentPoit.y - prePoint.y;
    NSLog(@"moveX = %.1f, moveY = %.1f", moveX, moveY);
    
    CGPoint temp = self.center;
    temp.x += moveX;
    temp.y += moveY;
    self.center = temp;
    
}


- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"%s", __func__);
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"%s", __func__);
}
@end
