//
//  NJView.m
//  04-矩阵操作
//
//  Created by Luffy on 15/9/6.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJView.h"

@implementation NJView

- (void)drawRect:(CGRect)rect
{
    CGContextRef ctx = UIGraphicsGetCurrentContext();

//    CGContextRotateCTM(ctx, M_PI_4); // 旋转
//    CGContextScaleCTM(ctx, 0.5, 0.5); // 缩放
    CGContextTranslateCTM(ctx, 0, 150); // 偏移
    
    CGContextAddEllipseInRect(ctx, CGRectMake(20, 20, 100, 100));
    
    CGContextAddRect(ctx, CGRectMake(150, 20, 150, 150));
    
    CGContextStrokePath(ctx);
}

@end
