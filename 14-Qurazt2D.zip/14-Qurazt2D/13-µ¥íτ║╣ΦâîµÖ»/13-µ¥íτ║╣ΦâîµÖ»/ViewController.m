//
//  ViewController.m
//  13-条纹背景
//
//  Created by Luffy on 15/9/7.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UITextView *contentView;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@property (nonatomic, assign) int index;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    [self test];
    [self test1];
}

- (void)test1
{
    CGFloat height = 44;
    CGSize size = CGSizeMake(self.view.frame.size.width, height);
    UIGraphicsBeginImageContextWithOptions(size, NO, 0);
    
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextAddRect(ctx, CGRectMake(0, 0, self.view.frame.size.width, height));
    [[UIColor redColor] set];
    CGContextFillPath(ctx);
    
    CGFloat lineWidth = 2;
    CGFloat lineY = height - lineWidth;
    CGContextMoveToPoint(ctx, 0, lineY);
    CGContextAddLineToPoint(ctx, 320, lineY);
    [[UIColor blackColor] set];
    CGContextStrokePath(ctx);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIColor *myColor = [UIColor colorWithPatternImage:image];
    self.contentView.backgroundColor = myColor;
}

- (void)test
{
    CGFloat height = 44;
    CGSize size = CGSizeMake(self.view.frame.size.width, height);
    UIGraphicsBeginImageContextWithOptions(size, NO, 0);
    
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextAddRect(ctx, CGRectMake(0, 0, self.view.frame.size.width, height));
    [[UIColor redColor] set];
    CGContextFillPath(ctx);
    
    CGFloat lineWidth = 2;
    CGFloat lineY = height - lineWidth;
    CGFloat lineX = 0;
    CGContextMoveToPoint(ctx, lineX, lineY);
    CGContextAddLineToPoint(ctx, 320, lineY);
    [[UIColor blackColor] set];
    CGContextStrokePath(ctx);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
 /*
   self.imageView.image = image;
    
    NSData *data = UIImagePNGRepresentation(image);
    
    NSString *path = [[NSSearchPathForDirectoriesInDomains(NSDocumentationDirectory, NSUserDomainMask, YES) lastObject]stringByAppendingPathComponent:@"aaa.png"];
    NSLog(@"%@", path);
    [data writeToFile:path atomically:YES];
//    [data writeToFile:@"/Users/Luffy/Desktop/aaa.png" atomically:YES];
  */
    
    UIColor *myColor = [UIColor colorWithPatternImage:image];
    self.view.backgroundColor = myColor;
}

- (IBAction)preBtnOnClick:(UIButton *)sender {
    self.index--;
    
    self.contentView.text = [NSString stringWithFormat:@"第%d页", self.index];
    CATransition *ca = [[CATransition alloc] init];
    ca.type = @"pageCurl";
    
    [self.contentView.layer addAnimation:ca forKey:nil];
    
    
}
- (IBAction)nextBtnOnClick:(UIButton *)sender {
    self.index++;
    self.contentView.text = [NSString stringWithFormat:@"第%d页", self.index];
    
    CATransition *ca = [[CATransition alloc] init];
    ca.type = @"pageCurl";
    
    [self.contentView.layer addAnimation:ca forKey:nil];
    
}

@end
