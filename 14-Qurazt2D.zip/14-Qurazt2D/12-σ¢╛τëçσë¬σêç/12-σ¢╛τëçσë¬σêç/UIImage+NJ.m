//
//  UIImage+NJ.m
//  12-图片剪切
//
//  Created by Luffy on 15/9/6.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "UIImage+NJ.h"

@implementation UIImage (NJ)

+ (instancetype)imageWithIcon:(NSString *)icon border:(NSInteger)border color:(UIColor *)color
{
    UIImage *image = [UIImage imageNamed:icon];
    
    CGFloat margin = border;
    CGSize size = CGSizeMake(image.size.width + margin, image.size.height + margin);
    
    UIGraphicsBeginImageContextWithOptions(size, NO, 0);
    
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    [color set];
    CGContextFillEllipseInRect(ctx, CGRectMake(0, 0, size.width, size.height));
    
    CGFloat smallX = margin * 0.5;
    CGFloat smallY = margin * 0.5;
    CGFloat smallW = image.size.width;
    CGFloat smallH = image.size.height;
    CGContextAddEllipseInRect(ctx, CGRectMake(smallX, smallY, smallW, smallH));
    CGContextClip(ctx);
    
    [image drawInRect:CGRectMake(smallX, smallY, smallW, smallH)];
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    return newImage;
}

@end
