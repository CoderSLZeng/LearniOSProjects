//
//  ViewController.m
//  12-图片剪切
//
//  Created by Luffy on 15/9/6.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "UIImage+NJ.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    [self test];
//    [self test1];
    [self test2];
}

- (void)test2
{
    UIImage *image = [UIImage imageWithIcon:@"me" border:50 color:[UIColor greenColor]];
    self.imageView.image = image;
}

- (void)test1
{
    UIImage *image = [UIImage imageNamed:@"me"];
    
    CGFloat margin = 10;
    CGSize size = CGSizeMake(image.size.width + margin, image.size.height + margin);
    
    UIGraphicsBeginImageContextWithOptions(size, NO, 0);
    
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    [[UIColor whiteColor] set];
    CGContextFillEllipseInRect(ctx, CGRectMake(0, 0, size.width, size.height));

    CGFloat smallX = margin * 0.5;
    CGFloat smallY = margin * 0.5;
    CGFloat smallW = image.size.width;
    CGFloat smallH = image.size.height;
//    [[UIColor blackColor] set];
//    CGContextFillEllipseInRect(ctx, CGRectMake(smallX, smallY, smallW, smallH));
    CGContextAddEllipseInRect(ctx, CGRectMake(smallX, smallY, smallW, smallH));
    
    CGContextClip(ctx);
    
    [image drawInRect:CGRectMake(smallX, smallY, smallW, smallH)];
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    self.imageView.image = newImage;
    NSData *data = UIImagePNGRepresentation(newImage);
    
    NSString *path = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"cba.png"];
    
    NSLog(@"%@", path);
    
    [data writeToFile:path atomically:YES];
    
    

}



- (void)test
{
    UIImage *image = [UIImage imageNamed:@"me"];
    
    UIGraphicsBeginImageContextWithOptions(image.size, NO, 0);
    
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    CGMutablePathRef path = CGPathCreateMutable();
    
    CGPathAddEllipseInRect(path, NULL, CGRectMake(0, 0, image.size.width, image.size.height));
    
    CGContextAddPath(ctx, path);
    CFRelease(path);
    
    CGContextClip(ctx);
    
    [image drawInRect:CGRectMake(0, 0, image.size.width, image.size.height)];
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    self.imageView.image = newImage;
    
    NSData *data = UIImagePNGRepresentation(newImage);
    
   NSString *path2 = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"abc.png"];
    
    [data writeToFile:path2 atomically:YES];
    
    
//    CGContextStrokePath(ctx);
    
    
}

@end
