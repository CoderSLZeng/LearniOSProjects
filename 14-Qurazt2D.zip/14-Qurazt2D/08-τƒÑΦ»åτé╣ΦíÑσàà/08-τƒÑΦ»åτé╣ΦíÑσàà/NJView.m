//
//  NJView.m
//  08-知识点补充
//
//  Created by Luffy on 15/9/6.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJView.h"

@implementation NJView

- (void)drawRect:(CGRect)rect
{
    
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    // 画四边形
    // 第一种
    CGMutablePathRef path = CGPathCreateMutable();
    
    CGPathMoveToPoint(path, NULL, 20, 20);
    CGPathAddLineToPoint(path, NULL, 50, 20);
    CGPathAddLineToPoint(path, NULL, 50, 50);
    CGPathAddLineToPoint(path, NULL, 20, 50);
    CGPathCloseSubpath(path);
    
    CGContextAddPath(ctx, path);
    
    CGContextStrokePath(ctx);
    
//    CGPathRelease(path);
    CFRelease(path);
    
    // 第二种
    CGMutablePathRef path2 = CGPathCreateMutable();
    
    CGPathAddRect(path2, NULL, CGRectMake(60, 20, 20, 30));
    
    [[UIColor redColor] set];
    
    CGContextAddPath(ctx, path2);
    
    CGContextStrokePath(ctx);
    
    CFRelease(path2);
    
    // 第三种
//    CGContextClearRect(ctx, rect);
    [[UIColor greenColor] set];
    CGContextStrokeRect(ctx, CGRectMake(90, 20, 30, 20));
    [[UIColor yellowColor] set];
    CGContextFillRect(ctx, CGRectMake(130, 20, 20, 30));
    
    // 第四种，只有Fill方法，没有stroke方法
    [[UIColor blueColor] set];
    UIRectFill(CGRectMake(160, 20, 20, 30));
    
    // 第五种，通过绘制线条设置宽度
    CGMutablePathRef path3 = CGPathCreateMutable();
    
    CGPathMoveToPoint(path3, NULL, 200, 20);
    CGPathAddLineToPoint(path3, NULL, 220, 50);
    CGContextAddPath(ctx, path3);
    
    CGContextSetLineWidth(ctx, 20);
    [[UIColor grayColor] set];
    CGContextStrokePath(ctx);
    
    CGPathRelease(path3);
    
    
}

@end
