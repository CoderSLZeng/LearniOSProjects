//
//  NJTextImageView.m
//  01-绘制基本图形
//
//  Created by Luffy on 15/9/5.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJTextImageView.h"

@implementation NJTextImageView

- (void)drawRect:(CGRect)rect
{
    [self text3];
}

- (void)text3 {
    
    UIImage *image = [UIImage imageNamed:@"bg"];
    
//    [image drawAtPoint:CGPointMake(0, 0)];
    
//    [image drawInRect:CGRectMake(0, 0, 200, 200)];
    
    [image drawAsPatternInRect:CGRectMake(0, 0, self.bounds.size.height, self.bounds.size.height)];
}

- (void)text2 {
    NSString *str = @"打i应予以哦哦哦全额确认全额外人热武器特委屈热武器记录机会更有意思V刹在打发额外无法大发发的很粗范德萨不热啊查找好好古也谈谈凤飞飞艾尔去哦哦个不能美女VB吗";
    
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    CGContextAddRect(ctx, CGRectMake(50, 50, 100, 300));
    
    CGContextStrokePath(ctx);
    
    NSMutableDictionary *dictM = [NSMutableDictionary dictionary];
    
    dictM[NSForegroundColorAttributeName] = [UIColor redColor];
    
    dictM[NSBackgroundColorAttributeName] = [UIColor greenColor];
    
    dictM[NSFontAttributeName] = [UIFont systemFontOfSize:20];
    
    [str drawInRect:CGRectMake(50, 50, 100, 300) withAttributes:dictM];
}

- (void)text {

    NSString *str = @"打i应予以哦哦哦全额确认全额外人热武器特委屈热武器记录机会更有意思V刹在打发额外无法大发发的很粗范德萨不热啊查找好好古也谈谈凤飞飞艾尔去哦哦个不能美女VB吗";
    
    [str drawInRect:CGRectMake(50, 50, 100, 100) withAttributes:nil];
//    [str drawAtPoint:CGPointMake(10, 10) withAttributes:nil];
}

@end
