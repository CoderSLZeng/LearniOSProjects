//
//  NJCircleView.m
//  01-绘制基本图形
//
//  Created by Luffy on 15/9/5.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJCircleView.h"

@implementation NJCircleView

- (void)drawRect:(CGRect)rect
{
    
    [self text4];
}

- (void)text4 {
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    CGContextAddArc(ctx, 100, 100, 50, 0, M_PI, 0);
    
    [[UIColor greenColor] set];
    
    CGContextFillPath(ctx);
    
}

- (void)text3 {
    CGContextRef cxt = UIGraphicsGetCurrentContext();
    
    CGContextAddArc(cxt, 100, 100, 50, M_PI_2, M_PI_4, 0);
    
    CGContextClosePath(cxt);
    
//    CGContextFillPath(cxt);
    CGContextStrokePath(cxt);
}

- (void)text2 {
    CGContextRef cxt = UIGraphicsGetCurrentContext();
    
    CGContextAddArc(cxt, 100, 100, 50, -M_PI_2, M_PI_2, 0);
    
    CGContextStrokePath(cxt);
}

- (void)text {
    CGContextRef cxt = UIGraphicsGetCurrentContext();
    
    CGContextAddEllipseInRect(cxt, CGRectMake(20, 20, 100, 100));
    
    [[UIColor redColor] set];
    
    CGContextStrokePath(cxt);
    
}

@end
