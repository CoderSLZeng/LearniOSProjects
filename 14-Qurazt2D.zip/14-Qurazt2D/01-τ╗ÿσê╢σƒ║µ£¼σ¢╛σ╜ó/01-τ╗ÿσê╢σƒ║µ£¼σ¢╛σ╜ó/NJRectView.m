//
//  NJRectView.m
//  01-绘制基本图形
//
//  Created by Luffy on 15/9/5.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJRectView.h"

@implementation NJRectView

- (void)drawRect:(CGRect)rect
{
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    CGContextAddRect(ctx, CGRectMake(50, 50, 150, 150));
    
//    CGContextSetRGBStrokeColor(ctx, 1.0, 0, 0, 1.0);
//    CGContextSetRGBFillColor(ctx, 1.0, 0, 0, 1.0);
    
//    [[UIColor purpleColor] setStroke];
    [[UIColor greenColor] setFill];
    
    CGContextStrokePath(ctx);
//    CGContextFillPath(ctx);
    
}


@end
