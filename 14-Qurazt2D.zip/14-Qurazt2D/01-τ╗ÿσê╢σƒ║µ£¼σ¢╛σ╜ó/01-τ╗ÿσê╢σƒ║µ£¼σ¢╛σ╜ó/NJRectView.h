//
//  NJRectView.h
//  01-绘制基本图形
//
//  Created by Luffy on 15/9/5.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NJRectView : UIView

@end
