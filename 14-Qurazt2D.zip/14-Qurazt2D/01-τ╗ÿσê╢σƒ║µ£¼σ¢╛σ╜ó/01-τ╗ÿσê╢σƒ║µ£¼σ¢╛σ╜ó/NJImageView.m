//
//  NJImageView.m
//  01-绘制基本图形
//
//  Created by Luffy on 15/9/5.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJImageView.h"

@implementation NJImageView

- (void)drawRect:(CGRect)rect
{
    UIImage *imag = [UIImage imageNamed:@"bg"];
    
    [imag drawAsPatternInRect:CGRectMake(0, 0, 320, 480)];
}

@end
