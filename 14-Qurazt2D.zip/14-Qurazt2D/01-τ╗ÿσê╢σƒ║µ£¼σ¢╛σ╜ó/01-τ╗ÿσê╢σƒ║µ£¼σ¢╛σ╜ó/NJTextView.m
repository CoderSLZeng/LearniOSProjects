//
//  NJTextView.m
//  01-绘制基本图形
//
//  Created by Luffy on 15/9/5.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJTextView.h"

@implementation NJTextView


- (void)drawRect:(CGRect)rect {
    
    
    NSString *str = @"王企鹅皮哦一样女款等我艾薇分请问咯哦";
    
    CGContextRef cxt = UIGraphicsGetCurrentContext();
    
    CGContextAddRect(cxt, CGRectMake(20, 20, 100, 100));
    
    CGContextStrokePath(cxt);
    
    NSMutableDictionary *dictM = [NSMutableDictionary dictionary];
    
    dictM[NSForegroundColorAttributeName] = [UIColor redColor];
    
    dictM[NSBackgroundColorAttributeName] = [UIColor greenColor];
    
    dictM[NSFontAttributeName] = [UIFont systemFontOfSize:20];
    
    [str drawInRect:CGRectMake(20, 20, 100, 100) withAttributes:dictM];

}



@end
