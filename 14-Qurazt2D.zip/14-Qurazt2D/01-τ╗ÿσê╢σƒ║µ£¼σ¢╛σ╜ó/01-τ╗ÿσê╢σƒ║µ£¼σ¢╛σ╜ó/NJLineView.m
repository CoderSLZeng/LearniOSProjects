//
//  NJLineView.m
//  01-绘制基本图形
//
//  Created by Luffy on 15/9/5.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJLineView.h"

@implementation NJLineView


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    CGContextMoveToPoint(ctx, 100, 100);
    
    CGContextAddLineToPoint(ctx, 100, 200);
    CGContextAddLineToPoint(ctx, 200, 150);
    
//    CGContextClosePath(ctx);
    
    CGContextSetRGBStrokeColor(ctx, 1.0, 0, 0, 1.0);
    
    CGContextSetLineWidth(ctx, 10);
    
    CGContextSetLineCap(ctx, kCGLineCapRound);
    
    CGContextSetLineJoin(ctx, kCGLineJoinRound);
    
    CGContextStrokePath(ctx);
    
    CGContextMoveToPoint(ctx, 200, 250);
    
    CGContextAddLineToPoint(ctx, 150, 100);
    
    [[UIColor greenColor] set];
    
    CGContextStrokePath(ctx);
}


@end
