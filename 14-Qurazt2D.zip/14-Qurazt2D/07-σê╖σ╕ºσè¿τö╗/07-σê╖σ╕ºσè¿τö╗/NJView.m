//
//  NJView.m
//  07-刷帧动画
//
//  Created by Luffy on 15/9/6.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJView.h"

@interface NJView ()

@property (nonatomic, assign) int imageY;

@end

@implementation NJView

- (void)awakeFromNib
{
      NSLog(@"%s", __func__);
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super init]) {
        NSLog(@"%s", __func__);;
        
//        [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(updataImage) userInfo:nil repeats:YES];
    
        CADisplayLink *display = [CADisplayLink displayLinkWithTarget:self selector:@selector(updataImage)];
        
        [display addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
    }
    
    return self;
}

- (void)updataImage {
    [self setNeedsDisplay];
}

- (void)drawRect:(CGRect)rect
{
    
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextClearRect(ctx, rect);
    
    UIImage *image = [UIImage imageNamed:@"snow"];
    
    _imageY += 5;
    
    [image drawAtPoint:CGPointMake(10, _imageY)];
    
    if (_imageY > rect.size.height) {
        _imageY = 0;
    }
    
}

@end
