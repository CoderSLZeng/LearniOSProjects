//
//  NJView.m
//  05-图片剪切
//
//  Created by Luffy on 15/9/6.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJView.h"

@implementation NJView

- (void)drawRect:(CGRect)rect
{
    CGContextRef ctx = UIGraphicsGetCurrentContext();
//    test(ctx);
    [self test:rect Context:ctx];
    
}

- (void)test:(CGRect)rect Context:(CGContextRef)ctx {
    
    CGFloat centerX = rect.size.width * 0.5;
    CGFloat centerY = rect.size.height * 0.5;
    
    CGContextAddArc(ctx, centerX, centerY, 50, 0, 2 * M_PI, 1);
    
    CGContextClip(ctx);
    CGContextStrokePath(ctx);
    
    UIImage *image = [UIImage imageNamed:@"me"];
    [image drawInRect:CGRectMake(centerX - 50, centerY - 50, 100, 100)];
    
    CGContextAddRect(ctx, CGRectMake(centerX - 50, centerY - 50, 100, 100));
    
    CGContextFillPath(ctx);
    
    
}

void test(CGContextRef ctx) {
    
    CGContextAddEllipseInRect(ctx, CGRectMake(100, 100, 50, 50));
    
    CGContextClip(ctx);
    
    CGContextStrokePath(ctx);
    
    UIImage *image = [UIImage imageNamed:@"me"];
    
    [image drawAtPoint:CGPointMake(100, 100)];
    
    CGContextFillPath(ctx);
}

@end
