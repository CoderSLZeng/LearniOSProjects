//
//  ViewController.m
//  11-图片水印
//
//  Created by Luffy on 15/9/6.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "UIImage+NJ.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    [self test];
    UIImage *image = [UIImage imageWithBackgroudImageName:@"psb" logo:@"logo1"];
    
    NSData *data = UIImagePNGRepresentation(image);
    
    NSString *path = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"abc.png"];
    NSLog(@"%@", path);
    
    [data writeToFile:path atomically:YES];
}


- (void)test
{
    UIImage *image = [UIImage imageNamed:@"psb"];
    
    UIGraphicsBeginImageContextWithOptions(image.size, NO, 0);
    
    [image drawAtPoint:CGPointMake(0, 0)];
    
    UIImage *logo = [UIImage imageNamed:@"logo1"];
    
    CGFloat margin = 10;
    CGFloat logoY = margin;
    CGFloat logoX = image.size.width - margin - logo.size.width;
    [logo drawAtPoint:CGPointMake(logoX, logoY)];
    
    NSString *str = @"黑马程序员";
    
    NSMutableDictionary *dictM =[NSMutableDictionary dictionary];
    dictM[NSFontAttributeName] = [UIFont systemFontOfSize:10.0];
    [str drawAtPoint:CGPointMake(200, 100) withAttributes:dictM];
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    NSData *data = UIImagePNGRepresentation(newImage);
    
    NSString *path = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"psb.png"];
    
    NSLog(@"%@", path);
    
    [data writeToFile:path atomically:YES];
    
}


@end
