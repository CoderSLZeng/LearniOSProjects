//
//  UIImage+NJ.m
//  11-图片水印
//
//  Created by Luffy on 15/9/6.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "UIImage+NJ.h"

@implementation UIImage (NJ)

+ (instancetype)imageWithBackgroudImageName:(NSString *)bgName logo:(NSString *)logo
{
    UIImage *bgImage = [UIImage imageNamed:bgName];
    
    UIGraphicsBeginImageContextWithOptions(bgImage.size, NO, 0);
    
    [bgImage drawAtPoint:CGPointMake(0, 0)];
    
    UIImage *logoImage = [UIImage imageNamed:logo];

    CGFloat margin = 10;
    CGFloat logoY = margin;
    CGFloat logoX = bgImage.size.width - margin - logoImage.size.width;
    [logoImage drawAtPoint:CGPointMake(logoX, logoY)];
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    return newImage;
    
}

@end
