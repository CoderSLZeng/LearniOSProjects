//
//  ViewController.m
//  10-基本绘图
//
//  Created by Luffy on 15/9/6.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(200, 200), NO, 0);
    
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathAddArc(path, NULL, 100, 100, 99, 0, M_PI * 2, 1);
    CGContextAddPath(ctx, path);
    
    CGPathRelease(path);
    
    CGContextStrokePath(ctx);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    self.imageView.image = image;
    
    NSData *data = UIImagePNGRepresentation(image);
    
    [data writeToFile:@"/Users/Luffy/Desktop/circle.png" atomically:YES];
    
    
    
}



@end
