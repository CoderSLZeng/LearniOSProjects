//
//  NJView.m
//  06-刷帧
//
//  Created by Luffy on 15/9/6.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJView.h"

@implementation NJView

- (void)setRadius:(float)radius
{
    _radius = radius;
    
    [self setNeedsDisplay];
    
}

- (void)awakeFromNib
{
    self.radius = 10;
}

- (void)drawRect:(CGRect)rect
{
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    
    CGContextAddArc(ctx, rect.size.width * 0.5, rect.size.height * 0.5, self.radius, 0, 2 * M_PI, 0);
//    CGContextAddEllipseInRect(ctx, CGRectMake(0, 0, 200, 200));
    
    [[UIColor purpleColor] set];
    
    CGContextFillPath(ctx);
    
}

@end
