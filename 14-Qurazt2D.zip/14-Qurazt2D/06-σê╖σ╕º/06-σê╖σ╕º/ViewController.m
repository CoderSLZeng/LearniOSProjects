//
//  ViewController.m
//  06-刷帧
//
//  Created by Luffy on 15/9/6.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "NJView.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet NJView *circleView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)changeVale:(UISlider *)sender {
    
    self.circleView.radius = sender.value;
    
//    [self.circleView setNeedsDisplay];
}

@end
