//
//  NJHumanView.m
//  02-小黄人
//
//  Created by Luffy on 15/9/5.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJHumanView.h"

#define NJTopX rect.size.width * 0.5

#define NJTopRadius              80 // 顶部半径值
#define NJTopY                150    // 顶部Y值

@implementation NJHumanView

- (void)drawRect:(CGRect)rect {
    
    CGContextRef cxt = UIGraphicsGetCurrentContext();
    
    
    
    // 画脸部和身体
    [self drawFaceWithCGContextRef:cxt AndRect:rect];
    // 画眼睛
    [self drawEyesWithCGContextRef:cxt];
    // 画嘴巴
    [self drawMouthWithCGContextRef:cxt AndRect:rect];
    
    // 画头发
    [self drawHairWithCGContextRef:cxt AndRect:rect];

    // 坐标
//    [self drawCoordsWithCGContextRef:cxt AndRect:rect];
}

// 画头发
- (void)drawHairWithCGContextRef:(CGContextRef)cxt AndRect:(CGRect)rect {

    CGFloat oneX = NJTopX;
    CGFloat oneY = NJTopY - NJTopRadius + 5;
    CGContextMoveToPoint(cxt, oneX, oneY);
    CGContextAddLineToPoint(cxt, oneX, oneY - 30);
    
    CGFloat twoX = NJTopX - 10;
    CGFloat twoY = NJTopY - NJTopRadius + 5;
    CGContextMoveToPoint(cxt, twoX, twoY);
    CGContextAddLineToPoint(cxt, twoX - 20, twoY - 30);
    
    CGFloat threeX = NJTopX + 10;
    CGFloat threeY = NJTopY - NJTopRadius + 5;
    CGContextMoveToPoint(cxt, threeX, threeY);
    CGContextAddLineToPoint(cxt, threeX + 20, threeY - 30);
    
    CGContextStrokePath(cxt);

    
}

// 画嘴巴
- (void)drawMouthWithCGContextRef:(CGContextRef)cxt AndRect:(CGRect)rect {

    // 控制点
    CGFloat controllerX = NJTopX;
    CGFloat controllerY = rect.size.height * 0.5 + 10;
    
    // 当前点
    CGFloat maginX = 30;
    CGFloat maginY = 20;
    CGFloat currentX = controllerX - maginX;
    CGFloat currentY = controllerY - maginY;
    CGContextMoveToPoint(cxt, currentX, currentY);
    
    // 结束点
    CGFloat endX = controllerX + maginX;
    CGFloat endY = currentY;
    
    CGContextAddQuadCurveToPoint(cxt, controllerX, controllerY, endX, endY);
    
    [[UIColor blackColor] set];
    
    CGContextSetLineWidth(cxt, 1);
    
    CGContextStrokePath(cxt);
}

// 画眼镜
- (void)drawEyesWithCGContextRef:(CGContextRef)cxt
{
    CGFloat starX = self.center.x - NJTopRadius;
    CGFloat starY = NJTopY;
    CGContextMoveToPoint(cxt, starX, starY);
    
    CGFloat endX = self.center.x + NJTopRadius;
    CGFloat endY = starY;
    CGContextAddLineToPoint(cxt, endX, endY);
    CGContextSetLineWidth(cxt, 15);
    [[UIColor blackColor] set];

    CGContextStrokePath(cxt);
    
    // 左眼
    CGFloat leftOrginX = self.center.x - 35;
    CGFloat leftX = leftOrginX + 10;
    [self createGlassesWithCGContextRef:cxt AndPoint:leftOrginX andPoint:leftX];
    
    // 右眼
    CGFloat rightOrginX = self.center.x + 35;
    CGFloat rightX = rightOrginX - 10;
    [self createGlassesWithCGContextRef:cxt AndPoint:rightOrginX andPoint:rightX];
    
}


/**
 *  创建一个眼镜和眼珠
 *
 *  @param cxt 上下文
 *  @param p1  眼镜框的原点位置
 *  @param p2  眼珠的原点位置
 */
- (void)createGlassesWithCGContextRef:(CGContextRef)cxt AndPoint:(CGFloat)p1 andPoint:(CGFloat)p2
{
    
    CGFloat glasserBigRadius = 35; // 眼镜框外圆的半径
    // 眼镜
    drawClicle(cxt, p1, NJTopY, glasserBigRadius);
    CGContextSetRGBFillColor(cxt, 79/255.0, 78/255.0, 83/255.0, 1.0);
    CGContextFillPath(cxt);
    
    CGFloat glassesSmallRadius = 25; // 眼镜框内圆的半径
//    CGContextAddArc(cxt, p1, topY, glassesSmallRadius, 0, 2 * M_PI, 1);
    drawClicle(cxt, p1, NJTopY, glassesSmallRadius);
    [[UIColor whiteColor] set];
    CGContextFillPath(cxt);
    
    // 眼珠子
    CGFloat eyesBigRadius = 10; // 眼珠外圆的半径
    drawClicle(cxt, p2, NJTopY, eyesBigRadius);
    CGContextSetRGBFillColor(cxt, 99/255.0, 29/255.0, 10/255.0, 1.0);
    CGContextFillPath(cxt);
    
    CGFloat eyesSmallRadius = 5; // 眼珠内圆的半径
    drawClicle(cxt, p2, NJTopY, eyesSmallRadius);
    [[UIColor blackColor] set];
    CGContextFillPath(cxt);
    
    CGFloat lightEyesX = p2 - 2;
    CGFloat lightEyesY = NJTopY - 2;
    CGFloat eyesLightRadius = 2; // 眼珠的亮点的半径
    drawClicle(cxt, lightEyesX, lightEyesY, eyesLightRadius);
    [[UIColor whiteColor] set];
    CGContextFillPath(cxt);
}

/**
 *  画圆 - C语言方法
 *
 *  @param cxt           上下文
 *  @param centerX       原点X的值
 *  @param centerY       原点Y的值
 *  @param glassesRadius 半径
 */
void drawClicle(CGContextRef cxt, CGFloat centerX, CGFloat centerY, CGFloat glassesRadius)
{
    CGContextAddArc(cxt, centerX, centerY, glassesRadius, 0, 2 * M_PI, 1);
}


// 画脸和身体
- (void)drawFaceWithCGContextRef:(CGContextRef)cxt AndRect:(CGRect)rect
{
    // 顶部
    CGFloat topX = NJTopX;
    CGContextAddArc(cxt, topX, NJTopY, NJTopRadius, -M_PI, 0, 0);
    
    // 中间
    CGFloat middleX = NJTopX + NJTopRadius;
    CGFloat middleY = NJTopY + 150;
    
    CGContextAddLineToPoint(cxt, middleX, middleY);
    
    // 底部圆
    CGFloat bottomX = topX;
    CGFloat bottomY = middleY;
    CGContextAddArc(cxt, bottomX, bottomY, NJTopRadius, 0, -M_PI, 0);
    // 合并起点
    CGContextClosePath(cxt);
    
    // 设置颜色
    CGContextSetRGBFillColor(cxt, 252/255.0, 221/255.0, 12/255.0, 1.0);
    CGContextFillPath(cxt);
}

// 坐标 - 测试玩，要删除
- (void)drawCoordsWithCGContextRef:(CGContextRef)cxt AndRect:(CGRect)rect
{
    
    CGContextMoveToPoint(cxt, NJTopX, 0);
    
    CGContextAddLineToPoint(cxt, NJTopX, 480);
    
    [[UIColor blackColor] set];
    
    CGContextSetLineWidth(cxt, 1);
    
    CGContextStrokePath(cxt);
}



@end
