//
//  NJOneViewController.m
//  07-modal
//
//  Created by Luffy on 15/9/5.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJOneViewController.h"
#import "NJTwoViewController.h"

@interface NJOneViewController ()

@end

@implementation NJOneViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (IBAction)jump2TwoView:(UIButton *)sender {
    
    NJTwoViewController *two = [[NJTwoViewController alloc] init];
    
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:two];
    
    [self presentViewController:nav animated:YES completion:^{
          NSLog(@"%s", __func__);
    }];
    
}

@end
