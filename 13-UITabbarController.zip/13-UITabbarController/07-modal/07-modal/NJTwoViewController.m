//
//  NJTwoViewController.m
//  07-modal
//
//  Created by Luffy on 15/9/5.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJTwoViewController.h"

@interface NJTwoViewController ()

@end

@implementation NJTwoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"取消" style:UIBarButtonItemStylePlain target:self action:@selector(cancelBtnOnClick)];
}

- (void)cancelBtnOnClick {
    
    [self dismissViewControllerAnimated:YES completion:^{
        NSLog(@"%s", __func__);
    }];
}



@end
