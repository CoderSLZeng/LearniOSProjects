//
//  NJViewController.m
//  05-modal-纯代码
//
//  Created by Luffy on 15/9/2.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJViewController.h"
#import "TwoViewController.h"

@interface NJViewController ()

@end

@implementation NJViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    CGFloat btnX = self.view.center.x;
    CGFloat btnY = self.view.center.y;
    CGFloat btnW = 44;
    CGFloat btnH = 80;
    
    UIButton  *btn = [[UIButton alloc] initWithFrame:CGRectMake(btnX, btnY, btnW, btnH)];
    [btn setTitle:@"点我啊" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [self.view addSubview:btn];
    
    [btn addTarget:self action:@selector(nextViewBtnOnClick) forControlEvents:UIControlEventTouchUpInside];
    
}

- (void)nextViewBtnOnClick
{
    TwoViewController *two = [[TwoViewController alloc] init];
    
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:two];
    
    [self presentViewController:nav animated:YES completion:^{
          NSLog(@"%s", __func__);
    }];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
