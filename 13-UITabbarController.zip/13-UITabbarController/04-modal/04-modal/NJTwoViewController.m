//
//  NJTwoViewController.m
//  04-modal
//
//  Created by Luffy on 15/9/2.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJTwoViewController.h"

@interface NJTwoViewController ()

@end

@implementation NJTwoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"取消" style:UIBarButtonItemStylePlain target:self action:@selector(cancleBtnOnClick)];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}


- (void)cancleBtnOnClick {
    [self dismissViewControllerAnimated:YES completion:^{
          NSLog(@"%s", __func__);
    }];
}

@end
