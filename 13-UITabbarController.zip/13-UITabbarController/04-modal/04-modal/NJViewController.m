//
//  NJViewController.m
//  04-modal
//
//  Created by Luffy on 15/9/2.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "NJViewController.h"
#import "NJTwoViewController.h"

@interface NJViewController ()

@end

@implementation NJViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btnOnClick:(UIButton *)sender {
    
    NJTwoViewController *two = [[NJTwoViewController alloc] init];
    
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:two];
    
    [self presentViewController:nav animated:YES completion:^{
          NSLog(@"%s", __func__);
    }];
}


@end
