//
//  NJTwoViewController.h
//  06=Modal-storyboard
//
//  Created by Luffy on 15/9/4.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NJTwoViewController : UIViewController
@property (nonatomic, copy) NSString *name;

@end
