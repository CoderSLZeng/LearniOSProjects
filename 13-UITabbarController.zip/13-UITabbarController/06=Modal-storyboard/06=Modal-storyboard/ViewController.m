//
//  ViewController.m
//  06=Modal-storyboard
//
//  Created by Luffy on 15/9/4.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "NJTwoViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    UINavigationController *nav = segue.destinationViewController;
    
    NJTwoViewController *two = (NJTwoViewController *)nav.topViewController;

}

@end
