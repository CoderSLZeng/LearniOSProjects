//
//  ViewController.m
//  01-QQ聊天界面
//
//  Created by Luffy on 15/8/14.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "HMMessageModel.h"
#import "HMMessageCell.h"
#import "HMMessageFrameModel.h"

@interface ViewController () <UITableViewDataSource, UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *messageFrames;

@end

@implementation ViewController

- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (NSMutableArray *)messageFrames
{
    if (_messageFrames == nil) _messageFrames = [HMMessageFrameModel messageFrames];
    return _messageFrames;
}

- (void)viewDidLoad {
    [super viewDidLoad];
//    NSLog(@"%@ - %i", self.messages, self.messages.count);
    
    self.tableView.allowsSelection = NO;
    self.tableView.backgroundColor = [UIColor colorWithRed:225/255.0 green:225/255.0 blue:225/255.0 alpha:1.0];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
};

#pragma mark - 数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.messageFrames.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    HMMessageCell *cell = [HMMessageCell messageCellWithTableView:tableView];
    
    HMMessageFrameModel *messageFrame = self.messageFrames[indexPath.row];
    
    cell.messageFrame = messageFrame;
    
    return cell;
}

#pragma mark - 代理方法
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    HMMessageFrameModel *messageFrame = self.messageFrames[indexPath.row];
    return messageFrame.cellHeight;
}


@end
