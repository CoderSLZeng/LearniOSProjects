//
//  HMMessageFrameModel.m
//  01-QQ聊天界面
//
//  Created by Luffy on 15/8/14.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMMessageFrameModel.h"
#import "HMMessageModel.h"
#import "Constant.h"


@implementation HMMessageFrameModel

-(void)setMessage:(HMMessageModel *)message
{
    _message = message;
    
    // 0.边距
    CGFloat padding = 10;
    
    // 1.时间
    CGFloat timeX = 0;
    CGFloat timeY = 0;
    CGFloat timeW = kScreenWidth;
    CGFloat timeH = kNormalHeight;
    
    _timeF = CGRectMake(timeX, timeY, timeW, timeH);
    
    // 2.头像
    CGFloat iconX;
    CGFloat iconY = CGRectGetMaxY(_timeF);
    CGFloat iconW = kIcon;
    CGFloat iconH = kIcon;
    
    if (message.type == HMMessageModelGatsby) {
        iconX = kScreenWidth - padding - iconW;
    } else {
        iconX = padding;
    }
    
    _iconF = CGRectMake(iconX, iconY, iconW, iconH);
    
    // 3.正文
    CGFloat textX;
    CGFloat textY = iconY + padding;
    CGSize textMaxSize = CGSizeMake(150, MAXFLOAT);
    CGSize textRealSize = [message.text boundingRectWithSize:textMaxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName: kTextFont} context:nil].size;
    
    CGSize btnSize = CGSizeMake(textRealSize.width + 40, textRealSize.height + 40);
    
    if (message.type == HMMessageModelGatsby) {
        textX = kScreenWidth - iconW - padding - btnSize.width;
    } else {
        textX = padding + iconW;
    }
    
//    _textF = (CGRect){{textX, textY}, textRealSize};
    _textF = (CGRect){{textX, textY}, btnSize};
    
    // 4.cell高度
    CGFloat iconMaxY = CGRectGetMaxY(_iconF);
    CGFloat textMaxY = CGRectGetMaxY(_textF);
    _cellHeight = MAX(iconMaxY, textMaxY);
    
}

+ (NSMutableArray *)messageFrames
{
    NSArray *array = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"messages.plist" ofType:nil]];
    
    NSMutableArray *arrayM = [NSMutableArray array];
    
    for (NSDictionary *dict in array) {
        HMMessageFrameModel *messageFrame = [[self alloc] init];
        
        HMMessageModel *message = [HMMessageModel messageWithDict:dict];
        
        messageFrame.message = message;
        
        [arrayM addObject:messageFrame];
    }
    return arrayM;
}

@end
