//
//  HMMessageCell.h
//  01-QQ聊天界面
//
//  Created by Luffy on 15/8/14.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HMMessageFrameModel;

@interface HMMessageCell : UITableViewCell

@property (nonatomic, strong) HMMessageFrameModel *messageFrame;

+ (instancetype)messageCellWithTableView:(UITableView *)tableView;

@end
