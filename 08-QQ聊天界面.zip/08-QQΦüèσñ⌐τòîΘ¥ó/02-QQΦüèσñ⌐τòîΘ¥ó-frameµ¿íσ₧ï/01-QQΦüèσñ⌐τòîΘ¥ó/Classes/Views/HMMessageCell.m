//
//  HMMessageCell.m
//  01-QQ聊天界面
//
//  Created by Luffy on 15/8/14.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "HMMessageCell.h"
#import "HMMessageFrameModel.h"
#import "HMMessageModel.h"
#import "Constant.h"

@interface HMMessageCell ()

@property (weak, nonatomic) UILabel *timeView;
@property (weak, nonatomic) UIImageView *iconView;
@property (weak, nonatomic) UIButton *textView;

@end

@implementation HMMessageCell

+ (instancetype)messageCellWithTableView:(UITableView *)tableView
{
    static NSString *ID = @"messageCell";
    
    HMMessageCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    
    if (cell == nil) {
        cell = [[self alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
    }
    
    return cell;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self) {
        // 1.时间
        UILabel *timeView = [[UILabel alloc] init];
        [self.contentView addSubview:timeView];
        timeView.font = kTimeFont;
        timeView.textAlignment = NSTextAlignmentCenter;
        self.timeView = timeView;
        
        // 2.头像
        UIImageView *iconView = [[UIImageView alloc] init];
        [self.contentView addSubview:iconView];
        self.iconView = iconView;
        
        // 3.正文
        UIButton *textView = [[UIButton alloc] init];
        [self.contentView addSubview:textView];
        textView.titleLabel.font = kTextFont;
        textView.titleLabel.numberOfLines = 0;
        textView.backgroundColor = [UIColor grayColor];
        self.textView = textView;
    }
    
    return self;
}

- (void)setMessageFrame:(HMMessageFrameModel *)messageFrame
{
    _messageFrame = messageFrame;
    
    HMMessageModel *message = messageFrame.message;
    
    // 1.时间
    self.timeView.frame = messageFrame.timeF;
    self.timeView.text = message.time;
    
    // 2.头像
    self.iconView.frame = messageFrame.iconF;
    if (message.type == HMMessageModelGatsby) {
        self.iconView.image = [UIImage imageNamed:@"Gatsby"];
    } else {
        self.iconView.image = [UIImage imageNamed:@"Jobs"];
    }
    
    // 3.正文
    self.textView.frame = messageFrame.textF;
    [self.textView setTitle:message.text forState:UIControlStateNormal];
    
    
    
    
    
    
    
    
    
    
    
    
}

@end
