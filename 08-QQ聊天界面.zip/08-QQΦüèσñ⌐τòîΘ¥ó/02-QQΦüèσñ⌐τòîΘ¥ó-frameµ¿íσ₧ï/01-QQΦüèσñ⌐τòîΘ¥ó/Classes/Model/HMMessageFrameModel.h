//
//  HMMessageFrameModel.h
//  01-QQ聊天界面
//
//  Created by Luffy on 15/8/14.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@class HMMessageModel;

@interface HMMessageFrameModel : NSObject

@property (nonatomic, assign, readonly) CGRect timeF;
@property (nonatomic, assign, readonly) CGRect iconF;
@property (nonatomic, assign, readonly) CGRect textF;

@property (nonatomic, assign, readonly) CGFloat cellHeight;

@property (nonatomic, strong) HMMessageModel *message;

+ (NSMutableArray *)messageFrames;
@end
