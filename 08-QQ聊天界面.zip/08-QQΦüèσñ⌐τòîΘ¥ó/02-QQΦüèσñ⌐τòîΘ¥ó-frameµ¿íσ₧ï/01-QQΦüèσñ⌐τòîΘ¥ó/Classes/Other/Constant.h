//
//  Constant.h
//  01-QQ聊天界面
//
//  Created by Luffy on 15/8/14.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#define kScreenWidth    [[UIScreen mainScreen] bounds].size.width
#define kNormalHeight   44
#define kIcon           50;
#define kTimeFont       [UIFont systemFontOfSize:13.f]
#define kTextFont       [UIFont systemFontOfSize:16.f]