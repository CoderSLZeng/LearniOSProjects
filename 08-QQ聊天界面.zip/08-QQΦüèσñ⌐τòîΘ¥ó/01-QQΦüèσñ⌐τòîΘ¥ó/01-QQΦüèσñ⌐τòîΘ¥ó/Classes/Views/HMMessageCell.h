//
//  HMMessageCell.h
//  01-QQ聊天界面
//
//  Created by Luffy on 15/8/14.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HMMessageCell : UITableViewCell

@property (weak, nonatomic) UILabel *timeView;
@property (weak, nonatomic) UIImageView *iconView;
@property (weak, nonatomic) UIButton *textView;

+ (instancetype)messageCellWithTableView:(UITableView *)tableView;

@end
