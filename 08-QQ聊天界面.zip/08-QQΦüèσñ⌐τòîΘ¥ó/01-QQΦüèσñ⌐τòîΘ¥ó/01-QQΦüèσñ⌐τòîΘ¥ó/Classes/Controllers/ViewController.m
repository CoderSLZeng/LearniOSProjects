//
//  ViewController.m
//  01-QQ聊天界面
//
//  Created by Luffy on 15/8/14.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "HMMessageModel.h"
#import "HMMessageCell.h"

@interface ViewController () <UITableViewDataSource, UITabBarDelegate>

@property (nonatomic, strong) NSMutableArray *messages;

@end

@implementation ViewController

- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (NSMutableArray *)messages
{
    if (_messages == nil) _messages = [HMMessageModel messages];
    return _messages;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    NSLog(@"%@ - %i", self.messages, self.messages.count);
};

#pragma mark - 数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.messages.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    static NSString *ID = @"messageCell";
//    
//    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
//    
//    if (cell == nil) {
//        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
//    }
    
    HMMessageCell *cell = [HMMessageCell messageCellWithTableView:tableView];
    
    return cell;
}


@end
