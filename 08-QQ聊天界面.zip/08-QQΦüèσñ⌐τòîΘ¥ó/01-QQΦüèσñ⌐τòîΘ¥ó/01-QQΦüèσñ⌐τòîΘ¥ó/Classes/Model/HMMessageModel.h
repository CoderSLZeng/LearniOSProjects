//
//  HMMessageModel.h
//  01-QQ聊天界面
//
//  Created by Luffy on 15/8/14.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    HMMessageModelGatsby = 0,
    HMMessageModelJobs
} HMMessageModelType;

@interface HMMessageModel : NSObject

@property (nonatomic, copy) NSString *time;
@property (nonatomic, copy) NSString *text;
@property (nonatomic, assign) HMMessageModelType type;

- (instancetype)initWithDict:(NSDictionary *)dict;
+ (instancetype)messageWithDict:(NSDictionary *)dict;

+ (NSMutableArray *)messages;
@end
