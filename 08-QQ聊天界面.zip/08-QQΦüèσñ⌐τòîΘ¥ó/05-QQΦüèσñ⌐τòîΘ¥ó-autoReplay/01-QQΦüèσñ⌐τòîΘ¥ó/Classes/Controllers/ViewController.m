//
//  ViewController.m
//  01-QQ聊天界面
//
//  Created by Luffy on 15/8/14.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "HMMessageModel.h"
#import "HMMessageCell.h"
#import "HMMessageFrameModel.h"

@interface ViewController () <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UITextField *inputView;

@property (nonatomic, strong) NSMutableArray *messageFrames;
@property (nonatomic, strong) NSDictionary *autoReplay;

@end

@implementation ViewController

- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (NSMutableArray *)messageFrames
{
    if (_messageFrames == nil) _messageFrames = [HMMessageFrameModel messageFrames];
    return _messageFrames;
}

- (NSDictionary *)autoReplay
{
    if (_autoReplay == nil) {
        _autoReplay = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"autoReplay.plist" ofType:nil]];
    }
    return _autoReplay;
}

- (void)viewDidLoad {
    [super viewDidLoad];
//    NSLog(@"%@ - %i", self.messages, self.messages.count);
    
    self.tableView.allowsSelection = NO;
    self.tableView.backgroundColor = [UIColor colorWithRed:225/255.0 green:225/255.0 blue:225/255.0 alpha:1.0];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillChangeFrame:) name:UIKeyboardWillChangeFrameNotification object:nil];
    
    self.inputView.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 8, 0)];
    self.inputView.leftViewMode = UITextFieldViewModeAlways;
}

//2015-08-15 09:33:42.013 01-QQ聊天界面[803:138905] --------{
//    UIKeyboardAnimationCurveUserInfoKey = 7;
//    UIKeyboardAnimationDurationUserInfoKey = "0.25";
//    UIKeyboardBoundsUserInfoKey = "NSRect: {{0, 0}, {320, 253}}";
//    UIKeyboardCenterBeginUserInfoKey = "NSPoint: {160, 353.5}";
//    UIKeyboardCenterEndUserInfoKey = "NSPoint: {160, 606.5}";
//    UIKeyboardFrameBeginUserInfoKey = "NSRect: {{0, 227}, {320, 253}}";
//    UIKeyboardFrameEndUserInfoKey = "NSRect: {{0, 480}, {320, 253}}";

// 更改键盘Frame方法
- (void)keyboardWillChangeFrame:(NSNotification *)notification
{
    NSLog(@"--------%@", notification.userInfo);
    
    self.view.window.backgroundColor = self.tableView.backgroundColor;
    
    CGRect frame = [notification.userInfo [UIKeyboardFrameEndUserInfoKey] CGRectValue];
    
    CGFloat keyY = frame.origin.y;
    
    CGFloat screenHeight = [[UIScreen mainScreen] bounds].size.height;
    
    CGFloat keyDuration = [notification.userInfo [UIKeyboardAnimationDurationUserInfoKey] floatValue];
    [UIView animateWithDuration:keyDuration animations:^{
        self.view.transform = CGAffineTransformMakeTranslation(0, keyY - screenHeight);
    }];
}


- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [self.view endEditing:YES];
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSLog(@"----%@", textField.text);
    
    // 1.发送一条信息
    [self addMessage:textField.text WithType:HMMessageModelGatsby];
    
    // 2.自动回复一条信息
    NSString *autoStr = [self autoReplayWithText:textField.text];
    
    // 将自动回复添加成一条聊天信息
    [self addMessage:autoStr WithType:HMMessageModelJobs];
    
    // 3.清空表格
    self.inputView.text = nil;
    
    return YES;
}

// 自动回复一条聊天信息
- (NSString *)autoReplayWithText:(NSString *)text
{
    for (int i = 0; i < text.length; i++) {
        NSString *subStr = [text substringWithRange:NSMakeRange(i, 1)];
        
        if (self.autoReplay[subStr]) {
            return self.autoReplay[subStr];
        }
    }
    
    return @"滚蛋";
}

// 添加一条聊天信息
- (void)addMessage:(NSString *)text WithType:(HMMessageModelType)type
{
    // 1.添加数据模型
    HMMessageModel *message = [[HMMessageModel alloc] init];
    
    // 2.设置数据的值
    message.time = @"22:22";
    message.text = text;
    message.type = type;
    
    // 3.设置内容的frame
    HMMessageFrameModel *messageFrame = [[HMMessageFrameModel alloc] init];
    
    messageFrame.message = message;
    
    [self.messageFrames addObject:messageFrame];
    
    // 4.刷新表格
    [self.tableView reloadData];
    
    // 5.自动上移
    NSIndexPath *path = [NSIndexPath indexPathForItem:self.messageFrames.count - 1 inSection:0];
    [self.tableView scrollToRowAtIndexPath:path atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

#pragma mark - 数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.messageFrames.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    HMMessageCell *cell = [HMMessageCell messageCellWithTableView:tableView];
    
    HMMessageFrameModel *messageFrame = self.messageFrames[indexPath.row];
    
    cell.messageFrame = messageFrame;
    
    return cell;
}

#pragma mark - 代理方法
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    HMMessageFrameModel *messageFrame = self.messageFrames[indexPath.row];
    return messageFrame.cellHeight;
}


@end
